using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.Utilities
{
    public static class SqlUtilities
    {
        public static bool IsSqlNullValue(object value)
        {
            bool bReturn = false;
            if (value==null){bReturn = true;}
            if (value.GetType().Equals(DBNull.Value.GetType())) { bReturn = true; }
            if (value.ToString() == string.Empty) { bReturn = true; }
            //TODO: Extend - theres probably more
            return bReturn;
        }
    }
}
