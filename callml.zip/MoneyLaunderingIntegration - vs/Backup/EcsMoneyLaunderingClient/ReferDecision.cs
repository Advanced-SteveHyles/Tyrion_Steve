using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ECS.MoneyLaundering
{
    public partial class ReferDecision : Form
    {
        public ReferDecision()
        {
            InitializeComponent();
        }

        private void Radio_CheckedChanged(object sender, EventArgs e)
        {
            btnContinue.Enabled = true;
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public string Decision
        {
            get
            {
                string result = "";
                
                if (radOverride.Checked)
                    result = "override";
                if (radDecline.Checked)
                    result = "decline";

                return result;
            }
        }

    }
}