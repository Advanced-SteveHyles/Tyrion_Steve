namespace ECS.MoneyLaundering
{
    partial class ReferDecision
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReferDecision));
            this.radOverride = new System.Windows.Forms.RadioButton();
            this.radDecline = new System.Windows.Forms.RadioButton();
            this.radRefer = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.btnContinue = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // radOverride
            // 
            this.radOverride.AutoSize = true;
            this.radOverride.Location = new System.Drawing.Point(27, 32);
            this.radOverride.Name = "radOverride";
            this.radOverride.Size = new System.Drawing.Size(272, 17);
            this.radOverride.TabIndex = 0;
            this.radOverride.Text = "Override the refer decision and regenerate the report";
            this.radOverride.UseVisualStyleBackColor = true;
            this.radOverride.CheckedChanged += new System.EventHandler(this.Radio_CheckedChanged);
            // 
            // radDecline
            // 
            this.radDecline.AutoSize = true;
            this.radDecline.Location = new System.Drawing.Point(27, 55);
            this.radDecline.Name = "radDecline";
            this.radDecline.Size = new System.Drawing.Size(268, 17);
            this.radDecline.TabIndex = 1;
            this.radDecline.Text = "Decline the refer decision and regenerate the report";
            this.radDecline.UseVisualStyleBackColor = true;
            this.radDecline.CheckedChanged += new System.EventHandler(this.Radio_CheckedChanged);
            // 
            // radRefer
            // 
            this.radRefer.AutoSize = true;
            this.radRefer.Checked = true;
            this.radRefer.Location = new System.Drawing.Point(27, 78);
            this.radRefer.Name = "radRefer";
            this.radRefer.Size = new System.Drawing.Size(140, 17);
            this.radRefer.TabIndex = 2;
            this.radRefer.TabStop = true;
            this.radRefer.Text = "Retain the referral status";
            this.radRefer.UseVisualStyleBackColor = true;
            this.radRefer.CheckedChanged += new System.EventHandler(this.Radio_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(299, 20);
            this.label1.TabIndex = 3;
            this.label1.Text = "The decision has been referred. Please choose one option:";
            // 
            // btnContinue
            // 
            this.btnContinue.Location = new System.Drawing.Point(236, 106);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(75, 23);
            this.btnContinue.TabIndex = 4;
            this.btnContinue.Text = "&Continue";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // ReferDecision
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 134);
            this.ControlBox = false;
            this.Controls.Add(this.btnContinue);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radRefer);
            this.Controls.Add(this.radDecline);
            this.Controls.Add(this.radOverride);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ReferDecision";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Applicant Referred";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radOverride;
        private System.Windows.Forms.RadioButton radDecline;
        private System.Windows.Forms.RadioButton radRefer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnContinue;
    }
}