using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ECS.MoneyLaundering
{
    public partial class PicklistForm : Form
    {
        public PicklistForm()
        {
            InitializeComponent();
        }

        public void SetComment(string comment)
        {
            label1.Text = comment;
        }

        public void ShowCheckboxes(bool show)
        {
          
        }

        public void PopulateList(object[] pickListStrings)
        {
            foreach (object pickListString in pickListStrings)
            {
                lbxPicklist.Items.Add(pickListString);
            }

        }

        private void btnOK_Click(object sender, System.EventArgs e)
        {
            if (lbxPicklist.SelectedIndex != -1)
            {
                DialogResult = DialogResult.OK;
            }
        }

        public int SelectedIndex
        {
            get
            {
                return lbxPicklist.SelectedIndex;
            }
        }

        private void lbxPicklist_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnOK.Enabled = (lbxPicklist.SelectedIndex != -1);
        }

        private void lbxPicklist_DoubleClick(object sender, EventArgs e)
        {
            if (lbxPicklist.SelectedIndex != -1)
            {
                DialogResult = DialogResult.OK;
            }
        }
    }
}