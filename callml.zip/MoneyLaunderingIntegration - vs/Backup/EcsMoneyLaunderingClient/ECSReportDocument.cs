using System;
using CrystalDecisions.Windows.Forms;
using ECS.Utilities.Connectivity;

namespace ECS.MoneyLaundering
{

    public class ECSReportDocument
    {
        private ECSIndividual m_Client;
        CallML.callmlsearch6 m_ResponseData;
        private string m_Path;
        ECS.Reports.ECSCrystalViewer crystalViewer = new ECS.Reports.ECSCrystalViewer();

        public ECSReportDocument(ECSIndividual ClientData, CallML.callmlsearch6 ResponseData)
        {
            m_Client = ClientData;
            m_ResponseData = ResponseData;

        }

        public void Generate()
        {
            // Generate document
            MLResultFacade resultFacade = new MLResultFacade(m_ResponseData);
            CrystalReports.CallMLReport report = new CrystalReports.CallMLReport();
            report.SetDataSource(new object[] { resultFacade });
            report.Subreports["CallMLCCJSubReport.rpt"].SetDataSource(resultFacade.CCJs);
            report.Subreports["CallMLInsolvenciesSubReport.rpt"].SetDataSource(resultFacade.Insolvencies);
            report.Subreports["CallMLShareSubReport.rpt"].SetDataSource(resultFacade.ShareRecords);
            report.Subreports["CallMLUKInvestorsSubReport.rpt"].SetDataSource(resultFacade.UKInvestors);
            report.Subreports["CallMLERSubReport.rpt"].SetDataSource(resultFacade.ElectoralRollRecords);
            
            // Show the report in the viewer
            crystalViewer.Text = "Money Laundering Report";
            crystalViewer.CrystalReportViewer.DisplayGroupTree = false;
            crystalViewer.CrystalReportViewer.ReportSource = report;
            crystalViewer.CrystalReportViewer.EnableDrillDown = false;
            crystalViewer.CrystalReportViewer.ShowGroupTreeButton = false;
            crystalViewer.ShowDialog();
  
            // Save document
            if (Path != null)
                report.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat,Path);
        }

        public void Close()
        {
            crystalViewer.Close();
        }

        private string GenerateFileName()
        {
            // Remove invalid characters from fullname
            string fullname = m_Client.Fullname;
            foreach (char invalidChar in System.IO.Path.GetInvalidFileNameChars())
            {
                fullname = fullname.Replace(invalidChar.ToString(), "");
            }
            //Example return MLReport_Mr John Green_010107_1002
            return String.Format("MLReport_{0}_{1}.pdf", fullname, DateTime.Now.ToString("ddMMyyyy_HHmm"));
        }

        public string Path
        {
            get
            {
                if (String.IsNullOrEmpty(m_Path))
                {
                    try
                    {
                        //TODO: Future Work - Replace ECA Get Path with Connection Manager Get Path
                        //Returns root document storage path for the entity ID supplied
                        if (m_Client != null)
                        {
                            string sClientRootPath = ECAServicesWrapper.GetClientPath(m_Client.EntityID);
                            m_Path = sClientRootPath + GenerateFileName();
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new ApplicationException("Unable to generate Report Document save path", ex);
                    }
                }
                return m_Path;
            }
        }
    }
}
