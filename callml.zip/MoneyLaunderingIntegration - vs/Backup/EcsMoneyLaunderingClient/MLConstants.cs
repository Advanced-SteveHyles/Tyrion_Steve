using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.MoneyLaundering
{
    public sealed class MLConstants
    {
        //ML Decision Constants
        public const string MLSUCCESSOUTCOME = "Yes";
        public const string MLWARNINGOUTCOME = "Yes -- Warning Present!";
        public const string MLREFEROUTCOME = "Refer";
        public const string MLOVERRIDEOUTCOME = "override";
        public const string MLDECLINEOUTCOME = "decline";
                
        //dalastml result values
        public const char DA_VALIDRESULT = 'Y';
        public const char DA_WARNINGRESULT = 'W';
        public const char DA_REFERRESULT = 'R';
        public const char DA_OVERRIDERESULT = 'O';
        public const char DA_DECLINERESULT = 'D';
        public const char DA_UNKNOWNRESULT = 'X';
    }
}
