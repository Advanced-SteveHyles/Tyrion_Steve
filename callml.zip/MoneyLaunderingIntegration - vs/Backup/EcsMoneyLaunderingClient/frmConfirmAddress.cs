using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ECS.Global;
using ECS.MoneyLaundering;

namespace ECS.MoneyLaundering
{
    public partial class frmConfirmAddress : Form
    {
        public frmConfirmAddress(CallML.address address, CallML.identity[] identities)
        {
            InitializeComponent();

            if (address != null)
            {
                txtBuildingName.Text = address.buildingname;
                txtBuildingNo.Text = address.buildingno;
                txtLine1.Text = address.street1;
                txtLine2.Text = address.street2;
                txtLine3.Text = address.sublocality;
                txtVillage.Text = address.locality;
                txtTown.Text = address.posttown;
                txtPostcode.Text = address.postcode;

                GetTitleList();
            }
            else // a resubmit - just display the ID tab
            {
                tabAddress.TabPages.Remove(tabPage1);
                tabAddress.TabPages.Remove(tabPage3);
                if (identities != null)
                {
                    foreach (CallML.identity currentID in identities)
                    {
                        switch (currentID.idtype)
                        {
                            case "5": //passport
                                foreach (CallML.idparam param in currentID.idparams)
                                {
                                    switch (param.idkey)
                                    {
                                        case "MACHINEREADABLELINE1":
                                            txtPassport1.Text = param.idvalue;
                                            break;
                                        case "MACHINEREADABLELINE2":
                                            txtPassport2.Text = param.idvalue;
                                            break;
                                        case "EXPIRYDATE":
                                            string day = param.idvalue.Substring(0, 2);
                                            string month = param.idvalue.Substring(2, 2);
                                            string year = param.idvalue.Substring(4);
                                            string date = day + "/" + month + "/" + year;
                                            dtpPassportExpire.Value = Convert.ToDateTime(date);
                                            break;
                                    }
                                }
                                grpPassport.Enabled = false;
                                break;
                            case "6": //driving license
                                txtDrivingLicense.Text = currentID.idparams[0].idvalue;
                                grpDrivingLicense.Enabled = false;    
                                break;
                        }
                    }
                }
            }

        }

        private void GetTitleList()
        {

            SqlConnection conn = ECSUtils.SysInfo.NewConnection();
            SqlCommand comm = new SqlCommand("GetTitleList", conn);
            comm.CommandType = CommandType.StoredProcedure;

            conn.Open();
            try
            {
                SqlDataReader dr = comm.ExecuteReader();

                while (dr.Read())
                {
                    cboTitle.Items.Add(((string)dr["titles"]).TrimEnd());
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("GetTitleList failed", ex);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public string AbodeNo
        {
            get { return txtAbodeNo.Text; }
        }
        public string BuildingNane
        {
            get { return txtBuildingName.Text; }
        }
        public string BuildingNo
        {
            get { return txtBuildingNo.Text; }
        }
        public string Line1
        {
            get { return txtLine1.Text; }
        }
        public string Line2
        {
            get { return txtLine2.Text; }
        }
        public string Line3
        {
            get { return txtLine3.Text; }
        }
        public string Village
        {
            get { return txtVillage.Text; }
        }
        public string Town
        {
            get { return txtTown.Text; }
        }
        public string PostCode
        {
            get { return txtPostcode.Text; }
        }

        public string Passport1
        {
            get { return txtPassport1.Text; }
        }
        public string Passport2
        {
            get { return txtPassport2.Text; }
        }
        public DateTime PassportExpiry
        {
            get { return dtpPassportExpire.Value; }
        }
        public string DrivingLicense
        {
            get { return txtDrivingLicense.Text; }
        }
        public string AliasTitle
        {
            get { return cboTitle.Text; }
        }
        public string AliasForenames
        {
            get { return txtForenames.Text; }
        }

        public string AliasSurname
        {
            get { return txtSurname.Text; }
        }

        public bool PassportEnabled
        {
            get { return grpPassport.Enabled; }
        }

        public bool DrivingLicenseEnabled
        {
            get { return grpDrivingLicense.Enabled; }
        }

        public bool DrivingLicensePhoto
        {
            get { return chkPhotograph.Checked; }
        }

        private void frmConfirmAddress_Load(object sender, EventArgs e)
        {

        }

    }
}