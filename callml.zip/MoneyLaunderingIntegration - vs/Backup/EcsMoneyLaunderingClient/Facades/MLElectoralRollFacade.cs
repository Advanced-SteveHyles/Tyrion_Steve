using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.MoneyLaundering
{
    public class MLElectoralRollFacade
    {
        CallML.resident m_Resident;
        public MLElectoralRollFacade(CallML.resident Resident)
        {
            m_Resident = Resident;
        }
        
        internal static string AppendWithDelimiter(string CurrentString, string AppendString, string Delimiter)
        {
            if (String.IsNullOrEmpty(AppendString))
            {
                return CurrentString;
            }
            else
            {
                if (String.IsNullOrEmpty(CurrentString))
                {
                    return AppendString;
                }
                else
                {
                    return CurrentString + Delimiter + AppendString;
                }
            }
        }

        public string ResidentName
        {
            get
            {
                string result = "";
                
                result = MLResultFacade.AppendWithDelimiter(result, m_Resident.name.title, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Resident.name.forename, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Resident.name.surname, " ");
            
                return result;
            }
        }

        public string DateRange
        {
            get
            {
                string result = m_Resident.startdate.Month + "/" + m_Resident.startdate.Year;

                if (m_Resident.enddate.Year == 1)
                {
                    result = result + " to present day";
                }
                else
                {
                    result = result + " to " + m_Resident.enddate.Month + "/" + m_Resident.enddate.Year;
                }

                return result;
            }
        }

        public int LORDays
        {
            get
            {               
                TimeSpan diffResult = DateTime.Now - m_Resident.startdate;

                return diffResult.Days;
            }
        }
        
        public string MatchType
        {
            get
            {
                string result = "";

                switch (m_Resident.matchtype)
                {
                    case CallML.enAppMatch.CM:
                        result = "CM";
                        break;
                    case CallML.enAppMatch.HM:
                        result = "HM";
                        break;
                    case CallML.enAppMatch.IM:
                        result = "IM";
                        break;
                    case CallML.enAppMatch.NM:
                        result = "NM";
                        break;
                    case CallML.enAppMatch.SM:
                        result = "SM";
                        break;
                }
                return result;

            }
        }


        public string ResidentType
        {
            get
            {
                return m_Resident.samefamilytype;
            }
        }
        

    }
}
