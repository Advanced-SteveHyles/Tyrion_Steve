using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.MoneyLaundering
{
    public class MLUKInvestorsFacade
    {
        private CallML.ukinvestorrecord m_UKInvestor;
        public MLUKInvestorsFacade(CallML.ukinvestorrecord UKInvestor)
        {
            m_UKInvestor = UKInvestor;
        }

        public string Name
        {
            get
            {
                string result = "";
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.title, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.forename, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.surname, " ");
                return result;
            }
        }

        public string Address
        {
            get
            {
                string result = "";
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.abode, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.housename, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.housenum, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.street1, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.street2, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.sublocality, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.locality, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.town, ", ");
                result = MLResultFacade.AppendWithDelimiter(result, m_UKInvestor.postcode, ", ");
                return result;
            }
        }

        public string Companies
        {
            get
            {
                // TODO : CSV list - do we parse it?
                return m_UKInvestor.companies;
            }
        }

        public bool UsedInDecision
        {
            get
            {
                return m_UKInvestor.usedindecision;
            }
        }
    }
}
