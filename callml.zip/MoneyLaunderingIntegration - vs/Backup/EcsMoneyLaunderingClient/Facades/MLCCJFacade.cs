using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.MoneyLaundering
{
    public class MLCCJFacade
    {
        CallML.judgment m_CCJ;
        public MLCCJFacade(CallML.judgment CCJ)
        {
            m_CCJ = CCJ;
        }

        public string Name
        {
            get
            {
                string result = "";
                result = MLResultFacade.AppendWithDelimiter(result, m_CCJ.title, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_CCJ.forename, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_CCJ.othernames, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_CCJ.surname, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_CCJ.suffix, " ");
                return result;
            }
        }

        public string Address
        {
            get
            {
                return m_CCJ.address;
            }
        }

        public string CourtName
        {
            get
            {
                return m_CCJ.courtname;
            }
        }

        public string CaseNumber
        {
            get
            {
                return m_CCJ.casenumber;
            }
        }

        public bool UsedInDecision
        {
            get
            {
                return m_CCJ.usedindecision;
            }
        }

        public string LORWarning
        {
            get
            {
                ////return m_CCJ.lorwarning;
                //if (m_CCJ..lorwarning)
                //{
                //    return "Warning! The applicant's data above has been active less than a year";
                //}
                //else
                //{
                    return "";
                //}
            }
        }
    }
}
