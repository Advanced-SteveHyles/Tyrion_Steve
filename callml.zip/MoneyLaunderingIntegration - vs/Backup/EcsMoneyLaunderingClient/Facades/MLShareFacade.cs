using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.MoneyLaundering
{
    public class MLShareFacade
    {
        CallML.sharerecord m_Account;
        public MLShareFacade(CallML.sharerecord Account)
        {
            m_Account = Account;
        }

        public string Name

        {
            get
            {
                string result = "";
                result = MLResultFacade.AppendWithDelimiter(result, m_Account.shareholderdetails.title, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Account.shareholderdetails.forename, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Account.shareholderdetails.forename2, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Account.shareholderdetails.surname, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Account.shareholderdetails.suffix, " ");
                return result;
            }
        }

        public string Address
        {
            get
            {
                return m_Account.shareholderdetails.address;
            }
        }

        public string AccountHolderStatus
        {
            get
            {
                switch (m_Account.shareholderdetails.statuscode)
                {
                    case "D":
                        return "Deceased";
                    case "G":
                        return "Gone Away";
                    case "N":
                        return "Normal";
                    case "P":
                        return "Guardian/Power of Attorney";
                    case "U":
                        return "Uncontactable";
                    default:
                        return "";
                }
            }
        }

        public string AccountTypeGroup
        {
            get
            {
                switch (m_Account.sharedetails.acctypegroup)
                {
                    case "1":
                        return "Loan & Instalment Credit";
                    case "2":
                        return "Mortgage";
                    case "3":
                        return "Revolving Credit & Budget";
                    case "4":
                        return "Telecommunications";
                    case "5":
                        return "Utilities";
                    case "6":
                        return "Home Shopping";
                    case "7":
                        return "Bank";
                    case "8":
                        return "Miscellaneous";
                    case "9":
                        return "Insurance";
                    case "10":
                        return "Internet";
                    default:
                        return m_Account.sharedetails.acctypegroup;
                }
            }
        }

        public string AccountTypeCode
        {
            get
            {
                switch (m_Account.sharedetails.acctypecode)
                {
                    case "LN":
                        return "Loan (unspecified type)";
                    case "UL":
                        return "Unsecured Loan";
                    case "BA":
                        return "Balloon Repayment Loan";
                    case "FD":
                        return "Fixed Term Deferred Payment loan";
                    case "SL":
                        return "Student Loan";
                    case "CP":
                        return "Personal Contract Purchase";
                    case "RG":
                        return "Repayment Grant";
                    case "TL":
                        return "Term Loan";
                    case "ML":
                        return "Motor Finance Loan - General";
                    case "CS":
                        return "Unsecured Car Loan";
                    case "SC":
                        return "Secured Car Loan";
                    case "BL":
                        return "Unsecured Business Loan";
                    case "SB":
                        return "Secured Business Loan";
                    case "LP":
                        return "Life Policy Loan";
                    case "ZL":
                        return "0% Finance Loan";
                    case "BR":
                        return "Brewery Loan";
                    case "PL":
                        return "Petroleum Loan";
                    case "BN":
                        return "Buy Now Pay Later";
                    case "EL":
                        return "Employer Loan";
                    case "FS":
                        return "Further Secured Loan";
                    case "SO":
                        return "Set Off Loan";
                    case "IL":
                        return "Advance Against Income";
                    case "HP":
                        return "Hire Purchase";
                    case "BH":
                        return "Balloon HP";
                    case "DH":
                        return "Deferred HP";
                    case "ZH":
                        return "0% HP";
                    case "CX":
                        return "Credit Sale";
                    case "CY":
                        return "Conditional Sale";
                    case "RT":
                        return "Rental Agreement (General)";
                    case "CR":
                        return "Consumer Goods Rental";
                    case "PR":
                        return "Property Rental";
                    case "LS":
                        return "Lease";
                    case "FL":
                        return "Finance Lease";
                    case "OL":
                        return "Operating Lease";
                    case "MG":
                        return "Mortgage (unspecified type)";
                    case "RM":
                        return "Residential Mortgage";
                    case "FM":
                        return "Flexible Mortgage";
                    case "CM":
                        return "Commercial Mortgage";
                    case "BM":
                        return "Residential Buy to Let";
                    case "XM":
                        return "Residential First Time Buyer";
                    case "FO":
                        return "Residential First Mortgage with Investment";
                    case "Offse":
                        return "t";
                    case "IM":
                        return "Residential Second Mortgage with";
                    case "Investment":
                        return "Offset";
                    case "SM":
                        return "Residential Second Mortgage";
                    case "MM":
                        return "Semi-commercial first mortgage";
                    case "NM":
                        return "Semi-commercial second mortgage";
                    case "DM":
                        return "Shared Ownership Mortgage (Housing Association)";
                    case "CC":
                        return "Credit Card";
                    case "CO":
                        return "Company Credit Card (individual responsible for debt)";
                    case "ST":
                        return "Store Card";
                    case "RS":
                        return "Retail Store Card";
                    case "FC":
                        return "Fuel Card (individual responsible for debt)";
                    case "CH":
                        return "Charge Card";
                    case "BD":
                        return "Budget Account";
                    case "TM":
                        return "Telecommunications Supplier";
                    case "AM":
                        return "Airtime Agreement - mthly contract";
                    case "AU":
                        return "Airtime Agreement - upfront";
                    case "QA":
                        return "Airtime Agreement - qtly payment";
                    case "LT":
                        return "Landline Telephone - even payment";
                    case "QT":
                        return "Landline Telephone - qtly payment";
                    case "UT":
                        return "Utility";
                    case "UE":
                        return "Utility - even payment";
                    case "QU":
                        return "Utility - qtly payment";
                    case "GE":
                        return "Gas - even payment";
                    case "QG":
                        return "Gas - qtly payment";
                    case "EE":
                        return "Electricity - even payment";
                    case "QE":
                        return "Electricity - qtly payment";
                    case "EW":
                        return "Water - even payment";
                    case "QW":
                        return "Water - qtly payment";
                    case "HS":
                        return "Home Shopping";
                    case "MO":
                        return "Mail Order";
                    case "MA":
                        return "Mail Order Agency";
                    case "TV":
                        return "TV Shopping";
                    case "HC":
                        return "Home Credit";
                    case "HD":
                        return "Home Shopping Direct";
                    case "HX":
                        return "Home Shopping Cash";
                    case "HA":
                        return "Home Shopping Agency";
                    case "WI":
                        return "Weekly Instalment Plan";
                    case "BC":
                        return "Book/Music/Video club";
                    case "CA":
                        return "Current Account";
                    case "OD":
                        return "Overdraft";
                    case "DC":
                        return "Debit Card";
                    case "SX":
                        return "Set Off Current Account";
                    case "RQ":
                        return "Returned Cheque";
                    case "BK":
                        return "Bank";
                    case "DF":
                        return "Bank Default";
                    case "MC":
                        return "Multifunctional Card";
                    case "OA":
                        return "Option Account";
                    case "SA":
                        return "Stock broking Account";
                    case "EC":
                        return "E-Cash";
                    case "CT":
                        return "Council Tax";
                    case "LR":
                        return "Local Rates - even payment scheme";
                    case "ZC":
                        return "Standby Credit";
                    case "CZ":
                        return "Combined Credit Accounts";
                    case "AF":
                        return "Agricultural Finance";
                    case "AD":
                        return "Asset Discounting";
                    case "BX":
                        return "Builders Merchant Credit";
                    case "CD":
                        return "Crown Debt";
                    case "FT":
                        return "Factoring";
                    case "GL":
                        return "Guarantee Liability";
                    case "SS":
                        return "Stationery Supplier";
                    case "RC":
                        return "Revolving credit";
                    case "DP":
                        return "Deferred payment";
                    case "TR":
                        return "Trade Credit";
                    case "VS":
                        return "Variable Subscription";
                    case "IN":
                        return "Insurance";
                    case "GI":
                        return "General Insurance";
                    case "BI":
                        return "Buildings Insurance";
                    case "CI":
                        return "Contents Insurance";
                    case "HI":
                        return "Household Insurance";
                    case "MI":
                        return "Motor Insurance";
                    case "PI":
                        return "Personal Health Insurance";
                    case "IC":
                        return "Internet Credit Line";
                    case "IS":
                        return "Internet Shopping";
                    default:
                        return m_Account.sharedetails.acctypecode;
                }
            }
        }

        public string DateOfBirthMatch
        {
            get
            {
                switch (m_Account.shareholderdetails.dobmatch)
                {
                    case 1:
                        return "No Date of Birth entered";
                    case 2:
                        return "Input Date of Birth matches returned SHARE Date of Birth";
                    case 3:
                        return "Input Date of Birth does not match returned SHARE Date of Birth";
                    case 4:
                        return "The SHARE record is not valid for Money Laundering purposes"; 
                    case 5:
                        return "No Date of Birth on SHARE data";
                    default:
                        return "";
                }
            }
        }

        public string DateOfBirth
        {
            get
            {

                DateTime theDate;

                if (m_Account.shareholderdetails.dob != null)
                {
                    theDate = DateTime.Parse(m_Account.shareholderdetails.dob);
                    return theDate.ToShortDateString();
                }
                else
                    return "";

            }
        }

        public string LORWarning
        {
            get
            {
                //return m_Account.accholderdetails.lorwarning;
                if (m_Account.shareholderdetails.lorwarning)
                {
                    return "Warning! The applicant's SHARE data has been active less than a year";
                }
                else
                {
                    return "";
                }
            }
        }

        public bool UsedInDecision
        {
            get
            {
                return m_Account.usedindecision;
            }
        }
    }
}
