using System;
using System.Collections.Generic;
using System.Text;

namespace ECS.MoneyLaundering
{
    public class MLInsolvenciesFacade
    {
        private CallML.bairecord m_Insolvency;
        public MLInsolvenciesFacade(CallML.bairecord Insolvency)
        {
            m_Insolvency = Insolvency;
        }
        
        public string Name
        {
            get
            {

                string result = "";
                result = MLResultFacade.AppendWithDelimiter(result, m_Insolvency.title, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Insolvency.forename, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Insolvency.othernames, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Insolvency.surname, " ");
                result = MLResultFacade.AppendWithDelimiter(result, m_Insolvency.suffix, " ");
                return result;
            }
        }

        public string Address
        {
            get
            {
                //TODO : This is an XML Block!!
                return m_Insolvency.address;
            }
        }

        public string CourtName
        {
            get
            {
                return m_Insolvency.courtname;
            }
        }

        public string OrderType
        {
            get
            {
                switch (m_Insolvency.ordertype)
                {
                    case "BO":
                        return "Bankruptcy Order";
                    case "ES":
                        return "Sequestration";
                    case "TD":
                        return "Trust Deeds";
                    case "IV":
                        return "Individual Voluntary Arrangement";
                    default:
                        return "";
                }
            }
        }

        public bool UsedInDecision
        {
            get
            {
                return m_Insolvency.usedindecision;
            }
        }

        public string LORWarning
        {
            get
            {
                //return m_Insolvency.lorwarning;
                return "";
            }
        }
    }
}
