using System;
using System.Collections.Generic;
using System.Text;
using ECS.MoneyLaundering.CallML;

namespace ECS.MoneyLaundering
{
    public class MLResultFacade
    {
        CallML.callmlsearch6 m_Search;
        CallML.resident m_Resident;
        CallML.errecord m_CurrentElectoralRoll;
        CallML.erhistoryitem m_ElectoralRollHistory;

        public MLResultFacade(CallML.callmlsearch6 Search)
        {
            m_Search = Search;

            // Find the current electoral role record
            m_CurrentElectoralRoll = null;
            m_ElectoralRollHistory = null;
            foreach (CallML.errecord erItem in m_Search.results.errecords)
            {
               
                if (erItem.currentaddress)
                {
                    m_CurrentElectoralRoll = erItem;

                    foreach(resident person in erItem.residents)
                    {
                        //if (person.name == m_Search.parameters.primarysearch.applicant.name)
                        if (person.matchtype == enAppMatch.IM)
                        {
                            m_Resident = person;
                            m_ElectoralRollHistory = person.erhistory[0];
                            break;  // break out of for loop
                        }

                        //if (person.name.forename.ToUpper() == m_Search.parameters.primarysearch.applicant.name.forename.ToUpper()
                        //&& person.name.surname.ToUpper() == m_Search.parameters.primarysearch.applicant.name.surname.ToUpper())

                        //{
                        //    m_Resident = person;
                        //    m_ElectoralRollHistory = person.erhistory[0];
                        //    //don't break out of loop, there might be another...
                        //}

                    }

                }
            }
        }

        public string InputName
        {
            get
            {
                CallML.name mlname = m_Search.parameters.primarysearch.applicant.name;
                string result = mlname.title.Trim();
                result = AppendWithDelimiter(result, mlname.forename, " ");
                result = AppendWithDelimiter(result, mlname.othernames, " ");
                result = AppendWithDelimiter(result, mlname.surname, " ");

                if (m_Search.parameters.primarysearch.applicant.aliases != null)
                {
                    CallML.name alias = m_Search.parameters.primarysearch.applicant.aliases[0];

                    result = result + " (Alias: " + alias.title.Trim();
                    result = AppendWithDelimiter(result, alias.forename, " ");
                    result = AppendWithDelimiter(result, alias.othernames, " ");
                    result = AppendWithDelimiter(result, alias.surname, " ");
                    result = result + ")";
                }

                return result;
            }
        }

        public string InputDOB
        {
            get
            {
                CallML.applicant mlapplicant = m_Search.parameters.primarysearch.applicant;
                string result = "Not entered";
                if (mlapplicant.dob.Year != 1)
                    result = mlapplicant.dob.ToShortDateString();
                return result;
            }
        }

        public string InputAddress
        {
            get
            {
                return GetFormattedAddress(m_Search.parameters.primarysearch.applicant.currentaddress);
            }
        }

        public DateTime SearchDate
        {
            get
            {
                return DateTime.Parse(m_Search.results.searchdate);
            }
        }

        public string SearchID
        {
            get
            {
                return m_Search.results.searchid;
            }
        }

        public int NumberOfPrimaryChecks
        {
            get
            {
                return m_Search.results.numprimarychecks;
            }
        }

        public int NumberOfPrimaryChecksConfirmed
        {
            get
            {
                return m_Search.results.numcorroborativechecks;
            }
        }

        public int NumberOfSHAREChecks
        {
            get
            {
                return m_Search.results.numprimaryshareidsconfirmed;
            }
        }

        public int NumberOfSHAREChecksConfirmed
        {
            get
            {
                return m_Search.results.numcorroborativeshareidsconfirmed;
            }
        }

        public int NumberOfIDChecks
        {
            get
            {
                return m_Search.results.numprimaryotheridsconfirmed;
            }
        }

        public int NumberOfIDChecksConfirmed
        {
            get
            {
                return m_Search.results.numcorroborativeotheridsconfirmed;
            }
        }

        public string ApplicantVerified
        {
            get
            {
                string result = "";
                
                result = m_Search.results.appverified.ToUpper();

                //if (result.EndsWith("WARNING PRESENT!"))
                //    result = result + WarningInfo();

                return result;
            }
        }

        public string DOBMatch
        {
            get
            {
                string result = m_Search.results.confirmatorydobs.ToString() +
                           "/" + m_Search.results.totaldobs.ToString();

                if (result == "0/0")
                    result = "Not Applicable";
                return result;
            }
        }

        public string WarningInfo
        {
            get
            {
                string sReturn = "";

                switch (m_Search.results.matchlevel)
                {
                    case enReportType.NoMatchFound:
                        sReturn = sReturn + "\nNo match found for " + InputName + " at " + InputAddress;
                        break;
                    case enReportType.SurnameReport:
                        sReturn = sReturn + "\nSurname match level for " + InputName + " at " + InputAddress;
                        break;
                    case enReportType.TooManyMatches:
                        sReturn = sReturn + "\nToo many matches found for " + InputName;
                        break;
                    case enReportType.NonDomicileMatch:
                        sReturn = sReturn + "\nNon-domicile match found for " + InputName;
                        break;
                    case enReportType.AddressReport:
                        sReturn = sReturn + "\nAddress match only - " + InputName + " not found at matched address";
                        break;
                }

                if (m_Search.results.pepwarning)
                    sReturn = sReturn + "\nMatch found on the 'Politically Exposed People' Database";
                if (m_Search.results.sdnwarning)
                    sReturn = sReturn + "\nMatch found on the 'OFAC Specially Designated Nationals' Database";
                if (m_Search.results.sanctionswarning)
                    sReturn = sReturn + "\nMatch found on the 'Bank of England Sanctions' Database";
                if (m_Search.results.deceasedwarning)
                    sReturn = sReturn + "\n" + InputName + " matches to the deceased data file";
                if (m_Search.results.addresswarning)
                    sReturn = sReturn + "\n" + InputAddress + " matches to the 'Non-Standard Address' database";
                if (m_Search.results.addresslinkswarning)
                    sReturn = sReturn + "\nForwarding address links have been found for this applicant";
                if (m_Search.results.dvlawarning)
                    sReturn = sReturn + "\nDriving License details resulted in a mismatch";
                if (m_Search.results.passportwarning)
                    sReturn = sReturn + "\nPassport numbers provided resulted in a mismatch";
                if (m_Search.results.fraudulentpassportwarning)
                    sReturn = sReturn + "\nPassport identity details match to the fraudulent passport database";
                if (m_Search.results.goneawaywarning)
                    sReturn = sReturn + "\n" + InputName + " matches to the 'Gone Away' file";

                if (m_CurrentElectoralRoll != null)
                {
                    if (m_CurrentElectoralRoll.lorwarning)
                        sReturn = sReturn + "\nElectoral Roll data is less than 12 months old";
                }
                if (sReturn != "")
                    sReturn = sReturn.Substring(1);

                return sReturn;
            }
        }

        public string FoundName
        {
            get
            {
                string result;
                if (m_Resident == null)
                {
                    result = "Applicant not found on Electoral Roll";
                }
                else
                {
                    result = "";
                    result = AppendWithDelimiter(result, m_Resident.name.forename, " ");
                    result = AppendWithDelimiter(result, m_Resident.name.othernames, " ");
                    result = AppendWithDelimiter(result, m_Resident.name.surname, " ");
                    if (m_Resident.currentname == 0)
                        result = result + " (" + m_Resident.individualtype + ")";
                }
                return result;
            }
        }

        public string FoundAddress
        {
            get
            {
                string result;
                if (m_CurrentElectoralRoll == null)
                {
                    result = "Address not found on Electoral Roll"; 
                }
                else
                {
                    if (m_CurrentElectoralRoll.address == null)
                    {
                        result = "Address not found on Electoral Roll";
                    }
                    else
                    {
                        result = GetFormattedAddress(m_CurrentElectoralRoll.address);
                    }
                }
                return result;
            }
        }

        public bool FoundResidents
        {
            get
            {
                bool result = false;
                if (m_CurrentElectoralRoll != null)
                {
                    if (m_CurrentElectoralRoll.residents.Length > 0)
                        result = true;
                }

                return result;
            }
        }

        public string ElectoralRollFrom
        {
            get
            {
                if (m_ElectoralRollHistory == null)
                {
                    return "Unknown";
                }
                else
                {
                    return m_ElectoralRollHistory.startdate.Month + "/" + m_ElectoralRollHistory.startdate.Year;
                }
            }
        }

        public string ElectoralRollTo
        {
            get
            {
                string result;
                if (m_ElectoralRollHistory == null)
                {
                    result = "Unknown";
                }
                else
                {
                    if (m_ElectoralRollHistory.enddate.Ticks == 0)
                    {
                        result = DateTime.Today.Month + "/" + DateTime.Today.Year;
                    }
                    else
                    {
                        result = m_ElectoralRollHistory.enddate.Month + "/" + m_ElectoralRollHistory.enddate.Year;
                    }
                }
                return result;
            }
        }

        public string ElectoralRollType
        {
            get
            {
                string result;
                if (m_ElectoralRollHistory == null)
                {
                    result = "";
                }
                else
                {
                    switch (m_ElectoralRollHistory.rollingroll)
                    {
                        case 0:
                            result = "Annual Electoral Roll";
                            break;
                        case 1:
                            result = "Monthly Rolling Electoral Roll";
                            break;
                        default:
                            result = "";
                            break;
                    }
                }
                return result;
            }
        }

        public bool ElectoralRollUsedInDecision
        {
            get
            {
                if (m_CurrentElectoralRoll == null)
                {
                    return false;
                }
                else
                {
                    return m_CurrentElectoralRoll.usedindecision;
                }
            }
        }

        public bool AddressConfirmed
        {
            get
            {
                foreach (paf postOffice in m_Search.results.pafs)
                {
                    if (postOffice.pafvalid) return true;
                }

                return false;
            }
        }

        private string GetFormattedAddress(CallML.address Address)
        {
            string result = "";
            result = AppendWithDelimiter(result, Address.premiseno, ", ");
            result = AppendWithDelimiter(result, Address.premisename, ", ");
            result = AppendWithDelimiter(result, Address.abodeno, ", ");
            result = AppendWithDelimiter(result, Address.buildingname, ", ");
            result = AppendWithDelimiter(result, Address.buildingno, ", ");
            result = AppendWithDelimiter(result, Address.street1, ", ");
            result = AppendWithDelimiter(result, Address.street2, ", ");
            result = AppendWithDelimiter(result, Address.sublocality, ", ");
            result = AppendWithDelimiter(result, Address.locality, ", ");
            result = AppendWithDelimiter(result, Address.posttown, ", ");
            result = AppendWithDelimiter(result, Address.postcode, ", ");
            return result;
        }

        internal static string AppendWithDelimiter(string CurrentString, string AppendString, string Delimiter)
        {
            if (String.IsNullOrEmpty(AppendString))
            {
                return CurrentString;
            }
            else
            {
                if (String.IsNullOrEmpty(CurrentString))
                {
                    return AppendString;
                }
                else
                {
                    return CurrentString + Delimiter + AppendString;
                }
            }
        }

        public MLShareFacade[] ShareRecords
        {
            get
            {
                MLShareFacade[] result = new MLShareFacade[m_Search.results.sharerecords.Length];
                int i = 0;
                foreach (CallML.sharerecord account in m_Search.results.sharerecords)
                {
                    result[i] = new MLShareFacade(account);
                    i++;
                }

                return result;
            }
        }

        public MLElectoralRollFacade[] ElectoralRollRecords
        {
            get
            {
                MLElectoralRollFacade[] result = new MLElectoralRollFacade[0];
                if (m_CurrentElectoralRoll != null)
                {
                    result = new MLElectoralRollFacade[m_CurrentElectoralRoll.residents.Length];
                    int i = 0;

                    foreach (CallML.resident resident in m_CurrentElectoralRoll.residents)
                    {
                        result[i] = new MLElectoralRollFacade(resident);
                        i++;
                    }
                }

                return result;
            }
        }

        public MLInsolvenciesFacade[] Insolvencies
        {
            get
            {
                MLInsolvenciesFacade[] result = new MLInsolvenciesFacade[m_Search.results.bairecords.Length];
                int i = 0;
                foreach (CallML.bairecord insolvency in m_Search.results.bairecords)
                {
                    result[i] = new MLInsolvenciesFacade(insolvency);
                    i++;
                }

                return result;
            }
        }

        public MLCCJFacade[] CCJs
        {
            get
            {
                MLCCJFacade[] result = new MLCCJFacade[m_Search.results.judgments.Length];
                int i = 0;
                foreach (CallML.judgment ccj in m_Search.results.judgments)
                {
                    result[i] = new MLCCJFacade(ccj);
                    i++;
                }

                return result;
            }
        }

        public MLUKInvestorsFacade[] UKInvestors
        {
            get
            {
                MLUKInvestorsFacade[] result = new MLUKInvestorsFacade[m_Search.results.ukinvestorrecords.Length];
                int i = 0;
                foreach (CallML.ukinvestorrecord ftse in m_Search.results.ukinvestorrecords)
                {
                    result[i] = new MLUKInvestorsFacade(ftse);
                    i++;
                }

                return result;
            }
        }

        public bool IsDirector
        {
            get { return m_Search.results.otherdata.director.surname != null; }
        }
        
        public string DirectorName
        {
            get
            {
                string result = "";
                if (IsDirector)
                {
                    result = AppendWithDelimiter(result, m_Search.results.otherdata.director.forename, " ");
                    result = AppendWithDelimiter(result, m_Search.results.otherdata.director.othernames, " ");
                    result = AppendWithDelimiter(result, m_Search.results.otherdata.director.surname, " ");
                }
                return result;
            }
        }

        public string DirectorAddress
        {
            get
            {
                string result = "";
                if (IsDirector)
                {
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.abodeno, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.buildingname, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.buildingno, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.street1, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.street2, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.sublocality, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.locality, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.posttown, ", ");
                    result = MLResultFacade.AppendWithDelimiter(result, m_Search.results.otherdata.director.postcode, ", ");
                }
                return result;
            }
        }

        public string CompanyName
        {
            get
            {
                string result = "";
                if (IsDirector)
                {
                    //int index = m_Search.results.otherdata.director.companydetails.LastIndexOf('[');
                    //if (index == -1)
                        result = m_Search.results.otherdata.director.companydetails;
                    //else
                    //    result = m_Search.results.otherdata.director.companydetails.Substring(0, index);
                }
                return result;
            }
        }

        public string CompanyRegisteredNumber
        {
            get
            {
                string result = "";
                if (IsDirector)
                {
                    int startIndex = m_Search.results.otherdata.director.companydetails.LastIndexOf('[');
                    int stopIndex = m_Search.results.otherdata.director.companydetails.LastIndexOf(']');
                    if (startIndex == -1)
                        result = "";
                    else
                        result = m_Search.results.otherdata.director.companydetails.Substring(startIndex, stopIndex - startIndex);
                }
                return result;
            }
        }

        public bool PEPWarning
        {
            get
            {
                return m_Search.results.pepwarning;
            }
        }

        public bool SDNWarning
        {
            get
            {
                return m_Search.results.sdnwarning;
            }
        }

        public bool BESWarning
        {
            get
            {
                return m_Search.results.sanctionswarning;
            }
        }

        public int LevelOfConfidenceERCurrentAddress
        {
            get
            {
                // return level of confidence as a percentage
                return m_Search.results.furtherdetails.levelofconfidenceer.currentaddresslevel * 20;
            }
        }

        public int LevelOfConfidenceShareCurrentAddress
        {
            get
            {
                // return level of confidence as a percentage
                return m_Search.results.furtherdetails.levelofconfidenceshare.currentaddresslevel * 20;
            }
        }

        public int LevelOfConfidenceDOB
        {
            get
            {
                // return level of confidence as a percentage
                switch (m_Search.results.furtherdetails.levelofconfidencedob)
                {
                    case 1:
                        return 33;
                    case 2:
                        return 66;
                    case 3 :
                        return 100;
                    default:
                        return 0;
                }
            }
        }

        public int LevelOfConfidenceCCJ
        {
            get
            {
                // return level of confidence as a percentage
                switch (m_Search.results.furtherdetails.levelofconfidenceccj)
                {
                    case 1:
                        return 33;
                    case 2:
                        return 66;
                    case 3:
                        return 100;
                    default:
                        return 0;
                }
            }
        }

        public int LevelOfConfidenceInsolvencies
        {
            get
            {
                // return level of confidence as a percentage
                return m_Search.results.furtherdetails.levelofconfidencebai * 50;
            }
        }

        public int LevelOfConfidenceUKInvestors
        {
            get
            {
                // return level of confidence as a percentage
                switch (m_Search.results.furtherdetails.levelofconfidenceftse)
                {
                    case 1:
                        return 33;
                    case 2:
                        return 66;
                    case 3:
                        return 100;
                    default:
                        return 0;
                }
            }
        }

        public string LORWarning
        {
            get
            {

                if (m_CurrentElectoralRoll != null)
                {
                    if (m_CurrentElectoralRoll.lorwarning)
                    {
                        return "Warning! The applicant's data has been active less than a year";
                    }
                    else
                    {
                        return "";
                    }
                }
                else { return "";  }
            }
        }

        // ******** Passport Info *********
        public string PassportCountry
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.passport != null)
                    result = m_Search.results.furtherdetails.passport.issuingcountry;

                return result;
            }
        }

        public string PassportNationality
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.passport != null)
                    result = m_Search.results.furtherdetails.passport.nationality;

                return result;
            }
        }

        public string PassportSurnameMatch
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.surnamematch)
                        result = "OK";
                    else 
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportForenameMatch
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.forenamematch)
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }
        
        public string PassportMiddleNameMatch
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.middlenamematch)
                       result = "OK";
                    else
                       result = "FAIL";
               }
                return result;
            }
        }

        public string PassportDOBDay
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.dobdaymatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }
       
        public string PassportDOBMonth
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.dobmonthmatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportDOBYear
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.dobyearmatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportCheckDigit1
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.checkDigit1Match)
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportCheckDigit2
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.checkDigit2Match)
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportCheckDigit3
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.checkDigit3Match)
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportCheckDigit4
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.checkDigit4Match)
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string PassportCheckDigit5
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.passport != null)
                {
                    if (m_Search.results.furtherdetails.passport.checkDigit5Match)
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }

        public string DrivingSurname
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.drivinglicence != null)
                {
                    if (m_Search.results.furtherdetails.drivinglicence.surnamematch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }
        public string DrivingInitial
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.drivinglicence != null)
                {
                    if (m_Search.results.furtherdetails.drivinglicence.initialmatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }
        public string DrivingOtherName
        {
            get
            {
                string result = "";

                if (m_Search.results.furtherdetails.drivinglicence != null)
                {
                    if (m_Search.results.furtherdetails.drivinglicence.othernamematch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }
                return result;
            }
        }
        public string DrivingDOBDay
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.drivinglicence != null)
                {
                    if (m_Search.results.furtherdetails.drivinglicence.dobdaymatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }

                return result;
            }
        }
        public string DrivingDOBMonth
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.drivinglicence != null)
                {
                    if (m_Search.results.furtherdetails.drivinglicence.dobmonthmatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }

                return result;
            }
        }
        public string DrivingDOBYear
        {
            get
            {
                string result = "";
                if (m_Search.results.furtherdetails.drivinglicence != null)
                {
                    if (m_Search.results.furtherdetails.drivinglicence.dobyearmatch == "true")
                        result = "OK";
                    else
                        result = "FAIL";
                }

                return result;
            }
        }


        // ******** Driving License Info *********

    }
}
