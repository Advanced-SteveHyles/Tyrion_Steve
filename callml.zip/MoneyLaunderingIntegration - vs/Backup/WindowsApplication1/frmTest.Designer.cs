namespace ECS.MoneyLaunderingTestHarness
{
    partial class frmTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTest));
            this.tbParent = new System.Windows.Forms.TabControl();
            this.tbError = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblEntityID = new System.Windows.Forms.Label();
            this.btnInvoke = new System.Windows.Forms.Button();
            this.txtEntityID = new System.Windows.Forms.TextBox();
            this.txtOutput = new System.Windows.Forms.RichTextBox();
            this.tbCallMLWS = new System.Windows.Forms.TabPage();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.txtOutput2 = new System.Windows.Forms.RichTextBox();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.txtOutput3 = new System.Windows.Forms.RichTextBox();
            this.tbParent.SuspendLayout();
            this.tbError.SuspendLayout();
            this.tbCallMLWS.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbParent
            // 
            this.tbParent.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tbParent.Controls.Add(this.tbError);
            this.tbParent.Controls.Add(this.tbCallMLWS);
            this.tbParent.Controls.Add(this.tabPage1);
            this.tbParent.Location = new System.Drawing.Point(12, 13);
            this.tbParent.Name = "tbParent";
            this.tbParent.SelectedIndex = 0;
            this.tbParent.Size = new System.Drawing.Size(618, 360);
            this.tbParent.TabIndex = 0;
            // 
            // tbError
            // 
            this.tbError.Controls.Add(this.label1);
            this.tbError.Controls.Add(this.textBox1);
            this.tbError.Controls.Add(this.button1);
            this.tbError.Controls.Add(this.lblEntityID);
            this.tbError.Controls.Add(this.btnInvoke);
            this.tbError.Controls.Add(this.txtEntityID);
            this.tbError.Controls.Add(this.txtOutput);
            this.tbError.Location = new System.Drawing.Point(4, 23);
            this.tbError.Name = "tbError";
            this.tbError.Padding = new System.Windows.Forms.Padding(3);
            this.tbError.Size = new System.Drawing.Size(610, 333);
            this.tbError.TabIndex = 0;
            this.tbError.Text = "Client Error Checking";
            this.tbError.UseVisualStyleBackColor = true;
            this.tbError.Click += new System.EventHandler(this.tbError_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(175, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 14);
            this.label1.TabIndex = 6;
            this.label1.Text = "Matter Entity ID:";
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(275, 45);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 22);
            this.textBox1.TabIndex = 5;
            this.textBox1.Text = "444991";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Location = new System.Drawing.Point(401, 46);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(162, 25);
            this.button1.TabIndex = 4;
            this.button1.Text = "Invoke case Plan level Fetch";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblEntityID
            // 
            this.lblEntityID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblEntityID.AutoSize = true;
            this.lblEntityID.Location = new System.Drawing.Point(214, 20);
            this.lblEntityID.Name = "lblEntityID";
            this.lblEntityID.Size = new System.Drawing.Size(55, 14);
            this.lblEntityID.TabIndex = 3;
            this.lblEntityID.Text = "Entity ID:";
            // 
            // btnInvoke
            // 
            this.btnInvoke.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInvoke.Location = new System.Drawing.Point(401, 17);
            this.btnInvoke.Name = "btnInvoke";
            this.btnInvoke.Size = new System.Drawing.Size(162, 25);
            this.btnInvoke.TabIndex = 2;
            this.btnInvoke.Text = "Invoke Database GetClient";
            this.btnInvoke.UseVisualStyleBackColor = true;
            this.btnInvoke.Click += new System.EventHandler(this.btnInvoke_Click);
            // 
            // txtEntityID
            // 
            this.txtEntityID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEntityID.Location = new System.Drawing.Point(275, 17);
            this.txtEntityID.Name = "txtEntityID";
            this.txtEntityID.Size = new System.Drawing.Size(120, 22);
            this.txtEntityID.TabIndex = 1;
            this.txtEntityID.Text = "444989";
            // 
            // txtOutput
            // 
            this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOutput.Location = new System.Drawing.Point(21, 77);
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.Size = new System.Drawing.Size(542, 232);
            this.txtOutput.TabIndex = 0;
            this.txtOutput.Text = "";
            // 
            // tbCallMLWS
            // 
            this.tbCallMLWS.Controls.Add(this.btnSubmit);
            this.tbCallMLWS.Controls.Add(this.txtOutput2);
            this.tbCallMLWS.Location = new System.Drawing.Point(4, 23);
            this.tbCallMLWS.Name = "tbCallMLWS";
            this.tbCallMLWS.Size = new System.Drawing.Size(610, 333);
            this.tbCallMLWS.TabIndex = 1;
            this.tbCallMLWS.Text = "CallMl Co-ordinator WebService";
            this.tbCallMLWS.UseVisualStyleBackColor = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.Location = new System.Drawing.Point(458, 307);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(152, 23);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.Text = "Invoke";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // txtOutput2
            // 
            this.txtOutput2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutput2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOutput2.Location = new System.Drawing.Point(3, 3);
            this.txtOutput2.Name = "txtOutput2";
            this.txtOutput2.Size = new System.Drawing.Size(604, 298);
            this.txtOutput2.TabIndex = 1;
            this.txtOutput2.Text = "";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.txtOutput3);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(610, 333);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Utilities";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(500, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "XslTransform";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // txtOutput3
            // 
            this.txtOutput3.Location = new System.Drawing.Point(6, 6);
            this.txtOutput3.Name = "txtOutput3";
            this.txtOutput3.Size = new System.Drawing.Size(488, 321);
            this.txtOutput3.TabIndex = 0;
            this.txtOutput3.Text = "";
            // 
            // frmTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 386);
            this.Controls.Add(this.tbParent);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmTest";
            this.Text = "Money Laundering Test Harness";
            this.tbParent.ResumeLayout(false);
            this.tbError.ResumeLayout(false);
            this.tbError.PerformLayout();
            this.tbCallMLWS.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbParent;
        private System.Windows.Forms.TabPage tbError;
        private System.Windows.Forms.Label lblEntityID;
        private System.Windows.Forms.Button btnInvoke;
        private System.Windows.Forms.TextBox txtEntityID;
        private System.Windows.Forms.RichTextBox txtOutput;
        private System.Windows.Forms.TabPage tbCallMLWS;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.RichTextBox txtOutput2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox txtOutput3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox1;
    }
}

