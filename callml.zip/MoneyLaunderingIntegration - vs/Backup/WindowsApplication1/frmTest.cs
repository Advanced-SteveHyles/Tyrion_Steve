using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using ECS.Utilities;

namespace ECS.MoneyLaunderingTestHarness
{
    public partial class frmTest : Form
    {
        MoneyLaundering.ECSCasePlanExecutor planner;
        MoneyLaundering.ECSDatabase database;
        //CallMLCoordinator.CallMLCoordinatorService m_svcCallML;

        public frmTest()
        {
            InitializeComponent();
            database = new ECS.MoneyLaundering.ECSDatabase(ECS.Global.ECSUtils.SysInfo);
            planner = new ECS.MoneyLaundering.ECSCasePlanExecutor();
            //m_svcCallML = new AIM.MoneyLaunderingTestHarness.CallMLCoordinator.CallMLCoordinatorService();
        }

        private void btnInvoke_Click(object sender, EventArgs e)
        {
            /*
            long ClientID = long.Parse(txtEntityID.Text);
            txtOutput.AppendText(database.GetClientData(ClientID, "AIM", "AIM")[0].OuterXml);
             * */
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int ClientID = int.Parse(txtEntityID.Text);
            int MatterID = int.Parse(textBox1.Text);
            txtOutput.AppendText(String.Format("Client {0} : {1}\n", ClientID, planner.PerformClientMLSearch(ClientID, MatterID)));
        }
        
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            /*
            XmlDocument oDoc = new XmlDocument();
            oDoc.LoadXml("<string>bling</string>");
            try
            {
                txtOutput2.AppendText("\n" + m_svcCallML.SubmitRequest((XmlNode)oDoc));
            }
            catch (Exception ex)
            {
                txtOutput2.AppendText(ex.Message);
            }
            */
        }
        private void button2_Click(object sender, EventArgs e)
        {
            XmlDocument output=null;
            string s = "<document>this is a document</document>";
            XmlUtilities.TransformXML(s, ref output, @"c:\Untitled2.xsl");
            txtOutput3.AppendText( output.OuterXml);
        }

        private void tbError_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}