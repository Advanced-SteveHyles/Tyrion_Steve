using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CallMLConfig
{
    public partial class NewUser : Form
    {
        public NewUser(string caption)
        {
            InitializeComponent();
            this.Text = caption;
        }

        private void btnOK_Click(object sender, EventArgs e)
        {

            // Check that new passwords match
            if (txtPassword.Text != txtConfirmPassword.Text)
            {
                MessageBox.Show("The passwords you typed do not match. Type the new password in both text boxes.", "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        public string CompanyName
        {
            get
            {
                return txtCompany.Text;
            }
        }
        public string UserName
        {
            get
            {
                return txtUser.Text;
            }
        }
        public string Password
        {
            get
            {
                return txtPassword.Text;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}