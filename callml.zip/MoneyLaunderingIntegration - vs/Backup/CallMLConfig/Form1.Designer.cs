namespace CallMLConfig
{
    partial class MLConfig
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MLConfig));
            this.txtURL = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCompanyName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cancelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.restoreDefaultsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spnDaysEligible = new System.Windows.Forms.NumericUpDown();
            this.spnMinChecks = new System.Windows.Forms.NumericUpDown();
            this.grpGeneral = new System.Windows.Forms.GroupBox();
            this.cbxElectoralRoll = new System.Windows.Forms.CheckBox();
            this.cbxSHARE = new System.Windows.Forms.CheckBox();
            this.cbxUseBAI = new System.Windows.Forms.CheckBox();
            this.cbxFTSE = new System.Windows.Forms.CheckBox();
            this.cbxCCJ = new System.Windows.Forms.CheckBox();
            this.cbxSearchDirectors = new System.Windows.Forms.CheckBox();
            this.grpPDFLinks = new System.Windows.Forms.GroupBox();
            this.btnUpdateHistory = new System.Windows.Forms.Button();
            this.cboPDFDate = new System.Windows.Forms.ComboBox();
            this.lblField = new System.Windows.Forms.Label();
            this.cboPDFScreen = new System.Windows.Forms.ComboBox();
            this.lblScreen = new System.Windows.Forms.Label();
            this.tabOptions = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.updPasswordReminder = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.cboPeriod = new System.Windows.Forms.ComboBox();
            this.spnSecurityLevel = new System.Windows.Forms.NumericUpDown();
            this.spnExpiryDays = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.grpMatchWarning = new System.Windows.Forms.GroupBox();
            this.chkWarnUKPassport = new System.Windows.Forms.CheckBox();
            this.chkWarnFraudPassport = new System.Windows.Forms.CheckBox();
            this.chkWarnDrivingLicense = new System.Windows.Forms.CheckBox();
            this.chkWarnResidency = new System.Windows.Forms.CheckBox();
            this.chkWarnDOBOne = new System.Windows.Forms.CheckBox();
            this.chkWarnDOBAll = new System.Windows.Forms.CheckBox();
            this.chkWarnAddressLinks = new System.Windows.Forms.CheckBox();
            this.chkWarnGoneAway = new System.Windows.Forms.CheckBox();
            this.chkWarnDeceased = new System.Windows.Forms.CheckBox();
            this.chkWarnPEP = new System.Windows.Forms.CheckBox();
            this.chkWarnCIFAS = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.pnlUtilities = new System.Windows.Forms.Panel();
            this.chkUE = new System.Windows.Forms.CheckBox();
            this.chkQU = new System.Windows.Forms.CheckBox();
            this.chkGE = new System.Windows.Forms.CheckBox();
            this.chkQG = new System.Windows.Forms.CheckBox();
            this.chkEE = new System.Windows.Forms.CheckBox();
            this.chkQE = new System.Windows.Forms.CheckBox();
            this.chkEW = new System.Windows.Forms.CheckBox();
            this.chkQW = new System.Windows.Forms.CheckBox();
            this.chkUT = new System.Windows.Forms.CheckBox();
            this.pnlTelecoms = new System.Windows.Forms.Panel();
            this.chkAM = new System.Windows.Forms.CheckBox();
            this.chkAU = new System.Windows.Forms.CheckBox();
            this.chkQA = new System.Windows.Forms.CheckBox();
            this.chkLT = new System.Windows.Forms.CheckBox();
            this.chkQT = new System.Windows.Forms.CheckBox();
            this.chkTM = new System.Windows.Forms.CheckBox();
            this.pnlMortgage = new System.Windows.Forms.Panel();
            this.chkFO = new System.Windows.Forms.CheckBox();
            this.chkRM = new System.Windows.Forms.CheckBox();
            this.chkIM = new System.Windows.Forms.CheckBox();
            this.chkMM = new System.Windows.Forms.CheckBox();
            this.chkFM = new System.Windows.Forms.CheckBox();
            this.chkCM = new System.Windows.Forms.CheckBox();
            this.chkBM = new System.Windows.Forms.CheckBox();
            this.chkXM = new System.Windows.Forms.CheckBox();
            this.chkSM = new System.Windows.Forms.CheckBox();
            this.chkNM = new System.Windows.Forms.CheckBox();
            this.chkDM = new System.Windows.Forms.CheckBox();
            this.chkMG = new System.Windows.Forms.CheckBox();
            this.pnlMiscellaneous = new System.Windows.Forms.Panel();
            this.chkOA = new System.Windows.Forms.CheckBox();
            this.chkSA = new System.Windows.Forms.CheckBox();
            this.chkEC = new System.Windows.Forms.CheckBox();
            this.chkCT = new System.Windows.Forms.CheckBox();
            this.chkLR = new System.Windows.Forms.CheckBox();
            this.chkAF = new System.Windows.Forms.CheckBox();
            this.chkCD = new System.Windows.Forms.CheckBox();
            this.chkFT = new System.Windows.Forms.CheckBox();
            this.chkRC = new System.Windows.Forms.CheckBox();
            this.chkDP = new System.Windows.Forms.CheckBox();
            this.chkZC = new System.Windows.Forms.CheckBox();
            this.chkCZ = new System.Windows.Forms.CheckBox();
            this.chkBX = new System.Windows.Forms.CheckBox();
            this.chkGL = new System.Windows.Forms.CheckBox();
            this.chkSS = new System.Windows.Forms.CheckBox();
            this.chkTR = new System.Windows.Forms.CheckBox();
            this.chkAD = new System.Windows.Forms.CheckBox();
            this.chkVS = new System.Windows.Forms.CheckBox();
            this.chkMC = new System.Windows.Forms.CheckBox();
            this.pnlLoan = new System.Windows.Forms.Panel();
            this.chkOL = new System.Windows.Forms.CheckBox();
            this.chkFL = new System.Windows.Forms.CheckBox();
            this.chkUL = new System.Windows.Forms.CheckBox();
            this.chkBA = new System.Windows.Forms.CheckBox();
            this.chkFD = new System.Windows.Forms.CheckBox();
            this.chkSL = new System.Windows.Forms.CheckBox();
            this.chkCP = new System.Windows.Forms.CheckBox();
            this.chkRG = new System.Windows.Forms.CheckBox();
            this.chkTL = new System.Windows.Forms.CheckBox();
            this.chkML = new System.Windows.Forms.CheckBox();
            this.chkCS = new System.Windows.Forms.CheckBox();
            this.chkSC = new System.Windows.Forms.CheckBox();
            this.chkBL = new System.Windows.Forms.CheckBox();
            this.chkSB = new System.Windows.Forms.CheckBox();
            this.chkLP = new System.Windows.Forms.CheckBox();
            this.chkZL = new System.Windows.Forms.CheckBox();
            this.chkPL = new System.Windows.Forms.CheckBox();
            this.chkBN = new System.Windows.Forms.CheckBox();
            this.chkEL = new System.Windows.Forms.CheckBox();
            this.chkFS = new System.Windows.Forms.CheckBox();
            this.chkSO = new System.Windows.Forms.CheckBox();
            this.chkHP = new System.Windows.Forms.CheckBox();
            this.chkBR = new System.Windows.Forms.CheckBox();
            this.chkLS = new System.Windows.Forms.CheckBox();
            this.chkZH = new System.Windows.Forms.CheckBox();
            this.chkPR = new System.Windows.Forms.CheckBox();
            this.chkIL = new System.Windows.Forms.CheckBox();
            this.chkBH = new System.Windows.Forms.CheckBox();
            this.chkCX = new System.Windows.Forms.CheckBox();
            this.chkCY = new System.Windows.Forms.CheckBox();
            this.chkRT = new System.Windows.Forms.CheckBox();
            this.chkCR = new System.Windows.Forms.CheckBox();
            this.chkDH = new System.Windows.Forms.CheckBox();
            this.chkLN = new System.Windows.Forms.CheckBox();
            this.pnlInternet = new System.Windows.Forms.Panel();
            this.chkIS = new System.Windows.Forms.CheckBox();
            this.chkIC = new System.Windows.Forms.CheckBox();
            this.pnlInsurance = new System.Windows.Forms.Panel();
            this.chkPI = new System.Windows.Forms.CheckBox();
            this.chkMI = new System.Windows.Forms.CheckBox();
            this.chkHI = new System.Windows.Forms.CheckBox();
            this.chkCI = new System.Windows.Forms.CheckBox();
            this.chkBI = new System.Windows.Forms.CheckBox();
            this.chkGI = new System.Windows.Forms.CheckBox();
            this.chkIN = new System.Windows.Forms.CheckBox();
            this.pnlHomeShopping = new System.Windows.Forms.Panel();
            this.chkMO = new System.Windows.Forms.CheckBox();
            this.chkMA = new System.Windows.Forms.CheckBox();
            this.chkTV = new System.Windows.Forms.CheckBox();
            this.chkHC = new System.Windows.Forms.CheckBox();
            this.chkHD = new System.Windows.Forms.CheckBox();
            this.chkHX = new System.Windows.Forms.CheckBox();
            this.chkHA = new System.Windows.Forms.CheckBox();
            this.chkWI = new System.Windows.Forms.CheckBox();
            this.chkBC = new System.Windows.Forms.CheckBox();
            this.chkHS = new System.Windows.Forms.CheckBox();
            this.pnlCredit = new System.Windows.Forms.Panel();
            this.chkCO = new System.Windows.Forms.CheckBox();
            this.chkST = new System.Windows.Forms.CheckBox();
            this.chkRS = new System.Windows.Forms.CheckBox();
            this.chkFC = new System.Windows.Forms.CheckBox();
            this.chkCH = new System.Windows.Forms.CheckBox();
            this.chkBD = new System.Windows.Forms.CheckBox();
            this.chkCC = new System.Windows.Forms.CheckBox();
            this.pnlBank = new System.Windows.Forms.Panel();
            this.chkOD = new System.Windows.Forms.CheckBox();
            this.chkSX = new System.Windows.Forms.CheckBox();
            this.chkRQ = new System.Windows.Forms.CheckBox();
            this.chkBK = new System.Windows.Forms.CheckBox();
            this.chkDF = new System.Windows.Forms.CheckBox();
            this.chkDC = new System.Windows.Forms.CheckBox();
            this.chkCA = new System.Windows.Forms.CheckBox();
            this.cboAccountType = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnDaysEligible)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnMinChecks)).BeginInit();
            this.grpGeneral.SuspendLayout();
            this.grpPDFLinks.SuspendLayout();
            this.tabOptions.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updPasswordReminder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnSecurityLevel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnExpiryDays)).BeginInit();
            this.grpMatchWarning.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.pnlUtilities.SuspendLayout();
            this.pnlTelecoms.SuspendLayout();
            this.pnlMortgage.SuspendLayout();
            this.pnlMiscellaneous.SuspendLayout();
            this.pnlLoan.SuspendLayout();
            this.pnlInternet.SuspendLayout();
            this.pnlInsurance.SuspendLayout();
            this.pnlHomeShopping.SuspendLayout();
            this.pnlCredit.SuspendLayout();
            this.pnlBank.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtURL
            // 
            this.txtURL.Location = new System.Drawing.Point(166, 11);
            this.txtURL.Name = "txtURL";
            this.txtURL.Size = new System.Drawing.Size(396, 20);
            this.txtURL.TabIndex = 0;
            this.txtURL.TextChanged += new System.EventHandler(this.ItemChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "CallML Service URL";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Company name";
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.Location = new System.Drawing.Point(166, 37);
            this.txtCompanyName.Name = "txtCompanyName";
            this.txtCompanyName.Size = new System.Drawing.Size(396, 20);
            this.txtCompanyName.TabIndex = 2;
            this.txtCompanyName.TextChanged += new System.EventHandler(this.ItemChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "User name";
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(166, 63);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(396, 20);
            this.txtUsername.TabIndex = 4;
            this.txtUsername.TextChanged += new System.EventHandler(this.ItemChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Password";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(166, 89);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(396, 20);
            this.txtPassword.TabIndex = 6;
            this.txtPassword.UseSystemPasswordChar = true;
            this.txtPassword.TextChanged += new System.EventHandler(this.ItemChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(110, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Period result is eligible";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 169);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 17;
            this.label7.Text = "Minimum checks";
            // 
            // btnSave
            // 
            this.btnSave.Enabled = false;
            this.btnSave.Location = new System.Drawing.Point(418, 528);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 31;
            this.btnSave.Text = "&Save";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(499, 528);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 32;
            this.btnCancel.Text = "E&xit";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.settingsToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(583, 24);
            this.menuStrip1.TabIndex = 34;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveToolStripMenuItem,
            this.cancelToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "&File";
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Enabled = false;
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.saveToolStripMenuItem.Text = "&Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // cancelToolStripMenuItem
            // 
            this.cancelToolStripMenuItem.Name = "cancelToolStripMenuItem";
            this.cancelToolStripMenuItem.Size = new System.Drawing.Size(109, 22);
            this.cancelToolStripMenuItem.Text = "E&xit";
            this.cancelToolStripMenuItem.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changePasswordToolStripMenuItem,
            this.changeAccountToolStripMenuItem,
            this.toolStripSeparator1,
            this.restoreDefaultsToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(58, 20);
            this.settingsToolStripMenuItem.Text = "&Settings";
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.changePasswordToolStripMenuItem.Text = "Change &Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // changeAccountToolStripMenuItem
            // 
            this.changeAccountToolStripMenuItem.Name = "changeAccountToolStripMenuItem";
            this.changeAccountToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.changeAccountToolStripMenuItem.Text = "Change Account Settings";
            this.changeAccountToolStripMenuItem.Click += new System.EventHandler(this.changeAccountToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(203, 6);
            // 
            // restoreDefaultsToolStripMenuItem
            // 
            this.restoreDefaultsToolStripMenuItem.Name = "restoreDefaultsToolStripMenuItem";
            this.restoreDefaultsToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.restoreDefaultsToolStripMenuItem.Text = "&Restore Defaults";
            this.restoreDefaultsToolStripMenuItem.Click += new System.EventHandler(this.restoreDefaultsToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(40, 20);
            this.helpToolStripMenuItem.Text = "&Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(114, 22);
            this.aboutToolStripMenuItem.Text = "&About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // spnDaysEligible
            // 
            this.spnDaysEligible.Location = new System.Drawing.Point(166, 141);
            this.spnDaysEligible.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.spnDaysEligible.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnDaysEligible.Name = "spnDaysEligible";
            this.spnDaysEligible.Size = new System.Drawing.Size(60, 20);
            this.spnDaysEligible.TabIndex = 35;
            this.spnDaysEligible.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnDaysEligible.ValueChanged += new System.EventHandler(this.ItemChanged);
            // 
            // spnMinChecks
            // 
            this.spnMinChecks.Location = new System.Drawing.Point(166, 167);
            this.spnMinChecks.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnMinChecks.Name = "spnMinChecks";
            this.spnMinChecks.Size = new System.Drawing.Size(60, 20);
            this.spnMinChecks.TabIndex = 36;
            this.spnMinChecks.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnMinChecks.ValueChanged += new System.EventHandler(this.ItemChanged);
            // 
            // grpGeneral
            // 
            this.grpGeneral.Controls.Add(this.cbxElectoralRoll);
            this.grpGeneral.Controls.Add(this.cbxSHARE);
            this.grpGeneral.Controls.Add(this.cbxUseBAI);
            this.grpGeneral.Controls.Add(this.cbxFTSE);
            this.grpGeneral.Controls.Add(this.cbxCCJ);
            this.grpGeneral.Controls.Add(this.cbxSearchDirectors);
            this.grpGeneral.Location = new System.Drawing.Point(18, 196);
            this.grpGeneral.Name = "grpGeneral";
            this.grpGeneral.Size = new System.Drawing.Size(304, 161);
            this.grpGeneral.TabIndex = 39;
            this.grpGeneral.TabStop = false;
            this.grpGeneral.Text = "General Details";
            // 
            // cbxElectoralRoll
            // 
            this.cbxElectoralRoll.AutoSize = true;
            this.cbxElectoralRoll.Location = new System.Drawing.Point(10, 134);
            this.cbxElectoralRoll.Name = "cbxElectoralRoll";
            this.cbxElectoralRoll.Size = new System.Drawing.Size(158, 17);
            this.cbxElectoralRoll.TabIndex = 44;
            this.cbxElectoralRoll.Text = "Use electoral roll information";
            this.cbxElectoralRoll.UseVisualStyleBackColor = true;
            this.cbxElectoralRoll.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // cbxSHARE
            // 
            this.cbxSHARE.AutoSize = true;
            this.cbxSHARE.Location = new System.Drawing.Point(10, 111);
            this.cbxSHARE.Name = "cbxSHARE";
            this.cbxSHARE.Size = new System.Drawing.Size(166, 17);
            this.cbxSHARE.TabIndex = 43;
            this.cbxSHARE.Text = "Use settled SHARE accounts";
            this.cbxSHARE.UseVisualStyleBackColor = true;
            this.cbxSHARE.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // cbxUseBAI
            // 
            this.cbxUseBAI.AutoSize = true;
            this.cbxUseBAI.Location = new System.Drawing.Point(10, 65);
            this.cbxUseBAI.Name = "cbxUseBAI";
            this.cbxUseBAI.Size = new System.Drawing.Size(163, 17);
            this.cbxUseBAI.TabIndex = 42;
            this.cbxUseBAI.Text = "Use bankruptcy && insolvency";
            this.cbxUseBAI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.cbxUseBAI.UseVisualStyleBackColor = true;
            this.cbxUseBAI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // cbxFTSE
            // 
            this.cbxFTSE.AutoSize = true;
            this.cbxFTSE.Location = new System.Drawing.Point(10, 42);
            this.cbxFTSE.Name = "cbxFTSE";
            this.cbxFTSE.Size = new System.Drawing.Size(236, 17);
            this.cbxFTSE.TabIndex = 41;
            this.cbxFTSE.Text = "Use UK investors data as an address source";
            this.cbxFTSE.UseVisualStyleBackColor = true;
            this.cbxFTSE.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // cbxCCJ
            // 
            this.cbxCCJ.AutoSize = true;
            this.cbxCCJ.Location = new System.Drawing.Point(10, 88);
            this.cbxCCJ.Name = "cbxCCJ";
            this.cbxCCJ.Size = new System.Drawing.Size(91, 17);
            this.cbxCCJ.TabIndex = 40;
            this.cbxCCJ.Text = "Use CCJ data";
            this.cbxCCJ.UseVisualStyleBackColor = true;
            this.cbxCCJ.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // cbxSearchDirectors
            // 
            this.cbxSearchDirectors.AutoSize = true;
            this.cbxSearchDirectors.Location = new System.Drawing.Point(10, 19);
            this.cbxSearchDirectors.Name = "cbxSearchDirectors";
            this.cbxSearchDirectors.Size = new System.Drawing.Size(209, 17);
            this.cbxSearchDirectors.TabIndex = 39;
            this.cbxSearchDirectors.Text = "Search the directors at home database";
            this.cbxSearchDirectors.UseVisualStyleBackColor = true;
            this.cbxSearchDirectors.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // grpPDFLinks
            // 
            this.grpPDFLinks.Controls.Add(this.btnUpdateHistory);
            this.grpPDFLinks.Controls.Add(this.cboPDFDate);
            this.grpPDFLinks.Controls.Add(this.lblField);
            this.grpPDFLinks.Controls.Add(this.cboPDFScreen);
            this.grpPDFLinks.Controls.Add(this.lblScreen);
            this.grpPDFLinks.Location = new System.Drawing.Point(16, 363);
            this.grpPDFLinks.Name = "grpPDFLinks";
            this.grpPDFLinks.Size = new System.Drawing.Size(307, 98);
            this.grpPDFLinks.TabIndex = 40;
            this.grpPDFLinks.TabStop = false;
            this.grpPDFLinks.Text = "PDF Links - Last Check Date";
            this.grpPDFLinks.Enter += new System.EventHandler(this.grpValueAddedServices_Enter);
            // 
            // btnUpdateHistory
            // 
            this.btnUpdateHistory.Location = new System.Drawing.Point(219, 28);
            this.btnUpdateHistory.Name = "btnUpdateHistory";
            this.btnUpdateHistory.Size = new System.Drawing.Size(70, 48);
            this.btnUpdateHistory.TabIndex = 4;
            this.btnUpdateHistory.Text = "Update ML History";
            this.btnUpdateHistory.UseVisualStyleBackColor = true;
            this.btnUpdateHistory.Click += new System.EventHandler(this.button1_Click);
            // 
            // cboPDFDate
            // 
            this.cboPDFDate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPDFDate.FormattingEnabled = true;
            this.cboPDFDate.Location = new System.Drawing.Point(63, 55);
            this.cboPDFDate.Name = "cboPDFDate";
            this.cboPDFDate.Size = new System.Drawing.Size(147, 21);
            this.cboPDFDate.TabIndex = 3;
            this.cboPDFDate.SelectedIndexChanged += new System.EventHandler(this.cboPDFDate_SelectedIndexChanged);
            // 
            // lblField
            // 
            this.lblField.AutoSize = true;
            this.lblField.Location = new System.Drawing.Point(16, 58);
            this.lblField.Name = "lblField";
            this.lblField.Size = new System.Drawing.Size(29, 13);
            this.lblField.TabIndex = 2;
            this.lblField.Text = "Field";
            // 
            // cboPDFScreen
            // 
            this.cboPDFScreen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPDFScreen.FormattingEnabled = true;
            this.cboPDFScreen.Location = new System.Drawing.Point(63, 28);
            this.cboPDFScreen.Name = "cboPDFScreen";
            this.cboPDFScreen.Size = new System.Drawing.Size(147, 21);
            this.cboPDFScreen.TabIndex = 1;
            this.cboPDFScreen.SelectedIndexChanged += new System.EventHandler(this.cboPDFScreen_SelectedIndexChanged);
            // 
            // lblScreen
            // 
            this.lblScreen.AutoSize = true;
            this.lblScreen.Location = new System.Drawing.Point(16, 31);
            this.lblScreen.Name = "lblScreen";
            this.lblScreen.Size = new System.Drawing.Size(41, 13);
            this.lblScreen.TabIndex = 0;
            this.lblScreen.Text = "Screen";
            // 
            // tabOptions
            // 
            this.tabOptions.Controls.Add(this.tabPage1);
            this.tabOptions.Controls.Add(this.tabPage2);
            this.tabOptions.Location = new System.Drawing.Point(0, 27);
            this.tabOptions.Name = "tabOptions";
            this.tabOptions.SelectedIndex = 0;
            this.tabOptions.Size = new System.Drawing.Size(583, 495);
            this.tabOptions.TabIndex = 42;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.updPasswordReminder);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.cboPeriod);
            this.tabPage1.Controls.Add(this.spnSecurityLevel);
            this.tabPage1.Controls.Add(this.spnExpiryDays);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.grpMatchWarning);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.txtURL);
            this.tabPage1.Controls.Add(this.grpPDFLinks);
            this.tabPage1.Controls.Add(this.txtCompanyName);
            this.tabPage1.Controls.Add(this.grpGeneral);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.spnMinChecks);
            this.tabPage1.Controls.Add(this.txtUsername);
            this.tabPage1.Controls.Add(this.spnDaysEligible);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtPassword);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(575, 469);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "General";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // updPasswordReminder
            // 
            this.updPasswordReminder.Location = new System.Drawing.Point(166, 116);
            this.updPasswordReminder.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.updPasswordReminder.Name = "updPasswordReminder";
            this.updPasswordReminder.Size = new System.Drawing.Size(60, 20);
            this.updPasswordReminder.TabIndex = 49;
            this.updPasswordReminder.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            this.updPasswordReminder.ValueChanged += new System.EventHandler(this.ItemChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 118);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 13);
            this.label5.TabIndex = 48;
            this.label5.Text = "Password Reminder (days)";
            // 
            // cboPeriod
            // 
            this.cboPeriod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPeriod.FormattingEnabled = true;
            this.cboPeriod.Items.AddRange(new object[] {
            "Days",
            "Months",
            "Years"});
            this.cboPeriod.Location = new System.Drawing.Point(235, 141);
            this.cboPeriod.Name = "cboPeriod";
            this.cboPeriod.Size = new System.Drawing.Size(88, 21);
            this.cboPeriod.TabIndex = 47;
            this.cboPeriod.SelectedIndexChanged += new System.EventHandler(this.ItemChanged);
            // 
            // spnSecurityLevel
            // 
            this.spnSecurityLevel.Location = new System.Drawing.Point(488, 169);
            this.spnSecurityLevel.Maximum = new decimal(new int[] {
            9,
            0,
            0,
            0});
            this.spnSecurityLevel.Name = "spnSecurityLevel";
            this.spnSecurityLevel.Size = new System.Drawing.Size(74, 20);
            this.spnSecurityLevel.TabIndex = 46;
            this.spnSecurityLevel.ValueChanged += new System.EventHandler(this.ItemChanged);
            // 
            // spnExpiryDays
            // 
            this.spnExpiryDays.Location = new System.Drawing.Point(488, 143);
            this.spnExpiryDays.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnExpiryDays.Name = "spnExpiryDays";
            this.spnExpiryDays.Size = new System.Drawing.Size(74, 20);
            this.spnExpiryDays.TabIndex = 45;
            this.spnExpiryDays.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.spnExpiryDays.ValueChanged += new System.EventHandler(this.ItemChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(339, 169);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 13);
            this.label10.TabIndex = 44;
            this.label10.Text = "Security level for override";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(339, 145);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 13);
            this.label9.TabIndex = 43;
            this.label9.Text = "Days before expiry warning";
            // 
            // grpMatchWarning
            // 
            this.grpMatchWarning.Controls.Add(this.chkWarnUKPassport);
            this.grpMatchWarning.Controls.Add(this.chkWarnFraudPassport);
            this.grpMatchWarning.Controls.Add(this.chkWarnDrivingLicense);
            this.grpMatchWarning.Controls.Add(this.chkWarnResidency);
            this.grpMatchWarning.Controls.Add(this.chkWarnDOBOne);
            this.grpMatchWarning.Controls.Add(this.chkWarnDOBAll);
            this.grpMatchWarning.Controls.Add(this.chkWarnAddressLinks);
            this.grpMatchWarning.Controls.Add(this.chkWarnGoneAway);
            this.grpMatchWarning.Controls.Add(this.chkWarnDeceased);
            this.grpMatchWarning.Controls.Add(this.chkWarnPEP);
            this.grpMatchWarning.Controls.Add(this.chkWarnCIFAS);
            this.grpMatchWarning.Location = new System.Drawing.Point(328, 196);
            this.grpMatchWarning.Name = "grpMatchWarning";
            this.grpMatchWarning.Size = new System.Drawing.Size(234, 265);
            this.grpMatchWarning.TabIndex = 42;
            this.grpMatchWarning.TabStop = false;
            this.grpMatchWarning.Text = "Show Decision Warning";
            // 
            // chkWarnUKPassport
            // 
            this.chkWarnUKPassport.AutoSize = true;
            this.chkWarnUKPassport.Location = new System.Drawing.Point(16, 228);
            this.chkWarnUKPassport.Name = "chkWarnUKPassport";
            this.chkWarnUKPassport.Size = new System.Drawing.Size(131, 17);
            this.chkWarnUKPassport.TabIndex = 10;
            this.chkWarnUKPassport.Text = "UK passport mismatch";
            this.chkWarnUKPassport.UseVisualStyleBackColor = true;
            this.chkWarnUKPassport.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnFraudPassport
            // 
            this.chkWarnFraudPassport.AutoSize = true;
            this.chkWarnFraudPassport.Location = new System.Drawing.Point(16, 90);
            this.chkWarnFraudPassport.Name = "chkWarnFraudPassport";
            this.chkWarnFraudPassport.Size = new System.Drawing.Size(119, 17);
            this.chkWarnFraudPassport.TabIndex = 9;
            this.chkWarnFraudPassport.Text = "Fraudulent passport";
            this.chkWarnFraudPassport.UseVisualStyleBackColor = true;
            this.chkWarnFraudPassport.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnDrivingLicense
            // 
            this.chkWarnDrivingLicense.AutoSize = true;
            this.chkWarnDrivingLicense.Location = new System.Drawing.Point(16, 181);
            this.chkWarnDrivingLicense.Name = "chkWarnDrivingLicense";
            this.chkWarnDrivingLicense.Size = new System.Drawing.Size(142, 17);
            this.chkWarnDrivingLicense.TabIndex = 8;
            this.chkWarnDrivingLicense.Text = "Driving license mismatch";
            this.chkWarnDrivingLicense.UseVisualStyleBackColor = true;
            this.chkWarnDrivingLicense.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnResidency
            // 
            this.chkWarnResidency.AutoSize = true;
            this.chkWarnResidency.Location = new System.Drawing.Point(16, 204);
            this.chkWarnResidency.Name = "chkWarnResidency";
            this.chkWarnResidency.Size = new System.Drawing.Size(119, 17);
            this.chkWarnResidency.TabIndex = 7;
            this.chkWarnResidency.Text = "Length of residency";
            this.chkWarnResidency.UseVisualStyleBackColor = true;
            this.chkWarnResidency.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnDOBOne
            // 
            this.chkWarnDOBOne.AutoSize = true;
            this.chkWarnDOBOne.Location = new System.Drawing.Point(16, 158);
            this.chkWarnDOBOne.Name = "chkWarnDOBOne";
            this.chkWarnDOBOne.Size = new System.Drawing.Size(182, 17);
            this.chkWarnDOBOne.TabIndex = 6;
            this.chkWarnDOBOne.Text = "SHARE date of birth - one record";
            this.chkWarnDOBOne.UseVisualStyleBackColor = true;
            this.chkWarnDOBOne.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnDOBAll
            // 
            this.chkWarnDOBAll.AutoSize = true;
            this.chkWarnDOBAll.Location = new System.Drawing.Point(16, 136);
            this.chkWarnDOBAll.Name = "chkWarnDOBAll";
            this.chkWarnDOBAll.Size = new System.Drawing.Size(179, 17);
            this.chkWarnDOBAll.TabIndex = 5;
            this.chkWarnDOBAll.Text = "SHARE date of birth - all records";
            this.chkWarnDOBAll.UseVisualStyleBackColor = true;
            this.chkWarnDOBAll.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnAddressLinks
            // 
            this.chkWarnAddressLinks.AutoSize = true;
            this.chkWarnAddressLinks.Location = new System.Drawing.Point(16, 113);
            this.chkWarnAddressLinks.Name = "chkWarnAddressLinks";
            this.chkWarnAddressLinks.Size = new System.Drawing.Size(142, 17);
            this.chkWarnAddressLinks.TabIndex = 4;
            this.chkWarnAddressLinks.Text = "Forwarding address links";
            this.chkWarnAddressLinks.UseVisualStyleBackColor = true;
            this.chkWarnAddressLinks.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnGoneAway
            // 
            this.chkWarnGoneAway.AutoSize = true;
            this.chkWarnGoneAway.Location = new System.Drawing.Point(16, 66);
            this.chkWarnGoneAway.Name = "chkWarnGoneAway";
            this.chkWarnGoneAway.Size = new System.Drawing.Size(80, 17);
            this.chkWarnGoneAway.TabIndex = 3;
            this.chkWarnGoneAway.Text = "Gone away";
            this.chkWarnGoneAway.UseVisualStyleBackColor = true;
            this.chkWarnGoneAway.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnDeceased
            // 
            this.chkWarnDeceased.AutoSize = true;
            this.chkWarnDeceased.Location = new System.Drawing.Point(16, 43);
            this.chkWarnDeceased.Name = "chkWarnDeceased";
            this.chkWarnDeceased.Size = new System.Drawing.Size(75, 17);
            this.chkWarnDeceased.TabIndex = 2;
            this.chkWarnDeceased.Text = "Deceased";
            this.chkWarnDeceased.UseVisualStyleBackColor = true;
            this.chkWarnDeceased.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnPEP
            // 
            this.chkWarnPEP.AutoSize = true;
            this.chkWarnPEP.Location = new System.Drawing.Point(16, 20);
            this.chkWarnPEP.Name = "chkWarnPEP";
            this.chkWarnPEP.Size = new System.Drawing.Size(129, 17);
            this.chkWarnPEP.TabIndex = 1;
            this.chkWarnPEP.Text = "PEP, SDN, Sanctions";
            this.chkWarnPEP.UseVisualStyleBackColor = true;
            this.chkWarnPEP.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWarnCIFAS
            // 
            this.chkWarnCIFAS.AutoSize = true;
            this.chkWarnCIFAS.Location = new System.Drawing.Point(22, 20);
            this.chkWarnCIFAS.Name = "chkWarnCIFAS";
            this.chkWarnCIFAS.Size = new System.Drawing.Size(56, 17);
            this.chkWarnCIFAS.TabIndex = 0;
            this.chkWarnCIFAS.Text = "CIFAS";
            this.chkWarnCIFAS.UseVisualStyleBackColor = true;
            this.chkWarnCIFAS.Visible = false;
            this.chkWarnCIFAS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.pnlUtilities);
            this.tabPage2.Controls.Add(this.pnlTelecoms);
            this.tabPage2.Controls.Add(this.pnlMortgage);
            this.tabPage2.Controls.Add(this.pnlMiscellaneous);
            this.tabPage2.Controls.Add(this.pnlLoan);
            this.tabPage2.Controls.Add(this.pnlInternet);
            this.tabPage2.Controls.Add(this.pnlInsurance);
            this.tabPage2.Controls.Add(this.pnlHomeShopping);
            this.tabPage2.Controls.Add(this.pnlCredit);
            this.tabPage2.Controls.Add(this.pnlBank);
            this.tabPage2.Controls.Add(this.cboAccountType);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(575, 469);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "SHARE exclusions";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // pnlUtilities
            // 
            this.pnlUtilities.Controls.Add(this.chkUE);
            this.pnlUtilities.Controls.Add(this.chkQU);
            this.pnlUtilities.Controls.Add(this.chkGE);
            this.pnlUtilities.Controls.Add(this.chkQG);
            this.pnlUtilities.Controls.Add(this.chkEE);
            this.pnlUtilities.Controls.Add(this.chkQE);
            this.pnlUtilities.Controls.Add(this.chkEW);
            this.pnlUtilities.Controls.Add(this.chkQW);
            this.pnlUtilities.Controls.Add(this.chkUT);
            this.pnlUtilities.Location = new System.Drawing.Point(0, 38);
            this.pnlUtilities.Name = "pnlUtilities";
            this.pnlUtilities.Size = new System.Drawing.Size(575, 431);
            this.pnlUtilities.TabIndex = 1;
            // 
            // chkUE
            // 
            this.chkUE.AutoSize = true;
            this.chkUE.Location = new System.Drawing.Point(14, 39);
            this.chkUE.Name = "chkUE";
            this.chkUE.Size = new System.Drawing.Size(127, 17);
            this.chkUE.TabIndex = 8;
            this.chkUE.Text = "Utility - even payment";
            this.chkUE.UseVisualStyleBackColor = true;
            this.chkUE.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkQU
            // 
            this.chkQU.AutoSize = true;
            this.chkQU.Location = new System.Drawing.Point(14, 62);
            this.chkQU.Name = "chkQU";
            this.chkQU.Size = new System.Drawing.Size(143, 17);
            this.chkQU.TabIndex = 7;
            this.chkQU.Text = "Utility - quarterly payment";
            this.chkQU.UseVisualStyleBackColor = true;
            this.chkQU.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkGE
            // 
            this.chkGE.AutoSize = true;
            this.chkGE.Location = new System.Drawing.Point(14, 85);
            this.chkGE.Name = "chkGE";
            this.chkGE.Size = new System.Drawing.Size(121, 17);
            this.chkGE.TabIndex = 6;
            this.chkGE.Text = "Gas - even payment";
            this.chkGE.UseVisualStyleBackColor = true;
            this.chkGE.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkQG
            // 
            this.chkQG.AutoSize = true;
            this.chkQG.Location = new System.Drawing.Point(14, 108);
            this.chkQG.Name = "chkQG";
            this.chkQG.Size = new System.Drawing.Size(137, 17);
            this.chkQG.TabIndex = 5;
            this.chkQG.Text = "Gas - quarterly payment";
            this.chkQG.UseVisualStyleBackColor = true;
            this.chkQG.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkEE
            // 
            this.chkEE.AutoSize = true;
            this.chkEE.Location = new System.Drawing.Point(14, 131);
            this.chkEE.Name = "chkEE";
            this.chkEE.Size = new System.Drawing.Size(147, 17);
            this.chkEE.TabIndex = 4;
            this.chkEE.Text = "Electricity - even payment";
            this.chkEE.UseVisualStyleBackColor = true;
            this.chkEE.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkQE
            // 
            this.chkQE.AutoSize = true;
            this.chkQE.Location = new System.Drawing.Point(14, 154);
            this.chkQE.Name = "chkQE";
            this.chkQE.Size = new System.Drawing.Size(163, 17);
            this.chkQE.TabIndex = 3;
            this.chkQE.Text = "Electricity - quarterly payment";
            this.chkQE.UseVisualStyleBackColor = true;
            this.chkQE.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkEW
            // 
            this.chkEW.AutoSize = true;
            this.chkEW.Location = new System.Drawing.Point(14, 177);
            this.chkEW.Name = "chkEW";
            this.chkEW.Size = new System.Drawing.Size(131, 17);
            this.chkEW.TabIndex = 2;
            this.chkEW.Text = "Water - even payment";
            this.chkEW.UseVisualStyleBackColor = true;
            this.chkEW.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkQW
            // 
            this.chkQW.AutoSize = true;
            this.chkQW.Location = new System.Drawing.Point(14, 201);
            this.chkQW.Name = "chkQW";
            this.chkQW.Size = new System.Drawing.Size(147, 17);
            this.chkQW.TabIndex = 1;
            this.chkQW.Text = "Water - quarterly payment";
            this.chkQW.UseVisualStyleBackColor = true;
            this.chkQW.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkUT
            // 
            this.chkUT.AutoSize = true;
            this.chkUT.Location = new System.Drawing.Point(14, 17);
            this.chkUT.Name = "chkUT";
            this.chkUT.Size = new System.Drawing.Size(51, 17);
            this.chkUT.TabIndex = 0;
            this.chkUT.Text = "Utility";
            this.chkUT.UseVisualStyleBackColor = true;
            this.chkUT.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlTelecoms
            // 
            this.pnlTelecoms.Controls.Add(this.chkAM);
            this.pnlTelecoms.Controls.Add(this.chkAU);
            this.pnlTelecoms.Controls.Add(this.chkQA);
            this.pnlTelecoms.Controls.Add(this.chkLT);
            this.pnlTelecoms.Controls.Add(this.chkQT);
            this.pnlTelecoms.Controls.Add(this.chkTM);
            this.pnlTelecoms.Location = new System.Drawing.Point(0, 38);
            this.pnlTelecoms.Name = "pnlTelecoms";
            this.pnlTelecoms.Size = new System.Drawing.Size(575, 431);
            this.pnlTelecoms.TabIndex = 4;
            // 
            // chkAM
            // 
            this.chkAM.AutoSize = true;
            this.chkAM.Location = new System.Drawing.Point(14, 40);
            this.chkAM.Name = "chkAM";
            this.chkAM.Size = new System.Drawing.Size(197, 17);
            this.chkAM.TabIndex = 5;
            this.chkAM.Text = "Airtime agreement - monthly contract";
            this.chkAM.UseVisualStyleBackColor = true;
            this.chkAM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkAU
            // 
            this.chkAU.AutoSize = true;
            this.chkAU.Location = new System.Drawing.Point(14, 63);
            this.chkAU.Name = "chkAU";
            this.chkAU.Size = new System.Drawing.Size(154, 17);
            this.chkAU.TabIndex = 4;
            this.chkAU.Text = "Airtime agreememt - upfront";
            this.chkAU.UseVisualStyleBackColor = true;
            this.chkAU.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkQA
            // 
            this.chkQA.AutoSize = true;
            this.chkQA.Location = new System.Drawing.Point(14, 86);
            this.chkQA.Name = "chkQA";
            this.chkQA.Size = new System.Drawing.Size(202, 17);
            this.chkQA.TabIndex = 3;
            this.chkQA.Text = "Airtime agreement - quarterly payment";
            this.chkQA.UseVisualStyleBackColor = true;
            this.chkQA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkLT
            // 
            this.chkLT.AutoSize = true;
            this.chkLT.Location = new System.Drawing.Point(14, 109);
            this.chkLT.Name = "chkLT";
            this.chkLT.Size = new System.Drawing.Size(192, 17);
            this.chkLT.TabIndex = 2;
            this.chkLT.Text = "Landline telephone - even payment";
            this.chkLT.UseVisualStyleBackColor = true;
            this.chkLT.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkQT
            // 
            this.chkQT.AutoSize = true;
            this.chkQT.Location = new System.Drawing.Point(14, 132);
            this.chkQT.Name = "chkQT";
            this.chkQT.Size = new System.Drawing.Size(208, 17);
            this.chkQT.TabIndex = 1;
            this.chkQT.Text = "Landline telephone - quarterly payment";
            this.chkQT.UseVisualStyleBackColor = true;
            this.chkQT.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkTM
            // 
            this.chkTM.AutoSize = true;
            this.chkTM.Location = new System.Drawing.Point(14, 17);
            this.chkTM.Name = "chkTM";
            this.chkTM.Size = new System.Drawing.Size(162, 17);
            this.chkTM.TabIndex = 0;
            this.chkTM.Text = "Telecommunications supplier";
            this.chkTM.UseVisualStyleBackColor = true;
            this.chkTM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlMortgage
            // 
            this.pnlMortgage.Controls.Add(this.chkFO);
            this.pnlMortgage.Controls.Add(this.chkRM);
            this.pnlMortgage.Controls.Add(this.chkIM);
            this.pnlMortgage.Controls.Add(this.chkMM);
            this.pnlMortgage.Controls.Add(this.chkFM);
            this.pnlMortgage.Controls.Add(this.chkCM);
            this.pnlMortgage.Controls.Add(this.chkBM);
            this.pnlMortgage.Controls.Add(this.chkXM);
            this.pnlMortgage.Controls.Add(this.chkSM);
            this.pnlMortgage.Controls.Add(this.chkNM);
            this.pnlMortgage.Controls.Add(this.chkDM);
            this.pnlMortgage.Controls.Add(this.chkMG);
            this.pnlMortgage.Location = new System.Drawing.Point(0, 38);
            this.pnlMortgage.Name = "pnlMortgage";
            this.pnlMortgage.Size = new System.Drawing.Size(575, 431);
            this.pnlMortgage.TabIndex = 4;
            // 
            // chkFO
            // 
            this.chkFO.AutoSize = true;
            this.chkFO.Location = new System.Drawing.Point(14, 153);
            this.chkFO.Name = "chkFO";
            this.chkFO.Size = new System.Drawing.Size(249, 17);
            this.chkFO.TabIndex = 13;
            this.chkFO.Text = "Residential first mortgage with investment offset";
            this.chkFO.UseVisualStyleBackColor = true;
            this.chkFO.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkRM
            // 
            this.chkRM.AutoSize = true;
            this.chkRM.Location = new System.Drawing.Point(14, 39);
            this.chkRM.Name = "chkRM";
            this.chkRM.Size = new System.Drawing.Size(125, 17);
            this.chkRM.TabIndex = 11;
            this.chkRM.Text = "Residential mortgage";
            this.chkRM.UseVisualStyleBackColor = true;
            this.chkRM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkIM
            // 
            this.chkIM.AutoSize = true;
            this.chkIM.Location = new System.Drawing.Point(14, 176);
            this.chkIM.Name = "chkIM";
            this.chkIM.Size = new System.Drawing.Size(268, 17);
            this.chkIM.TabIndex = 10;
            this.chkIM.Text = "Residential second mortgage with investment offset";
            this.chkIM.UseVisualStyleBackColor = true;
            this.chkIM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkMM
            // 
            this.chkMM.AutoSize = true;
            this.chkMM.Location = new System.Drawing.Point(14, 222);
            this.chkMM.Name = "chkMM";
            this.chkMM.Size = new System.Drawing.Size(171, 17);
            this.chkMM.TabIndex = 9;
            this.chkMM.Text = "Semi-commercial first mortgage";
            this.chkMM.UseVisualStyleBackColor = true;
            this.chkMM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkFM
            // 
            this.chkFM.AutoSize = true;
            this.chkFM.Location = new System.Drawing.Point(14, 60);
            this.chkFM.Name = "chkFM";
            this.chkFM.Size = new System.Drawing.Size(108, 17);
            this.chkFM.TabIndex = 8;
            this.chkFM.Text = "Flexible mortgage";
            this.chkFM.UseVisualStyleBackColor = true;
            this.chkFM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCM
            // 
            this.chkCM.AutoSize = true;
            this.chkCM.Location = new System.Drawing.Point(14, 83);
            this.chkCM.Name = "chkCM";
            this.chkCM.Size = new System.Drawing.Size(127, 17);
            this.chkCM.TabIndex = 7;
            this.chkCM.Text = "Commercial mortgage";
            this.chkCM.UseVisualStyleBackColor = true;
            this.chkCM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBM
            // 
            this.chkBM.AutoSize = true;
            this.chkBM.Location = new System.Drawing.Point(14, 106);
            this.chkBM.Name = "chkBM";
            this.chkBM.Size = new System.Drawing.Size(124, 17);
            this.chkBM.TabIndex = 6;
            this.chkBM.Text = "Residential buy to let";
            this.chkBM.UseVisualStyleBackColor = true;
            this.chkBM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkXM
            // 
            this.chkXM.AutoSize = true;
            this.chkXM.Location = new System.Drawing.Point(14, 129);
            this.chkXM.Name = "chkXM";
            this.chkXM.Size = new System.Drawing.Size(148, 17);
            this.chkXM.TabIndex = 5;
            this.chkXM.Text = "Residential first time buyer";
            this.chkXM.UseVisualStyleBackColor = true;
            this.chkXM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSM
            // 
            this.chkSM.AutoSize = true;
            this.chkSM.Location = new System.Drawing.Point(14, 199);
            this.chkSM.Name = "chkSM";
            this.chkSM.Size = new System.Drawing.Size(163, 17);
            this.chkSM.TabIndex = 3;
            this.chkSM.Text = "Residential second mortgage";
            this.chkSM.UseVisualStyleBackColor = true;
            this.chkSM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkNM
            // 
            this.chkNM.AutoSize = true;
            this.chkNM.Location = new System.Drawing.Point(14, 245);
            this.chkNM.Name = "chkNM";
            this.chkNM.Size = new System.Drawing.Size(190, 17);
            this.chkNM.TabIndex = 2;
            this.chkNM.Text = "Semi-commercial second mortgage";
            this.chkNM.UseVisualStyleBackColor = true;
            this.chkNM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkDM
            // 
            this.chkDM.AutoSize = true;
            this.chkDM.Location = new System.Drawing.Point(14, 268);
            this.chkDM.Name = "chkDM";
            this.chkDM.Size = new System.Drawing.Size(213, 17);
            this.chkDM.TabIndex = 1;
            this.chkDM.Text = "Shared ownership (housing association)";
            this.chkDM.UseVisualStyleBackColor = true;
            this.chkDM.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkMG
            // 
            this.chkMG.AutoSize = true;
            this.chkMG.Location = new System.Drawing.Point(14, 17);
            this.chkMG.Name = "chkMG";
            this.chkMG.Size = new System.Drawing.Size(157, 17);
            this.chkMG.TabIndex = 0;
            this.chkMG.Text = "Mortgage (unspecified type)";
            this.chkMG.UseVisualStyleBackColor = true;
            this.chkMG.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlMiscellaneous
            // 
            this.pnlMiscellaneous.Controls.Add(this.chkOA);
            this.pnlMiscellaneous.Controls.Add(this.chkSA);
            this.pnlMiscellaneous.Controls.Add(this.chkEC);
            this.pnlMiscellaneous.Controls.Add(this.chkCT);
            this.pnlMiscellaneous.Controls.Add(this.chkLR);
            this.pnlMiscellaneous.Controls.Add(this.chkAF);
            this.pnlMiscellaneous.Controls.Add(this.chkCD);
            this.pnlMiscellaneous.Controls.Add(this.chkFT);
            this.pnlMiscellaneous.Controls.Add(this.chkRC);
            this.pnlMiscellaneous.Controls.Add(this.chkDP);
            this.pnlMiscellaneous.Controls.Add(this.chkZC);
            this.pnlMiscellaneous.Controls.Add(this.chkCZ);
            this.pnlMiscellaneous.Controls.Add(this.chkBX);
            this.pnlMiscellaneous.Controls.Add(this.chkGL);
            this.pnlMiscellaneous.Controls.Add(this.chkSS);
            this.pnlMiscellaneous.Controls.Add(this.chkTR);
            this.pnlMiscellaneous.Controls.Add(this.chkAD);
            this.pnlMiscellaneous.Controls.Add(this.chkVS);
            this.pnlMiscellaneous.Controls.Add(this.chkMC);
            this.pnlMiscellaneous.Location = new System.Drawing.Point(0, 38);
            this.pnlMiscellaneous.Name = "pnlMiscellaneous";
            this.pnlMiscellaneous.Size = new System.Drawing.Size(575, 431);
            this.pnlMiscellaneous.TabIndex = 1;
            // 
            // chkOA
            // 
            this.chkOA.AutoSize = true;
            this.chkOA.Location = new System.Drawing.Point(14, 40);
            this.chkOA.Name = "chkOA";
            this.chkOA.Size = new System.Drawing.Size(99, 17);
            this.chkOA.TabIndex = 18;
            this.chkOA.Text = "Option account";
            this.chkOA.UseVisualStyleBackColor = true;
            this.chkOA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSA
            // 
            this.chkSA.AutoSize = true;
            this.chkSA.Location = new System.Drawing.Point(14, 63);
            this.chkSA.Name = "chkSA";
            this.chkSA.Size = new System.Drawing.Size(134, 17);
            this.chkSA.TabIndex = 17;
            this.chkSA.Text = "Stock broking account";
            this.chkSA.UseVisualStyleBackColor = true;
            this.chkSA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkEC
            // 
            this.chkEC.AutoSize = true;
            this.chkEC.Location = new System.Drawing.Point(14, 86);
            this.chkEC.Name = "chkEC";
            this.chkEC.Size = new System.Drawing.Size(59, 17);
            this.chkEC.TabIndex = 16;
            this.chkEC.Text = "E-cash";
            this.chkEC.UseVisualStyleBackColor = true;
            this.chkEC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCT
            // 
            this.chkCT.AutoSize = true;
            this.chkCT.Location = new System.Drawing.Point(14, 109);
            this.chkCT.Name = "chkCT";
            this.chkCT.Size = new System.Drawing.Size(78, 17);
            this.chkCT.TabIndex = 15;
            this.chkCT.Text = "Council tax";
            this.chkCT.UseVisualStyleBackColor = true;
            this.chkCT.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkLR
            // 
            this.chkLR.AutoSize = true;
            this.chkLR.Location = new System.Drawing.Point(14, 132);
            this.chkLR.Name = "chkLR";
            this.chkLR.Size = new System.Drawing.Size(194, 17);
            this.chkLR.TabIndex = 14;
            this.chkLR.Text = "Local rates - even payment scheme";
            this.chkLR.UseVisualStyleBackColor = true;
            this.chkLR.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkAF
            // 
            this.chkAF.AutoSize = true;
            this.chkAF.Location = new System.Drawing.Point(14, 201);
            this.chkAF.Name = "chkAF";
            this.chkAF.Size = new System.Drawing.Size(116, 17);
            this.chkAF.TabIndex = 13;
            this.chkAF.Text = "Agricultural finance";
            this.chkAF.UseVisualStyleBackColor = true;
            this.chkAF.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkCD
            // 
            this.chkCD.AutoSize = true;
            this.chkCD.Location = new System.Drawing.Point(228, 40);
            this.chkCD.Name = "chkCD";
            this.chkCD.Size = new System.Drawing.Size(80, 17);
            this.chkCD.TabIndex = 12;
            this.chkCD.Text = "Crown debt";
            this.chkCD.UseVisualStyleBackColor = true;
            this.chkCD.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkFT
            // 
            this.chkFT.AutoSize = true;
            this.chkFT.Location = new System.Drawing.Point(228, 63);
            this.chkFT.Name = "chkFT";
            this.chkFT.Size = new System.Drawing.Size(70, 17);
            this.chkFT.TabIndex = 11;
            this.chkFT.Text = "Factoring";
            this.chkFT.UseVisualStyleBackColor = true;
            this.chkFT.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkRC
            // 
            this.chkRC.AutoSize = true;
            this.chkRC.Location = new System.Drawing.Point(228, 132);
            this.chkRC.Name = "chkRC";
            this.chkRC.Size = new System.Drawing.Size(103, 17);
            this.chkRC.TabIndex = 10;
            this.chkRC.Text = "Revolving credit";
            this.chkRC.UseVisualStyleBackColor = true;
            this.chkRC.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkDP
            // 
            this.chkDP.AutoSize = true;
            this.chkDP.Location = new System.Drawing.Point(228, 155);
            this.chkDP.Name = "chkDP";
            this.chkDP.Size = new System.Drawing.Size(110, 17);
            this.chkDP.TabIndex = 9;
            this.chkDP.Text = "Deferred payment";
            this.chkDP.UseVisualStyleBackColor = true;
            this.chkDP.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkZC
            // 
            this.chkZC.AutoSize = true;
            this.chkZC.Location = new System.Drawing.Point(14, 155);
            this.chkZC.Name = "chkZC";
            this.chkZC.Size = new System.Drawing.Size(94, 17);
            this.chkZC.TabIndex = 8;
            this.chkZC.Text = "Standby credit";
            this.chkZC.UseVisualStyleBackColor = true;
            this.chkZC.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkCZ
            // 
            this.chkCZ.AutoSize = true;
            this.chkCZ.Location = new System.Drawing.Point(14, 178);
            this.chkCZ.Name = "chkCZ";
            this.chkCZ.Size = new System.Drawing.Size(149, 17);
            this.chkCZ.TabIndex = 7;
            this.chkCZ.Text = "Combined credit accounts";
            this.chkCZ.UseVisualStyleBackColor = true;
            this.chkCZ.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkBX
            // 
            this.chkBX.AutoSize = true;
            this.chkBX.Location = new System.Drawing.Point(228, 17);
            this.chkBX.Name = "chkBX";
            this.chkBX.Size = new System.Drawing.Size(139, 17);
            this.chkBX.TabIndex = 6;
            this.chkBX.Text = "Builders merchant credit";
            this.chkBX.UseVisualStyleBackColor = true;
            this.chkBX.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkGL
            // 
            this.chkGL.AutoSize = true;
            this.chkGL.Location = new System.Drawing.Point(228, 86);
            this.chkGL.Name = "chkGL";
            this.chkGL.Size = new System.Drawing.Size(109, 17);
            this.chkGL.TabIndex = 5;
            this.chkGL.Text = "Guarantee liability";
            this.chkGL.UseVisualStyleBackColor = true;
            this.chkGL.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkSS
            // 
            this.chkSS.AutoSize = true;
            this.chkSS.Location = new System.Drawing.Point(228, 109);
            this.chkSS.Name = "chkSS";
            this.chkSS.Size = new System.Drawing.Size(112, 17);
            this.chkSS.TabIndex = 4;
            this.chkSS.Text = "Stationary supplier";
            this.chkSS.UseVisualStyleBackColor = true;
            this.chkSS.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkTR
            // 
            this.chkTR.AutoSize = true;
            this.chkTR.Location = new System.Drawing.Point(228, 178);
            this.chkTR.Name = "chkTR";
            this.chkTR.Size = new System.Drawing.Size(83, 17);
            this.chkTR.TabIndex = 3;
            this.chkTR.Text = "Trade credit";
            this.chkTR.UseVisualStyleBackColor = true;
            this.chkTR.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkAD
            // 
            this.chkAD.AutoSize = true;
            this.chkAD.Location = new System.Drawing.Point(14, 224);
            this.chkAD.Name = "chkAD";
            this.chkAD.Size = new System.Drawing.Size(109, 17);
            this.chkAD.TabIndex = 2;
            this.chkAD.Text = "Asset discounting";
            this.chkAD.UseVisualStyleBackColor = true;
            this.chkAD.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkVS
            // 
            this.chkVS.AutoSize = true;
            this.chkVS.Location = new System.Drawing.Point(228, 201);
            this.chkVS.Name = "chkVS";
            this.chkVS.Size = new System.Drawing.Size(123, 17);
            this.chkVS.TabIndex = 1;
            this.chkVS.Text = "Variable subscription";
            this.chkVS.UseVisualStyleBackColor = true;
            this.chkVS.Click += new System.EventHandler(this.ItemChanged);
            // 
            // chkMC
            // 
            this.chkMC.AutoSize = true;
            this.chkMC.Location = new System.Drawing.Point(14, 17);
            this.chkMC.Name = "chkMC";
            this.chkMC.Size = new System.Drawing.Size(118, 17);
            this.chkMC.TabIndex = 0;
            this.chkMC.Text = "Multifunctional card";
            this.chkMC.UseVisualStyleBackColor = true;
            this.chkMC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlLoan
            // 
            this.pnlLoan.Controls.Add(this.chkOL);
            this.pnlLoan.Controls.Add(this.chkFL);
            this.pnlLoan.Controls.Add(this.chkUL);
            this.pnlLoan.Controls.Add(this.chkBA);
            this.pnlLoan.Controls.Add(this.chkFD);
            this.pnlLoan.Controls.Add(this.chkSL);
            this.pnlLoan.Controls.Add(this.chkCP);
            this.pnlLoan.Controls.Add(this.chkRG);
            this.pnlLoan.Controls.Add(this.chkTL);
            this.pnlLoan.Controls.Add(this.chkML);
            this.pnlLoan.Controls.Add(this.chkCS);
            this.pnlLoan.Controls.Add(this.chkSC);
            this.pnlLoan.Controls.Add(this.chkBL);
            this.pnlLoan.Controls.Add(this.chkSB);
            this.pnlLoan.Controls.Add(this.chkLP);
            this.pnlLoan.Controls.Add(this.chkZL);
            this.pnlLoan.Controls.Add(this.chkPL);
            this.pnlLoan.Controls.Add(this.chkBN);
            this.pnlLoan.Controls.Add(this.chkEL);
            this.pnlLoan.Controls.Add(this.chkFS);
            this.pnlLoan.Controls.Add(this.chkSO);
            this.pnlLoan.Controls.Add(this.chkHP);
            this.pnlLoan.Controls.Add(this.chkBR);
            this.pnlLoan.Controls.Add(this.chkLS);
            this.pnlLoan.Controls.Add(this.chkZH);
            this.pnlLoan.Controls.Add(this.chkPR);
            this.pnlLoan.Controls.Add(this.chkIL);
            this.pnlLoan.Controls.Add(this.chkBH);
            this.pnlLoan.Controls.Add(this.chkCX);
            this.pnlLoan.Controls.Add(this.chkCY);
            this.pnlLoan.Controls.Add(this.chkRT);
            this.pnlLoan.Controls.Add(this.chkCR);
            this.pnlLoan.Controls.Add(this.chkDH);
            this.pnlLoan.Controls.Add(this.chkLN);
            this.pnlLoan.Location = new System.Drawing.Point(0, 38);
            this.pnlLoan.Name = "pnlLoan";
            this.pnlLoan.Size = new System.Drawing.Size(575, 431);
            this.pnlLoan.TabIndex = 2;
            // 
            // chkOL
            // 
            this.chkOL.AutoSize = true;
            this.chkOL.Location = new System.Drawing.Point(237, 387);
            this.chkOL.Name = "chkOL";
            this.chkOL.Size = new System.Drawing.Size(100, 17);
            this.chkOL.TabIndex = 33;
            this.chkOL.Text = "Operating lease";
            this.chkOL.UseVisualStyleBackColor = true;
            this.chkOL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkFL
            // 
            this.chkFL.AutoSize = true;
            this.chkFL.Location = new System.Drawing.Point(237, 363);
            this.chkFL.Name = "chkFL";
            this.chkFL.Size = new System.Drawing.Size(92, 17);
            this.chkFL.TabIndex = 32;
            this.chkFL.Text = "Finance lease";
            this.chkFL.UseVisualStyleBackColor = true;
            this.chkFL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkUL
            // 
            this.chkUL.AutoSize = true;
            this.chkUL.Location = new System.Drawing.Point(14, 40);
            this.chkUL.Name = "chkUL";
            this.chkUL.Size = new System.Drawing.Size(101, 17);
            this.chkUL.TabIndex = 31;
            this.chkUL.Text = "Unsecured loan";
            this.chkUL.UseVisualStyleBackColor = true;
            this.chkUL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBA
            // 
            this.chkBA.AutoSize = true;
            this.chkBA.Location = new System.Drawing.Point(14, 63);
            this.chkBA.Name = "chkBA";
            this.chkBA.Size = new System.Drawing.Size(136, 17);
            this.chkBA.TabIndex = 30;
            this.chkBA.Text = "Balloon repayment loan";
            this.chkBA.UseVisualStyleBackColor = true;
            this.chkBA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkFD
            // 
            this.chkFD.AutoSize = true;
            this.chkFD.Location = new System.Drawing.Point(14, 86);
            this.chkFD.Name = "chkFD";
            this.chkFD.Size = new System.Drawing.Size(182, 17);
            this.chkFD.TabIndex = 29;
            this.chkFD.Text = "Fixed term deferred payment loan";
            this.chkFD.UseVisualStyleBackColor = true;
            this.chkFD.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSL
            // 
            this.chkSL.AutoSize = true;
            this.chkSL.Location = new System.Drawing.Point(14, 109);
            this.chkSL.Name = "chkSL";
            this.chkSL.Size = new System.Drawing.Size(86, 17);
            this.chkSL.TabIndex = 28;
            this.chkSL.Text = "Student loan";
            this.chkSL.UseVisualStyleBackColor = true;
            this.chkSL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCP
            // 
            this.chkCP.AutoSize = true;
            this.chkCP.Location = new System.Drawing.Point(14, 132);
            this.chkCP.Name = "chkCP";
            this.chkCP.Size = new System.Drawing.Size(156, 17);
            this.chkCP.TabIndex = 27;
            this.chkCP.Text = "Personal contract purchase";
            this.chkCP.UseVisualStyleBackColor = true;
            this.chkCP.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkRG
            // 
            this.chkRG.AutoSize = true;
            this.chkRG.Location = new System.Drawing.Point(14, 155);
            this.chkRG.Name = "chkRG";
            this.chkRG.Size = new System.Drawing.Size(102, 17);
            this.chkRG.TabIndex = 26;
            this.chkRG.Text = "repayment grant";
            this.chkRG.UseVisualStyleBackColor = true;
            this.chkRG.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkTL
            // 
            this.chkTL.AutoSize = true;
            this.chkTL.Location = new System.Drawing.Point(14, 178);
            this.chkTL.Name = "chkTL";
            this.chkTL.Size = new System.Drawing.Size(73, 17);
            this.chkTL.TabIndex = 25;
            this.chkTL.Text = "Term loan";
            this.chkTL.UseVisualStyleBackColor = true;
            this.chkTL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkML
            // 
            this.chkML.AutoSize = true;
            this.chkML.Location = new System.Drawing.Point(14, 201);
            this.chkML.Name = "chkML";
            this.chkML.Size = new System.Drawing.Size(158, 17);
            this.chkML.TabIndex = 24;
            this.chkML.Text = "Motor finance loan - general";
            this.chkML.UseVisualStyleBackColor = true;
            this.chkML.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCS
            // 
            this.chkCS.AutoSize = true;
            this.chkCS.Location = new System.Drawing.Point(14, 224);
            this.chkCS.Name = "chkCS";
            this.chkCS.Size = new System.Drawing.Size(119, 17);
            this.chkCS.TabIndex = 23;
            this.chkCS.Text = "Unsecured car loan";
            this.chkCS.UseVisualStyleBackColor = true;
            this.chkCS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSC
            // 
            this.chkSC.AutoSize = true;
            this.chkSC.Location = new System.Drawing.Point(14, 247);
            this.chkSC.Name = "chkSC";
            this.chkSC.Size = new System.Drawing.Size(107, 17);
            this.chkSC.TabIndex = 22;
            this.chkSC.Text = "Secured car loan";
            this.chkSC.UseVisualStyleBackColor = true;
            this.chkSC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBL
            // 
            this.chkBL.AutoSize = true;
            this.chkBL.Location = new System.Drawing.Point(14, 270);
            this.chkBL.Name = "chkBL";
            this.chkBL.Size = new System.Drawing.Size(145, 17);
            this.chkBL.TabIndex = 21;
            this.chkBL.Text = "Unsecured business loan";
            this.chkBL.UseVisualStyleBackColor = true;
            this.chkBL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSB
            // 
            this.chkSB.AutoSize = true;
            this.chkSB.Location = new System.Drawing.Point(14, 293);
            this.chkSB.Name = "chkSB";
            this.chkSB.Size = new System.Drawing.Size(133, 17);
            this.chkSB.TabIndex = 20;
            this.chkSB.Text = "Secured business loan";
            this.chkSB.UseVisualStyleBackColor = true;
            this.chkSB.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkLP
            // 
            this.chkLP.AutoSize = true;
            this.chkLP.Location = new System.Drawing.Point(14, 316);
            this.chkLP.Name = "chkLP";
            this.chkLP.Size = new System.Drawing.Size(96, 17);
            this.chkLP.TabIndex = 19;
            this.chkLP.Text = "Life policy loan";
            this.chkLP.UseVisualStyleBackColor = true;
            this.chkLP.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkZL
            // 
            this.chkZL.AutoSize = true;
            this.chkZL.Location = new System.Drawing.Point(14, 339);
            this.chkZL.Name = "chkZL";
            this.chkZL.Size = new System.Drawing.Size(101, 17);
            this.chkZL.TabIndex = 18;
            this.chkZL.Text = "0% finance loan";
            this.chkZL.UseVisualStyleBackColor = true;
            this.chkZL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkPL
            // 
            this.chkPL.AutoSize = true;
            this.chkPL.Location = new System.Drawing.Point(14, 385);
            this.chkPL.Name = "chkPL";
            this.chkPL.Size = new System.Drawing.Size(96, 17);
            this.chkPL.TabIndex = 17;
            this.chkPL.Text = "Petroleum loan";
            this.chkPL.UseVisualStyleBackColor = true;
            this.chkPL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBN
            // 
            this.chkBN.AutoSize = true;
            this.chkBN.Location = new System.Drawing.Point(237, 16);
            this.chkBN.Name = "chkBN";
            this.chkBN.Size = new System.Drawing.Size(110, 17);
            this.chkBN.TabIndex = 16;
            this.chkBN.Text = "Buy now pay later";
            this.chkBN.UseVisualStyleBackColor = true;
            this.chkBN.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkEL
            // 
            this.chkEL.AutoSize = true;
            this.chkEL.Location = new System.Drawing.Point(237, 39);
            this.chkEL.Name = "chkEL";
            this.chkEL.Size = new System.Drawing.Size(92, 17);
            this.chkEL.TabIndex = 15;
            this.chkEL.Text = "Employer loan";
            this.chkEL.UseVisualStyleBackColor = true;
            this.chkEL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkFS
            // 
            this.chkFS.AutoSize = true;
            this.chkFS.Location = new System.Drawing.Point(237, 62);
            this.chkFS.Name = "chkFS";
            this.chkFS.Size = new System.Drawing.Size(123, 17);
            this.chkFS.TabIndex = 14;
            this.chkFS.Text = "Further secured loan";
            this.chkFS.UseVisualStyleBackColor = true;
            this.chkFS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSO
            // 
            this.chkSO.AutoSize = true;
            this.chkSO.Location = new System.Drawing.Point(237, 85);
            this.chkSO.Name = "chkSO";
            this.chkSO.Size = new System.Drawing.Size(80, 17);
            this.chkSO.TabIndex = 13;
            this.chkSO.Text = "Set off loan";
            this.chkSO.UseVisualStyleBackColor = true;
            this.chkSO.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHP
            // 
            this.chkHP.AutoSize = true;
            this.chkHP.Location = new System.Drawing.Point(237, 131);
            this.chkHP.Name = "chkHP";
            this.chkHP.Size = new System.Drawing.Size(92, 17);
            this.chkHP.TabIndex = 12;
            this.chkHP.Text = "Hire purchase";
            this.chkHP.UseVisualStyleBackColor = true;
            this.chkHP.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBR
            // 
            this.chkBR.AutoSize = true;
            this.chkBR.Location = new System.Drawing.Point(14, 362);
            this.chkBR.Name = "chkBR";
            this.chkBR.Size = new System.Drawing.Size(87, 17);
            this.chkBR.TabIndex = 11;
            this.chkBR.Text = "Brewery loan";
            this.chkBR.UseVisualStyleBackColor = true;
            this.chkBR.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkLS
            // 
            this.chkLS.AutoSize = true;
            this.chkLS.Location = new System.Drawing.Point(237, 339);
            this.chkLS.Name = "chkLS";
            this.chkLS.Size = new System.Drawing.Size(55, 17);
            this.chkLS.TabIndex = 10;
            this.chkLS.Text = "Lease";
            this.chkLS.UseVisualStyleBackColor = true;
            this.chkLS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkZH
            // 
            this.chkZH.AutoSize = true;
            this.chkZH.Location = new System.Drawing.Point(237, 200);
            this.chkZH.Name = "chkZH";
            this.chkZH.Size = new System.Drawing.Size(58, 17);
            this.chkZH.TabIndex = 9;
            this.chkZH.Text = "0% HP";
            this.chkZH.UseVisualStyleBackColor = true;
            this.chkZH.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkPR
            // 
            this.chkPR.AutoSize = true;
            this.chkPR.Location = new System.Drawing.Point(237, 316);
            this.chkPR.Name = "chkPR";
            this.chkPR.Size = new System.Drawing.Size(94, 17);
            this.chkPR.TabIndex = 8;
            this.chkPR.Text = "Property rental";
            this.chkPR.UseVisualStyleBackColor = true;
            this.chkPR.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkIL
            // 
            this.chkIL.AutoSize = true;
            this.chkIL.Location = new System.Drawing.Point(237, 108);
            this.chkIL.Name = "chkIL";
            this.chkIL.Size = new System.Drawing.Size(143, 17);
            this.chkIL.TabIndex = 7;
            this.chkIL.Text = "Advance against income";
            this.chkIL.UseVisualStyleBackColor = true;
            this.chkIL.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBH
            // 
            this.chkBH.AutoSize = true;
            this.chkBH.Location = new System.Drawing.Point(237, 153);
            this.chkBH.Name = "chkBH";
            this.chkBH.Size = new System.Drawing.Size(79, 17);
            this.chkBH.TabIndex = 6;
            this.chkBH.Text = "Balloon HP";
            this.chkBH.UseVisualStyleBackColor = true;
            this.chkBH.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCX
            // 
            this.chkCX.AutoSize = true;
            this.chkCX.Location = new System.Drawing.Point(237, 224);
            this.chkCX.Name = "chkCX";
            this.chkCX.Size = new System.Drawing.Size(75, 17);
            this.chkCX.TabIndex = 5;
            this.chkCX.Text = "Credit sale";
            this.chkCX.UseVisualStyleBackColor = true;
            this.chkCX.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCY
            // 
            this.chkCY.AutoSize = true;
            this.chkCY.Location = new System.Drawing.Point(237, 247);
            this.chkCY.Name = "chkCY";
            this.chkCY.Size = new System.Drawing.Size(100, 17);
            this.chkCY.TabIndex = 4;
            this.chkCY.Text = "Conditional sale";
            this.chkCY.UseVisualStyleBackColor = true;
            this.chkCY.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkRT
            // 
            this.chkRT.AutoSize = true;
            this.chkRT.Location = new System.Drawing.Point(237, 270);
            this.chkRT.Name = "chkRT";
            this.chkRT.Size = new System.Drawing.Size(154, 17);
            this.chkRT.TabIndex = 3;
            this.chkRT.Text = "Rental agreement (general)";
            this.chkRT.UseVisualStyleBackColor = true;
            this.chkRT.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCR
            // 
            this.chkCR.AutoSize = true;
            this.chkCR.Location = new System.Drawing.Point(237, 293);
            this.chkCR.Name = "chkCR";
            this.chkCR.Size = new System.Drawing.Size(134, 17);
            this.chkCR.TabIndex = 2;
            this.chkCR.Text = "Consumer goods rental";
            this.chkCR.UseVisualStyleBackColor = true;
            this.chkCR.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkDH
            // 
            this.chkDH.AutoSize = true;
            this.chkDH.Location = new System.Drawing.Point(237, 177);
            this.chkDH.Name = "chkDH";
            this.chkDH.Size = new System.Drawing.Size(85, 17);
            this.chkDH.TabIndex = 1;
            this.chkDH.Text = "Deferred HP";
            this.chkDH.UseVisualStyleBackColor = true;
            this.chkDH.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkLN
            // 
            this.chkLN.AutoSize = true;
            this.chkLN.Location = new System.Drawing.Point(14, 17);
            this.chkLN.Name = "chkLN";
            this.chkLN.Size = new System.Drawing.Size(136, 17);
            this.chkLN.TabIndex = 0;
            this.chkLN.Text = "Loan (unspecified type)";
            this.chkLN.UseVisualStyleBackColor = true;
            this.chkLN.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlInternet
            // 
            this.pnlInternet.Controls.Add(this.chkIS);
            this.pnlInternet.Controls.Add(this.chkIC);
            this.pnlInternet.Location = new System.Drawing.Point(0, 38);
            this.pnlInternet.Name = "pnlInternet";
            this.pnlInternet.Size = new System.Drawing.Size(575, 400);
            this.pnlInternet.TabIndex = 1;
            // 
            // chkIS
            // 
            this.chkIS.AutoSize = true;
            this.chkIS.Location = new System.Drawing.Point(14, 40);
            this.chkIS.Name = "chkIS";
            this.chkIS.Size = new System.Drawing.Size(108, 17);
            this.chkIS.TabIndex = 2;
            this.chkIS.Text = "Internet shopping";
            this.chkIS.UseVisualStyleBackColor = true;
            this.chkIS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkIC
            // 
            this.chkIC.AutoSize = true;
            this.chkIC.Location = new System.Drawing.Point(14, 17);
            this.chkIC.Name = "chkIC";
            this.chkIC.Size = new System.Drawing.Size(110, 17);
            this.chkIC.TabIndex = 1;
            this.chkIC.Text = "Internet credit line";
            this.chkIC.UseVisualStyleBackColor = true;
            this.chkIC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlInsurance
            // 
            this.pnlInsurance.Controls.Add(this.chkPI);
            this.pnlInsurance.Controls.Add(this.chkMI);
            this.pnlInsurance.Controls.Add(this.chkHI);
            this.pnlInsurance.Controls.Add(this.chkCI);
            this.pnlInsurance.Controls.Add(this.chkBI);
            this.pnlInsurance.Controls.Add(this.chkGI);
            this.pnlInsurance.Controls.Add(this.chkIN);
            this.pnlInsurance.Location = new System.Drawing.Point(0, 38);
            this.pnlInsurance.Name = "pnlInsurance";
            this.pnlInsurance.Size = new System.Drawing.Size(575, 431);
            this.pnlInsurance.TabIndex = 1;
            // 
            // chkPI
            // 
            this.chkPI.AutoSize = true;
            this.chkPI.Location = new System.Drawing.Point(14, 155);
            this.chkPI.Name = "chkPI";
            this.chkPI.Size = new System.Drawing.Size(148, 17);
            this.chkPI.TabIndex = 6;
            this.chkPI.Text = "Personal health insurance";
            this.chkPI.UseVisualStyleBackColor = true;
            this.chkPI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkMI
            // 
            this.chkMI.AutoSize = true;
            this.chkMI.Location = new System.Drawing.Point(14, 132);
            this.chkMI.Name = "chkMI";
            this.chkMI.Size = new System.Drawing.Size(102, 17);
            this.chkMI.TabIndex = 5;
            this.chkMI.Text = "Motor insurance";
            this.chkMI.UseVisualStyleBackColor = true;
            this.chkMI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHI
            // 
            this.chkHI.AutoSize = true;
            this.chkHI.Location = new System.Drawing.Point(14, 109);
            this.chkHI.Name = "chkHI";
            this.chkHI.Size = new System.Drawing.Size(126, 17);
            this.chkHI.TabIndex = 4;
            this.chkHI.Text = "Household insurance";
            this.chkHI.UseVisualStyleBackColor = true;
            this.chkHI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCI
            // 
            this.chkCI.AutoSize = true;
            this.chkCI.Location = new System.Drawing.Point(14, 86);
            this.chkCI.Name = "chkCI";
            this.chkCI.Size = new System.Drawing.Size(117, 17);
            this.chkCI.TabIndex = 3;
            this.chkCI.Text = "Contents insurance";
            this.chkCI.UseVisualStyleBackColor = true;
            this.chkCI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBI
            // 
            this.chkBI.AutoSize = true;
            this.chkBI.Location = new System.Drawing.Point(14, 63);
            this.chkBI.Name = "chkBI";
            this.chkBI.Size = new System.Drawing.Size(117, 17);
            this.chkBI.TabIndex = 2;
            this.chkBI.Text = "Buildings insurance";
            this.chkBI.UseVisualStyleBackColor = true;
            this.chkBI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkGI
            // 
            this.chkGI.AutoSize = true;
            this.chkGI.Location = new System.Drawing.Point(14, 40);
            this.chkGI.Name = "chkGI";
            this.chkGI.Size = new System.Drawing.Size(112, 17);
            this.chkGI.TabIndex = 1;
            this.chkGI.Text = "General insurance";
            this.chkGI.UseVisualStyleBackColor = true;
            this.chkGI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkIN
            // 
            this.chkIN.AutoSize = true;
            this.chkIN.Location = new System.Drawing.Point(14, 17);
            this.chkIN.Name = "chkIN";
            this.chkIN.Size = new System.Drawing.Size(73, 17);
            this.chkIN.TabIndex = 0;
            this.chkIN.Text = "Insurance";
            this.chkIN.UseVisualStyleBackColor = true;
            this.chkIN.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlHomeShopping
            // 
            this.pnlHomeShopping.Controls.Add(this.chkMO);
            this.pnlHomeShopping.Controls.Add(this.chkMA);
            this.pnlHomeShopping.Controls.Add(this.chkTV);
            this.pnlHomeShopping.Controls.Add(this.chkHC);
            this.pnlHomeShopping.Controls.Add(this.chkHD);
            this.pnlHomeShopping.Controls.Add(this.chkHX);
            this.pnlHomeShopping.Controls.Add(this.chkHA);
            this.pnlHomeShopping.Controls.Add(this.chkWI);
            this.pnlHomeShopping.Controls.Add(this.chkBC);
            this.pnlHomeShopping.Controls.Add(this.chkHS);
            this.pnlHomeShopping.Location = new System.Drawing.Point(0, 38);
            this.pnlHomeShopping.Name = "pnlHomeShopping";
            this.pnlHomeShopping.Size = new System.Drawing.Size(575, 431);
            this.pnlHomeShopping.TabIndex = 1;
            // 
            // chkMO
            // 
            this.chkMO.AutoSize = true;
            this.chkMO.Location = new System.Drawing.Point(14, 40);
            this.chkMO.Name = "chkMO";
            this.chkMO.Size = new System.Drawing.Size(72, 17);
            this.chkMO.TabIndex = 9;
            this.chkMO.Text = "Mail order";
            this.chkMO.UseVisualStyleBackColor = true;
            this.chkMO.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkMA
            // 
            this.chkMA.AutoSize = true;
            this.chkMA.Location = new System.Drawing.Point(14, 63);
            this.chkMA.Name = "chkMA";
            this.chkMA.Size = new System.Drawing.Size(110, 17);
            this.chkMA.TabIndex = 8;
            this.chkMA.Text = "Mail order agency";
            this.chkMA.UseVisualStyleBackColor = true;
            this.chkMA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkTV
            // 
            this.chkTV.AutoSize = true;
            this.chkTV.Location = new System.Drawing.Point(14, 86);
            this.chkTV.Name = "chkTV";
            this.chkTV.Size = new System.Drawing.Size(86, 17);
            this.chkTV.TabIndex = 7;
            this.chkTV.Text = "TV shopping";
            this.chkTV.UseVisualStyleBackColor = true;
            this.chkTV.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHC
            // 
            this.chkHC.AutoSize = true;
            this.chkHC.Location = new System.Drawing.Point(14, 109);
            this.chkHC.Name = "chkHC";
            this.chkHC.Size = new System.Drawing.Size(83, 17);
            this.chkHC.TabIndex = 6;
            this.chkHC.Text = "Home credit";
            this.chkHC.UseVisualStyleBackColor = true;
            this.chkHC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHD
            // 
            this.chkHD.AutoSize = true;
            this.chkHD.Location = new System.Drawing.Point(14, 132);
            this.chkHD.Name = "chkHD";
            this.chkHD.Size = new System.Drawing.Size(129, 17);
            this.chkHD.TabIndex = 5;
            this.chkHD.Text = "Home shopping direct";
            this.chkHD.UseVisualStyleBackColor = true;
            this.chkHD.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHX
            // 
            this.chkHX.AutoSize = true;
            this.chkHX.Location = new System.Drawing.Point(14, 155);
            this.chkHX.Name = "chkHX";
            this.chkHX.Size = new System.Drawing.Size(126, 17);
            this.chkHX.TabIndex = 4;
            this.chkHX.Text = "Home shopping cash";
            this.chkHX.UseVisualStyleBackColor = true;
            this.chkHX.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHA
            // 
            this.chkHA.AutoSize = true;
            this.chkHA.Location = new System.Drawing.Point(14, 178);
            this.chkHA.Name = "chkHA";
            this.chkHA.Size = new System.Drawing.Size(138, 17);
            this.chkHA.TabIndex = 3;
            this.chkHA.Text = "Home shopping agency";
            this.chkHA.UseVisualStyleBackColor = true;
            this.chkHA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkWI
            // 
            this.chkWI.AutoSize = true;
            this.chkWI.Location = new System.Drawing.Point(14, 201);
            this.chkWI.Name = "chkWI";
            this.chkWI.Size = new System.Drawing.Size(137, 17);
            this.chkWI.TabIndex = 2;
            this.chkWI.Text = "Weekly installment plan";
            this.chkWI.UseVisualStyleBackColor = true;
            this.chkWI.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBC
            // 
            this.chkBC.AutoSize = true;
            this.chkBC.Location = new System.Drawing.Point(14, 224);
            this.chkBC.Name = "chkBC";
            this.chkBC.Size = new System.Drawing.Size(137, 17);
            this.chkBC.TabIndex = 1;
            this.chkBC.Text = "Book/music/video club";
            this.chkBC.UseVisualStyleBackColor = true;
            this.chkBC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkHS
            // 
            this.chkHS.AutoSize = true;
            this.chkHS.Location = new System.Drawing.Point(14, 17);
            this.chkHS.Name = "chkHS";
            this.chkHS.Size = new System.Drawing.Size(100, 17);
            this.chkHS.TabIndex = 0;
            this.chkHS.Text = "Home shopping";
            this.chkHS.UseVisualStyleBackColor = true;
            this.chkHS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlCredit
            // 
            this.pnlCredit.Controls.Add(this.chkCO);
            this.pnlCredit.Controls.Add(this.chkST);
            this.pnlCredit.Controls.Add(this.chkRS);
            this.pnlCredit.Controls.Add(this.chkFC);
            this.pnlCredit.Controls.Add(this.chkCH);
            this.pnlCredit.Controls.Add(this.chkBD);
            this.pnlCredit.Controls.Add(this.chkCC);
            this.pnlCredit.Location = new System.Drawing.Point(0, 38);
            this.pnlCredit.Name = "pnlCredit";
            this.pnlCredit.Size = new System.Drawing.Size(575, 431);
            this.pnlCredit.TabIndex = 1;
            // 
            // chkCO
            // 
            this.chkCO.AutoSize = true;
            this.chkCO.Location = new System.Drawing.Point(14, 40);
            this.chkCO.Name = "chkCO";
            this.chkCO.Size = new System.Drawing.Size(271, 17);
            this.chkCO.TabIndex = 6;
            this.chkCO.Text = "Company credit card (individual responsible for debt)";
            this.chkCO.UseVisualStyleBackColor = true;
            this.chkCO.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkST
            // 
            this.chkST.AutoSize = true;
            this.chkST.Location = new System.Drawing.Point(14, 63);
            this.chkST.Name = "chkST";
            this.chkST.Size = new System.Drawing.Size(75, 17);
            this.chkST.TabIndex = 5;
            this.chkST.Text = "Store card";
            this.chkST.UseVisualStyleBackColor = true;
            this.chkST.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkRS
            // 
            this.chkRS.AutoSize = true;
            this.chkRS.Location = new System.Drawing.Point(14, 86);
            this.chkRS.Name = "chkRS";
            this.chkRS.Size = new System.Drawing.Size(103, 17);
            this.chkRS.TabIndex = 4;
            this.chkRS.Text = "Retail store card";
            this.chkRS.UseVisualStyleBackColor = true;
            this.chkRS.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkFC
            // 
            this.chkFC.AutoSize = true;
            this.chkFC.Location = new System.Drawing.Point(14, 109);
            this.chkFC.Name = "chkFC";
            this.chkFC.Size = new System.Drawing.Size(218, 17);
            this.chkFC.TabIndex = 3;
            this.chkFC.Text = "Fuel card (individual responsible for debt)";
            this.chkFC.UseVisualStyleBackColor = true;
            this.chkFC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCH
            // 
            this.chkCH.AutoSize = true;
            this.chkCH.Location = new System.Drawing.Point(14, 132);
            this.chkCH.Name = "chkCH";
            this.chkCH.Size = new System.Drawing.Size(84, 17);
            this.chkCH.TabIndex = 2;
            this.chkCH.Text = "Charge card";
            this.chkCH.UseVisualStyleBackColor = true;
            this.chkCH.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBD
            // 
            this.chkBD.AutoSize = true;
            this.chkBD.Location = new System.Drawing.Point(14, 155);
            this.chkBD.Name = "chkBD";
            this.chkBD.Size = new System.Drawing.Size(102, 17);
            this.chkBD.TabIndex = 1;
            this.chkBD.Text = "Budget account";
            this.chkBD.UseVisualStyleBackColor = true;
            this.chkBD.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCC
            // 
            this.chkCC.AutoSize = true;
            this.chkCC.Location = new System.Drawing.Point(14, 17);
            this.chkCC.Name = "chkCC";
            this.chkCC.Size = new System.Drawing.Size(77, 17);
            this.chkCC.TabIndex = 0;
            this.chkCC.Text = "Credit card";
            this.chkCC.UseVisualStyleBackColor = true;
            this.chkCC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // pnlBank
            // 
            this.pnlBank.Controls.Add(this.chkOD);
            this.pnlBank.Controls.Add(this.chkSX);
            this.pnlBank.Controls.Add(this.chkRQ);
            this.pnlBank.Controls.Add(this.chkBK);
            this.pnlBank.Controls.Add(this.chkDF);
            this.pnlBank.Controls.Add(this.chkDC);
            this.pnlBank.Controls.Add(this.chkCA);
            this.pnlBank.Location = new System.Drawing.Point(0, 38);
            this.pnlBank.Name = "pnlBank";
            this.pnlBank.Size = new System.Drawing.Size(575, 431);
            this.pnlBank.TabIndex = 3;
            // 
            // chkOD
            // 
            this.chkOD.AutoSize = true;
            this.chkOD.Location = new System.Drawing.Point(13, 41);
            this.chkOD.Name = "chkOD";
            this.chkOD.Size = new System.Drawing.Size(70, 17);
            this.chkOD.TabIndex = 6;
            this.chkOD.Text = "Overdraft";
            this.chkOD.UseVisualStyleBackColor = true;
            this.chkOD.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkSX
            // 
            this.chkSX.AutoSize = true;
            this.chkSX.Location = new System.Drawing.Point(13, 86);
            this.chkSX.Name = "chkSX";
            this.chkSX.Size = new System.Drawing.Size(135, 17);
            this.chkSX.TabIndex = 5;
            this.chkSX.Text = "Set off current account";
            this.chkSX.UseVisualStyleBackColor = true;
            this.chkSX.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkRQ
            // 
            this.chkRQ.AutoSize = true;
            this.chkRQ.Location = new System.Drawing.Point(13, 109);
            this.chkRQ.Name = "chkRQ";
            this.chkRQ.Size = new System.Drawing.Size(109, 17);
            this.chkRQ.TabIndex = 4;
            this.chkRQ.Text = "Returned cheque";
            this.chkRQ.UseVisualStyleBackColor = true;
            this.chkRQ.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkBK
            // 
            this.chkBK.AutoSize = true;
            this.chkBK.Location = new System.Drawing.Point(13, 132);
            this.chkBK.Name = "chkBK";
            this.chkBK.Size = new System.Drawing.Size(51, 17);
            this.chkBK.TabIndex = 3;
            this.chkBK.Text = "Bank";
            this.chkBK.UseVisualStyleBackColor = true;
            this.chkBK.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkDF
            // 
            this.chkDF.AutoSize = true;
            this.chkDF.Location = new System.Drawing.Point(13, 155);
            this.chkDF.Name = "chkDF";
            this.chkDF.Size = new System.Drawing.Size(88, 17);
            this.chkDF.TabIndex = 2;
            this.chkDF.Text = "Bank Default";
            this.chkDF.UseVisualStyleBackColor = true;
            this.chkDF.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkDC
            // 
            this.chkDC.AutoSize = true;
            this.chkDC.Location = new System.Drawing.Point(13, 64);
            this.chkDC.Name = "chkDC";
            this.chkDC.Size = new System.Drawing.Size(75, 17);
            this.chkDC.TabIndex = 1;
            this.chkDC.Text = "Debit card";
            this.chkDC.UseVisualStyleBackColor = true;
            this.chkDC.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // chkCA
            // 
            this.chkCA.AutoSize = true;
            this.chkCA.Location = new System.Drawing.Point(13, 19);
            this.chkCA.Name = "chkCA";
            this.chkCA.Size = new System.Drawing.Size(102, 17);
            this.chkCA.TabIndex = 0;
            this.chkCA.Text = "Current account";
            this.chkCA.UseVisualStyleBackColor = true;
            this.chkCA.CheckedChanged += new System.EventHandler(this.ItemChanged);
            // 
            // cboAccountType
            // 
            this.cboAccountType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboAccountType.FormattingEnabled = true;
            this.cboAccountType.Items.AddRange(new object[] {
            "Loan & Installment Credit",
            "Mortgage",
            "Revolving Credit & Budget",
            "Telecommunications",
            "Utilities",
            "Home Shopping",
            "Bank",
            "Miscellaneous",
            "Insurance",
            "Internet"});
            this.cboAccountType.Location = new System.Drawing.Point(124, 11);
            this.cboAccountType.Name = "cboAccountType";
            this.cboAccountType.Size = new System.Drawing.Size(215, 21);
            this.cboAccountType.TabIndex = 2;
            this.cboAccountType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Account type group";
            // 
            // MLConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(583, 555);
            this.Controls.Add(this.tabOptions);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "MLConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CallML Configuration";
            this.Load += new System.EventHandler(this.MLConfig_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MLConfig_FormClosing);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.spnDaysEligible)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnMinChecks)).EndInit();
            this.grpGeneral.ResumeLayout(false);
            this.grpGeneral.PerformLayout();
            this.grpPDFLinks.ResumeLayout(false);
            this.grpPDFLinks.PerformLayout();
            this.tabOptions.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.updPasswordReminder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnSecurityLevel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spnExpiryDays)).EndInit();
            this.grpMatchWarning.ResumeLayout(false);
            this.grpMatchWarning.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.pnlUtilities.ResumeLayout(false);
            this.pnlUtilities.PerformLayout();
            this.pnlTelecoms.ResumeLayout(false);
            this.pnlTelecoms.PerformLayout();
            this.pnlMortgage.ResumeLayout(false);
            this.pnlMortgage.PerformLayout();
            this.pnlMiscellaneous.ResumeLayout(false);
            this.pnlMiscellaneous.PerformLayout();
            this.pnlLoan.ResumeLayout(false);
            this.pnlLoan.PerformLayout();
            this.pnlInternet.ResumeLayout(false);
            this.pnlInternet.PerformLayout();
            this.pnlInsurance.ResumeLayout(false);
            this.pnlInsurance.PerformLayout();
            this.pnlHomeShopping.ResumeLayout(false);
            this.pnlHomeShopping.PerformLayout();
            this.pnlCredit.ResumeLayout(false);
            this.pnlCredit.PerformLayout();
            this.pnlBank.ResumeLayout(false);
            this.pnlBank.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtURL;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCompanyName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cancelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restoreDefaultsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown spnDaysEligible;
        private System.Windows.Forms.NumericUpDown spnMinChecks;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.GroupBox grpGeneral;
        private System.Windows.Forms.CheckBox cbxElectoralRoll;
        private System.Windows.Forms.CheckBox cbxSHARE;
        private System.Windows.Forms.CheckBox cbxUseBAI;
        private System.Windows.Forms.CheckBox cbxFTSE;
        private System.Windows.Forms.CheckBox cbxCCJ;
        private System.Windows.Forms.CheckBox cbxSearchDirectors;
        private System.Windows.Forms.GroupBox grpPDFLinks;
        private System.Windows.Forms.TabControl tabOptions;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox grpMatchWarning;
        private System.Windows.Forms.CheckBox chkWarnResidency;
        private System.Windows.Forms.CheckBox chkWarnDOBOne;
        private System.Windows.Forms.CheckBox chkWarnDOBAll;
        private System.Windows.Forms.CheckBox chkWarnAddressLinks;
        private System.Windows.Forms.CheckBox chkWarnGoneAway;
        private System.Windows.Forms.CheckBox chkWarnDeceased;
        private System.Windows.Forms.CheckBox chkWarnPEP;
        private System.Windows.Forms.CheckBox chkWarnCIFAS;
        private System.Windows.Forms.Panel pnlCredit;
        private System.Windows.Forms.Panel pnlUtilities;
        private System.Windows.Forms.Panel pnlHomeShopping;
        private System.Windows.Forms.Panel pnlMiscellaneous;
        private System.Windows.Forms.Panel pnlInsurance;
        private System.Windows.Forms.Panel pnlInternet;
        private System.Windows.Forms.CheckBox chkIS;
        private System.Windows.Forms.CheckBox chkIC;
        private System.Windows.Forms.CheckBox chkPI;
        private System.Windows.Forms.CheckBox chkMI;
        private System.Windows.Forms.CheckBox chkHI;
        private System.Windows.Forms.CheckBox chkCI;
        private System.Windows.Forms.CheckBox chkBI;
        private System.Windows.Forms.CheckBox chkGI;
        private System.Windows.Forms.CheckBox chkIN;
        private System.Windows.Forms.CheckBox chkOA;
        private System.Windows.Forms.CheckBox chkSA;
        private System.Windows.Forms.CheckBox chkEC;
        private System.Windows.Forms.CheckBox chkCT;
        private System.Windows.Forms.CheckBox chkLR;
        private System.Windows.Forms.CheckBox chkAF;
        private System.Windows.Forms.CheckBox chkCD;
        private System.Windows.Forms.CheckBox chkFT;
        private System.Windows.Forms.CheckBox chkRC;
        private System.Windows.Forms.CheckBox chkDP;
        private System.Windows.Forms.CheckBox chkZC;
        private System.Windows.Forms.CheckBox chkCZ;
        private System.Windows.Forms.CheckBox chkBX;
        private System.Windows.Forms.CheckBox chkGL;
        private System.Windows.Forms.CheckBox chkSS;
        private System.Windows.Forms.CheckBox chkTR;
        private System.Windows.Forms.CheckBox chkAD;
        private System.Windows.Forms.CheckBox chkVS;
        private System.Windows.Forms.CheckBox chkMC;
        private System.Windows.Forms.Panel pnlBank;
        private System.Windows.Forms.CheckBox chkOD;
        private System.Windows.Forms.CheckBox chkSX;
        private System.Windows.Forms.CheckBox chkRQ;
        private System.Windows.Forms.CheckBox chkBK;
        private System.Windows.Forms.CheckBox chkDF;
        private System.Windows.Forms.CheckBox chkDC;
        private System.Windows.Forms.CheckBox chkCA;
        private System.Windows.Forms.CheckBox chkMO;
        private System.Windows.Forms.CheckBox chkMA;
        private System.Windows.Forms.CheckBox chkTV;
        private System.Windows.Forms.CheckBox chkHC;
        private System.Windows.Forms.CheckBox chkHD;
        private System.Windows.Forms.CheckBox chkHX;
        private System.Windows.Forms.CheckBox chkHA;
        private System.Windows.Forms.CheckBox chkWI;
        private System.Windows.Forms.CheckBox chkBC;
        private System.Windows.Forms.CheckBox chkHS;
        private System.Windows.Forms.CheckBox chkUE;
        private System.Windows.Forms.CheckBox chkQU;
        private System.Windows.Forms.CheckBox chkGE;
        private System.Windows.Forms.CheckBox chkQG;
        private System.Windows.Forms.CheckBox chkEE;
        private System.Windows.Forms.CheckBox chkQE;
        private System.Windows.Forms.CheckBox chkEW;
        private System.Windows.Forms.CheckBox chkQW;
        private System.Windows.Forms.CheckBox chkUT;
        private System.Windows.Forms.CheckBox chkCO;
        private System.Windows.Forms.CheckBox chkST;
        private System.Windows.Forms.CheckBox chkRS;
        private System.Windows.Forms.CheckBox chkFC;
        private System.Windows.Forms.CheckBox chkCH;
        private System.Windows.Forms.CheckBox chkBD;
        private System.Windows.Forms.CheckBox chkCC;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cboAccountType;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown spnSecurityLevel;
        private System.Windows.Forms.NumericUpDown spnExpiryDays;
        private System.Windows.Forms.ComboBox cboPeriod;
        private System.Windows.Forms.Panel pnlMortgage;
        private System.Windows.Forms.Panel pnlLoan;
        private System.Windows.Forms.Panel pnlTelecoms;
        private System.Windows.Forms.CheckBox chkAM;
        private System.Windows.Forms.CheckBox chkAU;
        private System.Windows.Forms.CheckBox chkQA;
        private System.Windows.Forms.CheckBox chkLT;
        private System.Windows.Forms.CheckBox chkQT;
        private System.Windows.Forms.CheckBox chkTM;
        private System.Windows.Forms.CheckBox chkOL;
        private System.Windows.Forms.CheckBox chkFL;
        private System.Windows.Forms.CheckBox chkUL;
        private System.Windows.Forms.CheckBox chkBA;
        private System.Windows.Forms.CheckBox chkFD;
        private System.Windows.Forms.CheckBox chkSL;
        private System.Windows.Forms.CheckBox chkCP;
        private System.Windows.Forms.CheckBox chkRG;
        private System.Windows.Forms.CheckBox chkTL;
        private System.Windows.Forms.CheckBox chkML;
        private System.Windows.Forms.CheckBox chkCS;
        private System.Windows.Forms.CheckBox chkSC;
        private System.Windows.Forms.CheckBox chkBL;
        private System.Windows.Forms.CheckBox chkSB;
        private System.Windows.Forms.CheckBox chkLP;
        private System.Windows.Forms.CheckBox chkZL;
        private System.Windows.Forms.CheckBox chkPL;
        private System.Windows.Forms.CheckBox chkBN;
        private System.Windows.Forms.CheckBox chkEL;
        private System.Windows.Forms.CheckBox chkFS;
        private System.Windows.Forms.CheckBox chkSO;
        private System.Windows.Forms.CheckBox chkHP;
        private System.Windows.Forms.CheckBox chkBR;
        private System.Windows.Forms.CheckBox chkLS;
        private System.Windows.Forms.CheckBox chkZH;
        private System.Windows.Forms.CheckBox chkPR;
        private System.Windows.Forms.CheckBox chkIL;
        private System.Windows.Forms.CheckBox chkBH;
        private System.Windows.Forms.CheckBox chkCX;
        private System.Windows.Forms.CheckBox chkCY;
        private System.Windows.Forms.CheckBox chkRT;
        private System.Windows.Forms.CheckBox chkCR;
        private System.Windows.Forms.CheckBox chkDH;
        private System.Windows.Forms.CheckBox chkLN;
        private System.Windows.Forms.CheckBox chkFO;
        private System.Windows.Forms.CheckBox chkRM;
        private System.Windows.Forms.CheckBox chkIM;
        private System.Windows.Forms.CheckBox chkMM;
        private System.Windows.Forms.CheckBox chkFM;
        private System.Windows.Forms.CheckBox chkCM;
        private System.Windows.Forms.CheckBox chkBM;
        private System.Windows.Forms.CheckBox chkXM;
        private System.Windows.Forms.CheckBox chkSM;
        private System.Windows.Forms.CheckBox chkNM;
        private System.Windows.Forms.CheckBox chkDM;
        private System.Windows.Forms.CheckBox chkMG;
        private System.Windows.Forms.CheckBox chkWarnUKPassport;
        private System.Windows.Forms.CheckBox chkWarnFraudPassport;
        private System.Windows.Forms.CheckBox chkWarnDrivingLicense;
        private System.Windows.Forms.ComboBox cboPDFDate;
        private System.Windows.Forms.Label lblField;
        private System.Windows.Forms.ComboBox cboPDFScreen;
        private System.Windows.Forms.Label lblScreen;
        private System.Windows.Forms.ToolStripMenuItem changeAccountToolStripMenuItem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown updPasswordReminder;
        private System.Windows.Forms.Button btnUpdateHistory;
    }
}

