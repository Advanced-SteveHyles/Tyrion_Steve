using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CallMLConfig
{
    public partial class ChangePassword : Form
    {
        private string m_CompanyName;
        private string m_Username;
        private string m_URL;

        public ChangePassword(string CompanyName, string UserName, string Password, string URL)
        {
            InitializeComponent();

            m_CompanyName = CompanyName;
            m_Username = UserName;
            //txtOldPassword.Text = Password;
            m_URL = URL;
        }

        public string NewPassword
        {
            get
            {
                return txtNewPassword.Text;
            }
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            // Check that new passwords match
            if (txtNewPassword.Text != txtConfirmNewPassword.Text)
            {
                MessageBox.Show("The passwords you typed do not match. Type the new password in both text boxes.", "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (txtOldPassword.Text == txtNewPassword.Text)
            {
                MessageBox.Show("You have specified the same old and new password. The new password has not been submitted to CallML.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (txtOldPassword.Text == "")
            {
                MessageBox.Show("You must specify an old password.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else if (txtNewPassword.Text == "")
            {
                MessageBox.Show("You must specify a new password.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                // Contact web service

                // Populate header

                CallML6.callcreditheaders callcreditHeaders = new CallML6.callcreditheaders();
                // Assign the login credentials to the callcreditHeaders object properties, with the information input into the form.
                callcreditHeaders.company = m_CompanyName;
                callcreditHeaders.username = m_Username;
                callcreditHeaders.password = txtOldPassword.Text;
            
                // M507 means password change
                //callcreditHeaders.ojjobid = "M507";

                CallML6.CallML6 callMLAdmin = new CallML6.CallML6();

                // We have the URL of the main service. Work out the URL of the admin service.
                // Ideally we should be saving the URL in zzmlconfig but we can't make file changes
                // Main url is like https://www.callcreditsecure.co.uk/services/callml/callml.asmx
                // Admin url is like https://www.callcreditsecure.co.uk/services/callcreditadmin/callcreditadmin.asmx
                string adminURL = m_URL.Replace('\\', '/');
                int callmlIndex = adminURL.IndexOf("/callml/", StringComparison.CurrentCultureIgnoreCase);
                //adminURL = adminURL.Substring(0, callmlIndex) + "/callcreditadmin/callcreditadmin.asmx";
                callMLAdmin.Url = adminURL;

                System.Net.WebProxy proxy = System.Net.WebProxy.GetDefaultProxy();
                proxy.UseDefaultCredentials = true;
                callMLAdmin.Proxy = proxy;

                // Assign the populated callcreditHeaders object to the callCredit.callcreditheadersValue property
                callMLAdmin.callcreditheadersValue = callcreditHeaders;

                // Set a Timeout value (30 seconds)
                callMLAdmin.Timeout = 30000;

                try
                {
                    // Submit the change password request
                    if (callMLAdmin.ChangePassword06a(txtNewPassword.Text, txtConfirmNewPassword.Text))
                    {
                        MessageBox.Show("Password changed", "CallML", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        DialogResult = DialogResult.OK;
                    }
                    else
                    {
                        MessageBox.Show("Failed to change password", "CallML", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (System.Net.WebException WebEx)
                {
                    MessageBox.Show("Unable to connect to CallML admin web service (" + adminURL + "): " + WebEx.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (System.Web.Services.Protocols.SoapException SoapEx)
                {
                    MessageBox.Show(SoapEx.Message, "Change Password", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void ChangePassword_Shown(object sender, EventArgs e)
        {
            txtOldPassword.Focus();
        }
    }
}