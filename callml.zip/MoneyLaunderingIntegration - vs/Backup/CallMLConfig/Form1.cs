using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ECS.Global;
using ECS.Global.Encryption;
using ECS.EvolutionConnectionManager.SystemDetail;
using System.Data.SqlClient;

namespace CallMLConfig
{
    public partial class MLConfig : Form
    {
        private DataSet dsConfig;
        private DataTable dtConfig;
        private SqlDataAdapter daConfig;
        private bool m_Loading;

        private const string DEFAULT_HOST_URL = "https://ct.callcreditsecure.co.uk/services/callml/callml6.asmx";
        private const short DEFAULT_PERIOD_VALUE = 5;
        private const string DEFAULT_PERIOD_TYPE = "Y";
        private const byte DEFAULT_SEARCH_DIRECTORS = 1;
        private const byte DEFAULT_SEARCH_REDIRECTION = 0;
        private const short DEFAULT_MIN_CHECKS = 2;
        private const byte DEFAULT_USE_ER = 0;
        private const byte DEFAULT_USE_FTSE = 0;
        private const byte DEFAULT_USE_BAI = 0;
        private const short DEFAULT_USE_SETTLED_ACC = 0;
        private const byte DEFAULT_USE_CCJ = 0;

        private string m_ShareGroups = "";
        private string m_ShareAccountTypes = "";
        private string m_DecisionWarning = "";

        private int selectedScreenId = 0;
        private int selectedDateId = 0;

        private DateTime m_PasswordChange = DateTime.Now;

        public MLConfig()
        {

            if (!ECSUtils.SysInfo.UserInfo.Administrator)
            {
                MessageBox.Show("This program can only be run by Evolution Administrators.", "CallML Configuration", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Close();
            }

            InitializeComponent();

            SqlConnection conn = ECSUtils.SysInfo.NewConnection();

            daConfig = new SqlDataAdapter();
            daConfig.SelectCommand = new SqlCommand("ML_GetMLConnectionDetails", conn);
            daConfig.SelectCommand.CommandType = CommandType.StoredProcedure;
            daConfig.SelectCommand.Parameters.AddWithValue("@MLType", "CallML");
            daConfig.SelectCommand.Parameters.AddWithValue("@ECSUsername", "AIM");

            daConfig.InsertCommand = new SqlCommand("ML_InsertMLConnectionDetails", conn);
            daConfig.InsertCommand.CommandType = CommandType.StoredProcedure;
            SqlParameter configID = new SqlParameter("@ConfigID", SqlDbType.Int, 0, "ml_config_id");
            configID.Direction = ParameterDirection.Output;
            daConfig.InsertCommand.Parameters.Add(configID);
            daConfig.InsertCommand.Parameters.Add("@ECSUsername", SqlDbType.VarChar, 8, "ecs_username");
            daConfig.InsertCommand.Parameters.Add("@MLType", SqlDbType.VarChar, 20, "ml_type");
            daConfig.InsertCommand.Parameters.Add("@MLUsername", SqlDbType.VarChar, 20, "ml_username");
            daConfig.InsertCommand.Parameters.Add("@MLPassword", SqlDbType.VarChar, 60, "ml_password");
            daConfig.InsertCommand.Parameters.Add("@MLCompanyName", SqlDbType.VarChar, 20, "ml_company_name");
            daConfig.InsertCommand.Parameters.Add("@MLHostURL", SqlDbType.VarChar, 200, "ml_host_url");
            daConfig.InsertCommand.Parameters.Add("@PrdResultEligible", SqlDbType.Int, 0, "prd_result_eligible");
            daConfig.InsertCommand.Parameters.Add("@EligiblePrdType", SqlDbType.VarChar, 1, "eligible_prd_type");
            daConfig.InsertCommand.Parameters.Add("@SearchDirectors", SqlDbType.TinyInt, 0, "search_directors");
            daConfig.InsertCommand.Parameters.Add("@MinChecks", SqlDbType.SmallInt, 0, "min_checks");
            daConfig.InsertCommand.Parameters.Add("@UseER", SqlDbType.Int, 0, "use_er");
            daConfig.InsertCommand.Parameters.Add("@UseFTSE", SqlDbType.TinyInt, 0, "use_ftse");
            daConfig.InsertCommand.Parameters.Add("@UseBAI", SqlDbType.TinyInt, 0, "use_bai");
            daConfig.InsertCommand.Parameters.Add("@UseSettledAccounts", SqlDbType.TinyInt, 0, "use_settledaccounts");
            daConfig.InsertCommand.Parameters.Add("@UseCCJ", SqlDbType.TinyInt, 0, "use_CCJ");
            daConfig.InsertCommand.Parameters.Add("@DecisionWarning", SqlDbType.VarChar, 24, "decision_warning");
            daConfig.InsertCommand.Parameters.Add("@ValueAddedServices", SqlDbType.SmallInt, 0, "value_added_services");
            daConfig.InsertCommand.Parameters.Add("@ExcludeShareGroups", SqlDbType.VarChar, 20, "exclude_share_groups");
            daConfig.InsertCommand.Parameters.Add("@ExcludeShareAccountTypes", SqlDbType.Text, 350, "exclude_share_accounttypes");
            daConfig.InsertCommand.Parameters.Add("@WarningDays", SqlDbType.SmallInt, 0, "warning_days");
            daConfig.InsertCommand.Parameters.Add("@OverrideLevel", SqlDbType.SmallInt, 0, "override_level");
            daConfig.InsertCommand.Parameters.Add("@PDFScreenID", SqlDbType.Int, 0, "lastcheckdate_pdfid");
            daConfig.InsertCommand.Parameters.Add("@PDFDateID", SqlDbType.TinyInt, 0, "lastcheckdate_datano");
            daConfig.InsertCommand.Parameters.Add("@LastPasswordChange", SqlDbType.DateTime, 0, "last_password_change");
            daConfig.InsertCommand.Parameters.Add("@PasswordReminder", SqlDbType.SmallInt, 0, "password_reminder");

            daConfig.UpdateCommand = new SqlCommand("ML_UpdateMLConnectionDetails", conn);
            daConfig.UpdateCommand.CommandType = CommandType.StoredProcedure;
            daConfig.UpdateCommand.Parameters.Add("@ConfigID", SqlDbType.Int, 0, "ml_config_id");
            daConfig.UpdateCommand.Parameters.Add("@ECSUsername", SqlDbType.VarChar, 8, "ecs_username");
            daConfig.UpdateCommand.Parameters.Add("@MLType", SqlDbType.VarChar, 20, "ml_type");
            daConfig.UpdateCommand.Parameters.Add("@MLUsername", SqlDbType.VarChar, 20, "ml_username");
            daConfig.UpdateCommand.Parameters.Add("@MLPassword", SqlDbType.VarChar, 60, "ml_password");
            daConfig.UpdateCommand.Parameters.Add("@MLCompanyName", SqlDbType.VarChar, 20, "ml_company_name");
            daConfig.UpdateCommand.Parameters.Add("@MLHostURL", SqlDbType.VarChar, 200, "ml_host_url");
            daConfig.UpdateCommand.Parameters.Add("@PrdResultEligible", SqlDbType.Int, 0, "prd_result_eligible");
            daConfig.UpdateCommand.Parameters.Add("@EligiblePrdType", SqlDbType.VarChar, 1, "eligible_prd_type");
            daConfig.UpdateCommand.Parameters.Add("@SearchDirectors", SqlDbType.TinyInt, 0, "search_directors");
            daConfig.UpdateCommand.Parameters.Add("@MinChecks", SqlDbType.SmallInt, 0, "min_checks");
            daConfig.UpdateCommand.Parameters.Add("@UseER", SqlDbType.Int, 0, "use_er");
            daConfig.UpdateCommand.Parameters.Add("@UseFTSE", SqlDbType.TinyInt, 0, "use_ftse");
            daConfig.UpdateCommand.Parameters.Add("@UseBAI", SqlDbType.TinyInt, 0, "use_bai");
            daConfig.UpdateCommand.Parameters.Add("@UseSettledAccounts", SqlDbType.TinyInt, 0, "use_settledaccounts");
            daConfig.UpdateCommand.Parameters.Add("@UseCCJ", SqlDbType.TinyInt, 0, "use_ccj");
            daConfig.UpdateCommand.Parameters.Add("@DecisionWarning", SqlDbType.VarChar, 24, "decision_warning");
            daConfig.UpdateCommand.Parameters.Add("@ValueAddedServices", SqlDbType.SmallInt, 0, "value_added_services");
            daConfig.UpdateCommand.Parameters.Add("@ExcludeShareGroups", SqlDbType.VarChar, 20, "exclude_share_groups");
            daConfig.UpdateCommand.Parameters.Add("@ExcludeShareAccountTypes", SqlDbType.Text, 350, "exclude_share_accounttypes");
            daConfig.UpdateCommand.Parameters.Add("@WarningDays", SqlDbType.SmallInt, 0, "warning_days");
            daConfig.UpdateCommand.Parameters.Add("@OverrideLevel", SqlDbType.SmallInt, 0, "override_level");
            daConfig.UpdateCommand.Parameters.Add("@PDFScreenID", SqlDbType.Int, 0, "lastcheckdate_pdfid");
            daConfig.UpdateCommand.Parameters.Add("@PDFDateID", SqlDbType.TinyInt, 0, "lastcheckdate_datano");
            daConfig.UpdateCommand.Parameters.Add("@LastPasswordChange", SqlDbType.DateTime, 0, "last_password_change");
            daConfig.UpdateCommand.Parameters.Add("@PasswordReminder", SqlDbType.SmallInt, 0, "password_reminder");

            dsConfig = new DataSet();
            dtConfig = dsConfig.Tables.Add("Config");
            daConfig.Fill(dtConfig);

            if (dtConfig.Rows.Count == 0)
            {
                NewUser frm = new NewUser("CallML User Account");
                frm.ShowDialog();

                if (frm.DialogResult == DialogResult.OK)
                {
                    EvolutionEncryption.IV = Encoding.ASCII.GetBytes(resEncryption.IV);
                    EvolutionEncryption.Key = Encoding.ASCII.GetBytes(resEncryption.Key);
                    // Insert default values
                    dtConfig.Rows.Add(
                        -1,
                        "AIM",
                        "CallML",
                        frm.UserName,
                        EvolutionEncryption.Encrypt(frm.Password),
                        frm.CompanyName,
                        DEFAULT_HOST_URL,
                        DEFAULT_PERIOD_VALUE,
                        DEFAULT_PERIOD_TYPE,
                        DEFAULT_SEARCH_DIRECTORS,
                        DEFAULT_MIN_CHECKS,
                        DEFAULT_USE_ER,
                        DEFAULT_USE_FTSE,
                        DEFAULT_USE_BAI,
                        DEFAULT_USE_SETTLED_ACC,
                        DEFAULT_USE_CCJ,
                        "",
                        0,
                        m_ShareGroups,
                        m_ShareAccountTypes,
                        30,
                        0,
                        0,
                        0,
                        DateTime.Now,
                        30);

                    //txtPassword.Enabled = true;
                    txtPassword.Enabled = false;
                }
                else
                {
                    MessageBox.Show("A valid account must be entered before configuring the CallML settings.", "CallML Config", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    this.Close();
                    return;
                }
            }
            else
            {
                txtPassword.Enabled = false;
            }

            m_Loading = true;

            string errorMessage = "";

            DataRow dr = dtConfig.Rows[0];
            try { txtURL.Text = ((string)dr["ml_host_url"]).TrimEnd(); }
            catch (Exception e1) { errorMessage = errorMessage + "\ntxtURL: " + e1.Message; }

            try { txtCompanyName.Text = ((string)dr["ml_company_name"]).TrimEnd(); }
            catch (Exception e2) { errorMessage = errorMessage + "\ntxtCompanyName: " + e2.Message; }
            
            try { txtUsername.Text = ((string)dr["ml_username"]).TrimEnd(); }
            catch (Exception e3) { errorMessage = errorMessage + "\ntxtUserName: " + e3.Message; }

            try { m_PasswordChange = (DateTime)dr["last_password_change"]; }
            catch (Exception e4) { errorMessage = errorMessage + "\nm_PasswordChange: " + e4.Message; }

            try { updPasswordReminder.Value = (short)dr["password_reminder"]; }
            catch (Exception e5) { errorMessage = errorMessage + "\nupdPasswordReminder: " + e5.Message; }
               
            try {            
                string password = ((string)dr["ml_password"]).TrimEnd();
                // decrypt password
                EvolutionEncryption.IV = Encoding.ASCII.GetBytes(resEncryption.IV);
                EvolutionEncryption.Key = Encoding.ASCII.GetBytes(resEncryption.Key);
                txtPassword.Text = EvolutionEncryption.Decrypt(password);
                txtPassword.Text = txtPassword.Text.Replace("\0", ""); }
            catch (Exception e6) { errorMessage = errorMessage + "\nPassword: " + e6.Message; }

            try { spnDaysEligible.Value = ((int)dr["prd_result_eligible"]); }
            catch (Exception e7) { errorMessage = errorMessage + "\nspnDaysEligible: " + e7.Message; }

            try {
                switch ((string)dr["eligible_prd_type"])
                {
                    case "D": //day
                        cboPeriod.SelectedIndex = 0;
                        break;
                    case "M": //month
                        cboPeriod.SelectedIndex = 1;
                        break;
                    case "Y": //year
                        cboPeriod.SelectedIndex = 2;
                        break;
                }
            }
            catch (Exception e8) { errorMessage = errorMessage + "\ncboPeriod: " + e8.Message; }


            try { spnMinChecks.Value = (decimal)(short)dr["min_checks"]; }
            catch (Exception e9) { errorMessage = errorMessage + "\nspnMinChecks: " + e9.Message; }

            try { spnExpiryDays.Value = (int)dr["warning_days"]; }
            catch (Exception e10) { errorMessage = errorMessage + "\nspnExpiryDays: " + e10.Message; }

            try { spnSecurityLevel.Value = (byte)dr["override_level"]; }
            catch (Exception e11) { errorMessage = errorMessage + "\nspnSecurityLevel: " + e11.Message; }

            cbxSearchDirectors.Checked = ((byte)dr["search_directors"] == 1);
            cbxFTSE.Checked = ((byte)dr["use_ftse"] == 1);
            cbxUseBAI.Checked = ((byte)dr["use_bai"] == 1);
            cbxCCJ.Checked = ((byte)dr["use_CCJ"] == 1);
            cbxSHARE.Checked = ((byte)dr["use_settledaccounts"] == 1);
            cbxElectoralRoll.Checked = ((byte)dr["use_er"] == 1);
            
            //PopulateValueAddedServices((short)dr["value_added_services"]);
            PopulateDecisionWarning((string)dr["decision_warning"]);
            PopulateSHAREExclusions((string)dr["exclude_share_groups"], (string)dr["exclude_share_accounttypes"]);
            cboAccountType.SelectedIndex = 0;

            selectedScreenId = (int)dr["lastcheckdate_pdfid"];
            selectedDateId = (byte)dr["lastcheckdate_datano"];
            PopulatePDFScreenList();

            if (errorMessage != "")
            {
                MessageBox.Show("CallML config returned an error:" +
                                errorMessage, "CallML Config", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            
            m_Loading = false;
            
            SetButtonStatus();
        }

        //private void PopulateValueAddedServices(short services)
        //{
                     
        //    if ((services & 1) > 0) chkVasCIFAS.Checked = true;
        //    if ((services & 2) > 0) chkVasDeceased.Checked = true;
        //    if ((services & 8) > 0) chkVasAddressLinks.Checked = true;
        //}

        private void PopulateDecisionWarning(string matchWarning)
        {

            if (matchWarning.IndexOf("1") >= 0) chkWarnCIFAS.Checked = true;
            if (matchWarning.IndexOf("2") >= 0) chkWarnPEP.Checked = true;
            if (matchWarning.IndexOf("3") >= 0) chkWarnDeceased.Checked = true; 
            if (matchWarning.IndexOf("4") >= 0) chkWarnGoneAway.Checked = true;
            if (matchWarning.IndexOf("5") >= 0) chkWarnFraudPassport.Checked = true;
            if (matchWarning.IndexOf("6") >= 0) chkWarnAddressLinks.Checked = true; 
            if (matchWarning.IndexOf("7") >= 0) chkWarnDOBAll.Checked = true; 
            if (matchWarning.IndexOf("8") >= 0) chkWarnDOBOne.Checked = true; 
            if (matchWarning.IndexOf("9") >= 0) chkWarnResidency.Checked = true;
            if (matchWarning.IndexOf("10") >= 0) chkWarnDrivingLicense.Checked = true; 
            if (matchWarning.IndexOf("11") >= 0) chkWarnUKPassport.Checked = true;            // We don't support DVLA info (10)

        }

        private void PopulateSHAREExclusions(string accountGroups, string accountTypes)
        {

            //Account Groups
            char[] splitchar = { ',' };
            string[] groupCodes = accountGroups.Split(splitchar);

            foreach (string group in groupCodes)
            {
                switch (group.Trim())
                {
                    case "1":
                        SelectAllInPanel(pnlLoan);
                        break;
                    case "2":
                        SelectAllInPanel(pnlMortgage);
                        break;
                    case "3":
                        SelectAllInPanel(pnlCredit);
                        break;
                    case "4":
                        SelectAllInPanel(pnlTelecoms);
                        break;
                    case "5":
                        SelectAllInPanel(pnlUtilities);
                        break;
                    case "6":
                        SelectAllInPanel(pnlHomeShopping);
                        break;
                    case "7":
                        SelectAllInPanel(pnlBank);
                        break;
                    case "8":
                        SelectAllInPanel(pnlMiscellaneous);
                        break;
                    case "9":
                        SelectAllInPanel(pnlInsurance);
                        break;
                    case "10":
                        SelectAllInPanel(pnlInternet);
                        break;
                }

            }

            //AccountTypes
            string[] typeCodes = accountTypes.Split(splitchar);

            foreach (string type in typeCodes)
            {
                string ctlName = "chk" + type.Trim();

                bool found = false;
                found = FindControl(pnlLoan, ctlName);
                if (!found) found = FindControl(pnlMortgage, ctlName);
                if (!found) found = FindControl(pnlCredit, ctlName);
                if (!found) found = FindControl(pnlTelecoms, ctlName);
                if (!found) found = FindControl(pnlUtilities, ctlName);
                if (!found) found = FindControl(pnlHomeShopping, ctlName);
                if (!found) found = FindControl(pnlBank, ctlName);
                if (!found) found = FindControl(pnlMiscellaneous, ctlName);
                if (!found) found = FindControl(pnlInsurance, ctlName);
                if (!found) found = FindControl(pnlInternet, ctlName);
            }

        }

        bool FindControl(Control parent, string name)
        {
            
            bool found = false;
            
            foreach (Control ctl in parent.Controls)
            {
                if (ctl.Name == name)
                {
                    CheckBox box = (CheckBox)ctl;
                    box.Checked = true;
                    found = true; 
                    break;
                }
            }

            return found;

        }

        void SelectAllInPanel(Panel panel)
        {
        foreach (Control ctrl in panel.Controls)
                {
                    CheckBox box = (CheckBox)ctrl;
                    box.Checked = true;
                }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void PopulatePDFScreenList()
        {

            SqlConnection conn = ECSUtils.SysInfo.NewConnection();
            SqlCommand comm = new SqlCommand("ML_GetPDFScreens", conn);
            comm.CommandType = CommandType.StoredProcedure;

            conn.Open();
            try
            {
                SqlDataReader dr = comm.ExecuteReader();

                while (dr.Read())
                {
                    cboPDFScreen.Items.Add(new PDFScreen(
                                    (int)dr["PDFID"],
                                    ((string)dr["ScreenDescription"]).TrimEnd()));
                    if (selectedScreenId == (int)dr["PDFID"])
                    {
                        cboPDFScreen.SelectedIndex = cboPDFScreen.Items.Count - 1;
                        PopulatePDFDates();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("PopulatePDFScreenList failed", ex);
            }
        }

        private void PopulatePDFDates()
        {

            cboPDFDate.Items.Clear();
            
            SqlConnection conn = ECSUtils.SysInfo.NewConnection();
            SqlCommand comm = new SqlCommand("ML_GetPDFFieldList", conn);
            comm.Parameters.AddWithValue("@PDFID", selectedScreenId); 
            comm.CommandType = CommandType.StoredProcedure;

            conn.Open();
            try
            {
                SqlDataReader dr = comm.ExecuteReader();

                while (dr.Read())
                {
                    byte data_number = (byte)dr["data_number"];
                    string description = ((string)dr["description"]).TrimEnd();
                    cboPDFDate.Items.Add(new PDFDates(data_number, description));
                    if (selectedDateId == data_number)
                    {
                        cboPDFDate.SelectedIndex = cboPDFDate.Items.Count - 1;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("PopulatePDFDates failed", ex);
            }


        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ECS.About.AboutForm aboutForm = new ECS.About.AboutForm(ECSUtils.SysInfo);
            aboutForm.Program = this.Text;
            aboutForm.ShowDialog();
            aboutForm.Dispose();
        }

        //private bool Validate()
        //{
        //    bool result;
        //    if (txtPassword.Text == txtConfirmPassword.Text)
        //    {
        //        result = true;
        //    }
        //    else
        //    {
        //        MessageBox.Show("Password confirmation does not match password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //        txtPassword.Focus();
        //        result = false;
        //    }

        //    return result;
        //}

        public bool Apply()
        {
            bool result = Validate();

            try
            {
                daConfig.Update(dtConfig);
            }
            catch (Exception ex)
            {
                result = false;
                MessageBox.Show("An error occured whilst updating the database:" + Environment.NewLine + ex.Message, "Error updating database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            SetButtonStatus();

            return result;
        }

        private void SetButtonStatus()
        {
            btnSave.Enabled = dsConfig.HasChanges();
            saveToolStripMenuItem.Enabled = btnSave.Enabled;
        }

        private void MLConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (dsConfig != null)   // This will be null if we bail out during the Form load event
            {
                if (dsConfig.HasChanges())
                {
                    DialogResult result = MessageBox.Show("Save changes to Money laundering configuration?", "Save changes?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button3);
                    switch (result)
                    {
                        case DialogResult.Cancel:
                            e.Cancel = true;
                            break;
                        case DialogResult.Yes:
                            if (!Apply())
                                e.Cancel = true;    // if the save fails then don't close
                            break;
                    }
                }
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // just do this once at the end because there's a lot to check!
            SetDecisionWarning();
            SetExcludedAccountTypes();

            Apply();
        }

        private void UpdateDataSet()
        {
            // Update the DataSet where the data has changed

            DataRow dr = dtConfig.Rows[0];
            if (txtURL.Text.TrimEnd() != ((string)dr["ml_host_url"]).TrimEnd())
                dr["ml_host_url"] = txtURL.Text.TrimEnd();

            if (txtCompanyName.Text.TrimEnd() != ((string)dr["ml_company_name"]).TrimEnd())
                dr["ml_company_name"] = txtCompanyName.Text.TrimEnd();

            if (txtUsername.Text.TrimEnd() != ((string)dr["ml_username"]).TrimEnd())
                dr["ml_username"] = txtUsername.Text.TrimEnd();

            // encrypt password
            EvolutionEncryption.IV = Encoding.ASCII.GetBytes(resEncryption.IV);
            EvolutionEncryption.Key = Encoding.ASCII.GetBytes(resEncryption.Key);
            string encPassword = EvolutionEncryption.Encrypt(txtPassword.Text.TrimEnd());

            if (encPassword != ((string)dr["ml_password"]).TrimEnd())
                dr["ml_password"] = encPassword;

            if (spnDaysEligible.Value != ((decimal)(int)dr["prd_result_eligible"]))
                dr["prd_result_eligible"] = (int)spnDaysEligible.Value;

            if (cboPeriod.Text.Substring(0, 1) != ((string)dr["eligible_prd_type"]))
                dr["eligible_prd_type"] = cboPeriod.Text.Substring(0, 1);

            if (spnMinChecks.Value != (decimal)(short)dr["min_checks"])
                dr["min_checks"] = (short)spnMinChecks.Value;

            if (BoolToByte(cbxSearchDirectors.Checked) != (byte)dr["search_directors"])
                dr["search_directors"] = BoolToByte(cbxSearchDirectors.Checked);

            if (BoolToByte(cbxFTSE.Checked) != (byte)dr["use_ftse"])
                dr["use_ftse"] = BoolToByte(cbxFTSE.Checked);

            if (BoolToByte(cbxElectoralRoll.Checked) != (byte)dr["use_er"])
                dr["use_er"] = BoolToByte(cbxElectoralRoll.Checked);

            if (BoolToByte(cbxUseBAI.Checked) != (byte)dr["use_bai"])
                dr["use_bai"] = BoolToByte(cbxUseBAI.Checked);

            if (BoolToByte(cbxSHARE.Checked) != (byte)dr["use_settledaccounts"])
                dr["use_settledaccounts"] = BoolToByte(cbxSHARE.Checked);

            if (BoolToByte(cbxCCJ.Checked) != (byte)dr["use_ccj"])
                dr["use_ccj"] = BoolToByte(cbxCCJ.Checked);

            dr["value_added_services"] = 0;
            //if (chkVasCIFAS.Checked) dr["value_added_services"] = (short)dr["value_added_services"] + 1;
            //if (chkVasDeceased.Checked) dr["value_added_services"] = (short)dr["value_added_services"] + 2;
            //if (chkVasAddressLinks.Checked) dr["value_added_services"] = (short)dr["value_added_services"] + 8;


            dr["decision_warning"] = "?";
            dr["exclude_share_groups"] = "?";
            dr["exclude_share_accounttypes"] = "?";

            if (spnExpiryDays.Value != (int)dr["warning_days"])
                dr["warning_days"] = (short)spnExpiryDays.Value;

            if (spnSecurityLevel.Value != (byte)dr["override_level"])
                dr["override_level"] = (short)spnSecurityLevel.Value;

            dr["lastcheckdate_pdfid"] = selectedScreenId;
            dr["lastcheckdate_datano"] = selectedDateId;

            dr["last_password_change"] = m_PasswordChange;
            dr["password_reminder"] = (short)updPasswordReminder.Value;

        }

        private byte BoolToByte(bool Value)
        {
            if (Value)
                return 1;
            else
                return 0;
        }

        private void ItemChanged(object sender, EventArgs e)
        {
            if (!m_Loading)
            {
                UpdateDataSet();
                SetButtonStatus();
            }
        }

        private void restoreDefaultsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            txtURL.Text = DEFAULT_HOST_URL;
            spnDaysEligible.Value = (decimal)DEFAULT_PERIOD_VALUE;
            switch (DEFAULT_PERIOD_TYPE)
            {
                case "D":
                    cboPeriod.SelectedIndex = 0;
                    break;
                case "M":
                    cboPeriod.SelectedIndex = 1;
                    break;
                case "Y":
                    cboPeriod.SelectedIndex = 2;
                    break;
            }
            
            spnMinChecks.Value = (int)DEFAULT_MIN_CHECKS;
            cbxSearchDirectors.Checked = DEFAULT_SEARCH_DIRECTORS == 1;
            cbxFTSE.Checked = DEFAULT_USE_FTSE == 1;
            cbxUseBAI.Checked = DEFAULT_USE_BAI == 1;
            cbxSHARE.Checked = DEFAULT_USE_SETTLED_ACC == 1;
            cbxCCJ.Checked = DEFAULT_USE_CCJ == 1;

            //chkVasCIFAS.Checked = false;
            //chkVasDeceased.Checked = false;
            //chkVasAddressLinks.Checked = false;

            chkWarnCIFAS.Checked = false;
            chkWarnPEP.Checked = false;
            chkWarnDeceased.Checked = false;
            chkWarnGoneAway.Checked = false;
            chkWarnFraudPassport.Checked = false;
            chkWarnAddressLinks.Checked = false;
            chkWarnDOBAll.Checked = false;
            chkWarnDOBOne.Checked = false;
            chkWarnDrivingLicense.Checked = false;
            chkWarnUKPassport.Checked = false;

            DefaultExclusions(pnlLoan);
            DefaultExclusions(pnlMortgage);
            DefaultExclusions(pnlCredit);
            DefaultExclusions(pnlTelecoms);
            DefaultExclusions(pnlUtilities);
            DefaultExclusions(pnlHomeShopping);
            DefaultExclusions(pnlBank);
            DefaultExclusions(pnlMiscellaneous);
            DefaultExclusions(pnlInsurance);
            DefaultExclusions(pnlInternet);

        }

        void DefaultExclusions(Panel pnl)
        {
            foreach (Control ctl in pnl.Controls)
            {
                CheckBox box = (CheckBox)ctl;
                box.Checked = false;
            }
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (dsConfig.HasChanges())
            {
                DialogResult dr = MessageBox.Show("Changing the password will save the changes you have made", "Warning", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning);
                if (dr == DialogResult.Cancel)
                    return;

                // Make sure that what they have input is valid
                if (!Validate())
                    return;
            }

            // Pop a dialog prompting old/new password

            ChangePassword changepwd = new ChangePassword(txtCompanyName.Text, txtUsername.Text, txtPassword.Text, txtURL.Text);
            if (changepwd.ShowDialog() == DialogResult.OK)
            {
                // Write the password back to the database
                m_PasswordChange = DateTime.Today;
                txtPassword.Text = changepwd.NewPassword;
                SetDecisionWarning();
                SetExcludedAccountTypes();
                Apply();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            pnlLoan.Visible = false;
            pnlMortgage.Visible = false;
            pnlCredit.Visible = false;
            pnlTelecoms.Visible = false;
            pnlUtilities.Visible = false;
            pnlHomeShopping.Visible = false;
            pnlBank.Visible = false;
            pnlMiscellaneous.Visible = false;
            pnlInsurance.Visible = false;
            pnlInternet.Visible = false;
                
            switch (cboAccountType.SelectedIndex)
            {
                case 0: //Loan & Installment Credit
                    pnlLoan.Visible = true;
                    break;
                case 1: //Mortgage
                    pnlMortgage.Visible = true;
                    break;
                case 2: //Revolving Credit & Budget
                    pnlCredit.Visible = true;
                    break;
                case 3: //Telecommunications
                    pnlTelecoms.Visible = true;
                    break;
                case 4: //Utilities
                    pnlUtilities.Visible = true;
                    break;
                case 5: //Home Shopping
                    pnlHomeShopping.Visible = true;
                    break;
                case 6: //Bank
                    pnlBank.Visible = true;
                    break;
                case 7: //Miscellaneous
                    pnlMiscellaneous.Visible = true;
                    break;
                case 8: //Insurance
                    pnlInsurance.Visible = true;
                    break;
                case 9: //Internet
                    pnlInternet.Visible = true;
                    break;
            }

        }

        private void SetExcludedAccountTypes()
        {
            m_ShareGroups = "";
            m_ShareAccountTypes = "";

            //pnlLoan
            SetPanelValues(pnlLoan, 1);
            //pnlMortgage
            SetPanelValues(pnlMortgage, 2);
            //pnlCredit
            SetPanelValues(pnlCredit, 3);
            //pnlTelecoms
            SetPanelValues(pnlTelecoms, 4);
            //pnlUtilities
            SetPanelValues(pnlUtilities, 5);
            //pnlHomeShopping
            SetPanelValues(pnlHomeShopping, 6);
            //pnlBank
            SetPanelValues(pnlBank, 7);
            //pnlMiscellaneous
            SetPanelValues(pnlMiscellaneous, 8);
            //pnlInsurance
            SetPanelValues(pnlInsurance, 9);
            //pnlInternet
            SetPanelValues(pnlInternet, 10);

            if (m_ShareGroups.Length > 0) m_ShareGroups = m_ShareGroups.Substring(1);
            if (m_ShareAccountTypes.Length > 0) m_ShareAccountTypes = m_ShareAccountTypes.Substring(1);

            DataRow dr = dtConfig.Rows[0];
            dr["exclude_share_groups"] = (string)m_ShareGroups;

            if ((string)m_ShareAccountTypes == String.Empty)
                (string)m_ShareAccountTypes = " ";
            
            dr["exclude_share_accounttypes"] = (string)m_ShareAccountTypes;
        }

        void SetPanelValues(Panel panel, int type)
        {
            bool allSelected;
            allSelected = true;
            foreach (Control ctrl in panel.Controls)
            {
                CheckBox box = (CheckBox)ctrl;
                if (!box.Checked)
                {
                    allSelected = false;
                    break;
                }
            }
            if (allSelected)
            {
                m_ShareGroups = m_ShareGroups + "," + type.ToString();
            }
            else
            {
                foreach (Control ctrl in panel.Controls)
                {
                    CheckBox box = (CheckBox)ctrl;
                    if (box.Checked)
                    {
                        m_ShareAccountTypes = m_ShareAccountTypes + "," + box.Name.ToString().Substring(3);
                    }
                }
            }

        }

        private void SetDecisionWarning()
        {
            
            m_DecisionWarning = "";

            //if (chkWarnCIFAS.Checked) m_DecisionWarning = m_DecisionWarning + ",1";
            if (chkWarnPEP.Checked) m_DecisionWarning = m_DecisionWarning + ",2";
            if (chkWarnDeceased.Checked) m_DecisionWarning = m_DecisionWarning + ",3";
            if (chkWarnGoneAway.Checked) m_DecisionWarning = m_DecisionWarning + ",4";
            if (chkWarnFraudPassport.Checked) m_DecisionWarning = m_DecisionWarning + ",5";
            if (chkWarnAddressLinks.Checked) m_DecisionWarning = m_DecisionWarning + ",6";
            if (chkWarnDOBAll.Checked) m_DecisionWarning = m_DecisionWarning + ",7";
            if (chkWarnDOBOne.Checked) m_DecisionWarning = m_DecisionWarning + ",8";
            if (chkWarnResidency.Checked) m_DecisionWarning = m_DecisionWarning + ",9";
            if (chkWarnDrivingLicense.Checked) m_DecisionWarning = m_DecisionWarning + ",10";
            if (chkWarnUKPassport.Checked) m_DecisionWarning = m_DecisionWarning + ",11";

            if (m_DecisionWarning.Length > 0) m_DecisionWarning = m_DecisionWarning.Substring(1);
            DataRow dr = dtConfig.Rows[0];
            dr["decision_warning"] = m_DecisionWarning;

        }

        private void grpValueAddedServices_Enter(object sender, EventArgs e)
        {

        }

        private void cboPDFScreen_SelectedIndexChanged(object sender, EventArgs e)
        {
            //show the data in the relevant fields
            PDFScreen screen = (PDFScreen)cboPDFScreen.SelectedItem;
            selectedScreenId = screen.ScreenID;
            if (!m_Loading)
                selectedDateId = 0;
            PopulatePDFDates();

        }

        private struct PDFScreen
        {
            public int ScreenID;
            public string ScreenName;

            public PDFScreen(int _ScreenID, string _ScreenName)
            {
                ScreenID = _ScreenID;
                ScreenName = _ScreenName;
            }

            public override string ToString()
            {
                return this.ScreenName;
            }
        }
        
        private struct PDFDates
        {
            public int DataNo;
            public string Description;

            public PDFDates(int _DataNo, string _Description)
            {
                DataNo = _DataNo;
                Description = _Description;
            }

            public override string ToString()
            {
                return this.Description;
            }
        }

        private void cboPDFDate_SelectedIndexChanged(object sender, EventArgs e)
        {
            //show the data in the relevant fields
            PDFDates dates = (PDFDates)cboPDFDate.SelectedItem;
            selectedDateId = dates.DataNo;
            if (!m_Loading)
            {
                UpdateDataSet();
                SetButtonStatus();
            }
        }

        private void changeAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to change the current user account?", "CalML Config", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                NewUser frm = new NewUser("Change Account Settings");
                frm.ShowDialog();

                if (frm.DialogResult == DialogResult.OK)
                {
                    txtCompanyName.Text = frm.CompanyName;
                    txtUsername.Text = frm.UserName;
                    txtPassword.Text = frm.Password;
                    m_PasswordChange = DateTime.Today;
                }
            }
        }

        private void MLConfig_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (cboPDFDate.SelectedIndex >= 0)
            {
                DialogResult result = MessageBox.Show("The contents of the PDF Links - Last Check Date field will be inserted into the ML History table.  Do you wish to continue?",
                            "CallML Config", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {

                    SqlConnection conn = ECSUtils.SysInfo.NewConnection();

                    try
                    {
                        SqlCommand comm = new SqlCommand("ML_InsertLastMLFromPDF", conn);
                        comm.CommandType = CommandType.StoredProcedure;

                        int iRowsAffected;
                        conn.Open();
                        try
                        {
                            iRowsAffected = comm.ExecuteNonQuery();

                            iRowsAffected = iRowsAffected / 2;

                            MessageBox.Show(iRowsAffected.ToString() + " individuals updated.", "CallMLConfig", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                    catch (Exception ex)
                    {
                        throw new ApplicationException("ML_InsertLastMLFromPDF failed ", ex);
                    }
                }
            }
            else
                MessageBox.Show("Please select a PDF Date field to perform this operation.", "CallMLConfig", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }


}