using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.Xml;
using System.Web.Services;
using ECS.Utilities;
using wsSecurity = ECS.Utilities.Connectivity.Security;
using wsClient = ECS.Utilities.Connectivity.Client;
using wsMatter = ECS.Utilities.Connectivity.Matter;

namespace ECS.Utilities.Connectivity
{
    public static class EvolutionWebServices
    {
        static wsClient.Client m_wsClient;
        static wsSecurity.Security m_wsSecurity;
        static wsMatter.Matter m_wsMatter;

        public static wsClient.Client ClientWebService
        {
            get
            {
                if (m_wsClient == null)
                {
                    m_wsClient = new wsClient.Client();
                    m_wsClient.Url = GetConfigURL("Client");
                    m_wsClient.Credentials = CredentialCache.DefaultCredentials;
                }
                return m_wsClient;
            }

        }

        public static wsSecurity.Security SecurityWebService
        {
            get
            {
                if (m_wsSecurity == null)
                {
                    m_wsSecurity = new wsSecurity.Security();
                    m_wsSecurity.Url =GetConfigURL("Security");
                    m_wsSecurity.Credentials = CredentialCache.DefaultCredentials;
                }
                return m_wsSecurity;
	        }
        }


        public static wsMatter.Matter MatterWebService
        {
            get
            {
                if (m_wsMatter == null)
                {
                    m_wsMatter = new wsMatter.Matter();
                    m_wsClient.Url = GetConfigURL("Matter"); 
                    m_wsMatter.Credentials = CredentialCache.DefaultCredentials;
                }
                return m_wsMatter;
            }

        }

        public static string GetToken(string UserName, string Password)
        {
            return SecurityWebService.GetToken(UserName, Password);
        }

        private static string DetectErrorString(XmlDocument ErrorXml)
        {
            string returnError = string.Empty;
            returnError = XmlUtilities.GetXmlString(ErrorXml, "//Description");
            return returnError;
        }

        /// <summary>
        /// Verifys that the Xml Returned from a query is complete and valid
        /// returns true if the Data is valid, false if not, complete with a description
        /// of the error
        /// </summary>
        /// <returns></returns>
        public static bool CheckReturn(XmlDocument Data, List<string> Descriptions)
        {
            bool bReturn = false;

            Descriptions = pCheckReturn(Data);
            if (Descriptions.Count == 0) { bReturn = true; };

            return bReturn;
        }

        public static bool CheckReturn(string Data, List<string> Descriptions)
        {
            XmlDocument XmlData = new XmlDocument();
            XmlData.LoadXml(Data);
            return CheckReturn(XmlData, Descriptions);
        }

        private static List<string> pCheckReturn(XmlDocument oDoc)
        {
            string sError = string.Empty;
            List <string> oDescriptions = new List<string>();
            sError = DetectErrorString(oDoc);
           
            bool bValid = oDoc.FirstChild.Name.Contains("Success");
            if (!bValid)
            {
                //Check 1: Has the Web Service returned an internal error
                if (sError != null && sError != string.Empty)
                {
                    oDescriptions.Add(sError);
                }
                else //only perform subsequent checks if valid data
                {

                    //Check 2: Valid Data Returned (ECSDATA present and has child nodes)
                    XmlNode oNode = oDoc.SelectSingleNode("/ECSDATA");
                    if (oNode == null)
                    {
                        oDescriptions.Add("Invalid Data returned");
                    }
                    else if (oNode.ChildNodes.Count == 0)
                    {
                        oDescriptions.Add("ID not present in specified Evolution database");
                    }
                }
            }
            return oDescriptions;
        }

        public static string GetConfigURL(string ServiceName)
        {
            string sLocation;
            try
            {
                XmlDocument config = new XmlDocument();
                sLocation = string.Format(@"{0}\WebServiceLocationConfig.xml",Environment.CurrentDirectory);
                #if DEBUG
                        sLocation = @"D:\Documents and Settings\revans\My Documents\Visual Studio 2005\Projects\MoneyLaunderingIntegration\ECSConnectivityUtilities\bin\Debug\WebServiceLocationConfig.xml";
                #endif
                config.Load(sLocation);
                return Utilities.XmlUtilities.GetXmlString(config, "//" + ServiceName);
            }
            catch (System.IO.IOException ex)
            {
                throw new ApplicationException("Could Not Load Web Services Configuration", ex);
            }

        }
    }
}