using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using ECS.Global;
using ECS.MoneyLaundering;

namespace MoneyLaunderingCheck
{
    public partial class frmQuickML : Form
    {
        public frmQuickML()
        {
            InitializeComponent();

            GetTitleList();
        }

        private void GetTitleList()
        {

            SqlConnection conn = ECSUtils.SysInfo.NewConnection();
            SqlCommand comm = new SqlCommand("GetTitleList", conn);
            comm.CommandType = CommandType.StoredProcedure;

            conn.Open();
            try
            {
                SqlDataReader dr = comm.ExecuteReader();

                while (dr.Read())
                {
                    cboTitle.Items.Add(((string)dr["titles"]).TrimEnd());
                }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("GetTitleList failed", ex);
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            IECSCasePlanExecutor casePlanExec = new ECSCasePlanExecutor();
            bool result = casePlanExec.PerformClientMLSearch(0, 0,
                            cboTitle.Text, txtForenames.Text, txtSurname.Text, dtpDOB.Value,
                            txtBuildingName.Text, txtBiuldingNo.Text, txtLine1.Text, txtLine2.Text, txtLine3.Text,
                            txtVillage.Text, txtTown.Text, txtPostcode.Text);

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtVillage_TextChanged(object sender, EventArgs e)
        {

        }
    }
}