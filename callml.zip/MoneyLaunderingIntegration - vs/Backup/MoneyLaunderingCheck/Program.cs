using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ECS.MoneyLaundering;

namespace MoneyLaunderingCheck
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static int Main(string[] Args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            bool result = false;
            int programID, workID, clientEntityID, matterEntityID;
            string title, forenames, surname;
            DateTime dob = DateTime.Today;
            string building_name, building_no, line1, line2, line3;
            string village, town, postcode;

            switch (Args.Length)
            {
                case 0:
                    //Launch the QuickML dialog to allow entry
                    frmQuickML frm = new frmQuickML();
                    frm.ShowDialog();
                    break;
                case 1: //client
                    if ((Int32.TryParse(Args[0], out clientEntityID)))
                    {
                        IECSCasePlanExecutor casePlanExec = new ECSCasePlanExecutor();
                        result = casePlanExec.PerformClientMLSearch(clientEntityID, 0);
                    }
                    break;
                case 2: //matter
                    if ((Int32.TryParse(Args[0], out clientEntityID)) &&
                        (Int32.TryParse(Args[1], out matterEntityID)))
                    {
                        IECSCasePlanExecutor casePlanExec = new ECSCasePlanExecutor();
                        result = casePlanExec.PerformClientMLSearch(clientEntityID, matterEntityID);
                    }
                    break;
                case 4: // reload the report                    
                    if ((Int32.TryParse(Args[1], out clientEntityID)))
                    {
                        int sequencer;
                        if ((Int32.TryParse(Args[2], out sequencer)))
                        {
                            if ((Int32.TryParse(Args[0], out programID)))
                            {
                                IECSCasePlanExecutor casePlanExec = new ECSCasePlanExecutor();

                                switch (Args[3])
                                {
                                    case "V": //view report
                                        result = casePlanExec.GenerateMLReport(programID, clientEntityID, sequencer);
                                        break;
                                    case "R": //resubmit report
                                        result = casePlanExec.ResubmitMLReport(clientEntityID, sequencer);
                                        break;
                                    case "O": //override refer decision
                                        result = casePlanExec.OverrideMLReport(clientEntityID, sequencer, "override");
                                        break;
                                    case "D": //decline refer decision
                                        result = casePlanExec.OverrideMLReport(clientEntityID, sequencer, "decline");
                                        break;
                                }
                            }
                        }
                    }
                    break;
                case 14: //new 
                    title = Args[2];
                    forenames = Args[3];
                    surname = Args[4];
                    string[] dateArray = Args[5].Split('/');
                    try
                    {
                        int day;
                        Int32.TryParse(dateArray[0], out day);
                        int month;
                        Int32.TryParse(dateArray[1], out month);
                        int year;
                        Int32.TryParse(dateArray[2], out year);
                        dob = new DateTime(year, month, day);
                    }
                    catch { }
                    building_name = Args[6];
                    building_no = Args[7];
                    line1 = Args[8];
                    line2 = Args[9];
                    line3 = Args[10];
                    village = Args[11];
                    town = Args[12];
                    postcode = Args[13];
                    if ((Int32.TryParse(Args[0], out programID)) && (Int32.TryParse(Args[1], out workID)))
                    {
                        IECSCasePlanExecutor casePlanExec = new ECSCasePlanExecutor();
                        result = casePlanExec.PerformClientMLSearch(programID, workID,
                                        title, forenames, surname, dob,
                                        building_name, building_no, line1, line2, line3,
                                        village, town, postcode);
                    }
                    break;
                default:
                    MessageBox.Show("Invalid number of arguments (" + Args.Length + ") - expected 1, 4 or 14.", "Money Laundering Check", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    break;

            }
            
            if (result)
                return 0;
            else
                return -1;
        }
    }
}