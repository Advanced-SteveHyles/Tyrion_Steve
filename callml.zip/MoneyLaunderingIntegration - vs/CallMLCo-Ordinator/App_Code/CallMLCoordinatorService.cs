using System;
using System.Net;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Xml;
using System.Security.Principal;
using System.Xml.Xsl;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Diagnostics;
using AIM.Utilities;
using AIM.Xml.FacadeLibrary;
using CallML;

[WebService(Namespace = "http://www.aim.co.uk/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class CallMLCoordinatorService : System.Web.Services.WebService
{
    CallML.CallML m_CallMLService;
    EventLog m_oEventLog;
    static string m_sMLUserName = string.Empty;
    static string m_sMLPassword = string.Empty;
    static string m_sMLCompanyName = string.Empty;
    static string m_sCallMLURL = string.Empty;

    public CallMLCoordinatorService() 
    {  
        if (EvolutionEventLog != null)
        {
            m_CallMLService = new CallML.CallML();
            m_CallMLService.Timeout = System.Threading.Timeout.Infinite;
            m_CallMLService.Url = CallMLURL;
        }
    }
    
    //TODO: Implement Web Service Security & token based
    [WebMethod]
    public XmlDocument SubmitRequest(XmlDocument Data)
    {
        callmlsearch oQueryML=null, oResultML=null;
        XmlDocument oResponseData=null;
       
        try
        {
            //build the submission based on the supplied data
            oQueryML = PrepareSubmission(Data);
            m_CallMLService.callcreditheadersValue = GetHeader();

            //This code allows the web proxy to use the credentials of the calling thread, which should be
            //the requesting user. This is nessecary where proxies to internet access are in place
            WindowsIdentity identity = (WindowsIdentity)System.Threading.Thread.CurrentPrincipal.Identity;
            using (WindowsImpersonationContext impersonationContext = identity.Impersonate())
            {
                //Internet Explorer on the host server should have the proxy configured in order for this to work
                //Note on GetDefaultProxy: It's depreciated, but it still does the job better than the replacements...
                WebProxy wp = WebProxy.GetDefaultProxy();
                wp.UseDefaultCredentials = true;
                m_CallMLService.Proxy = wp;
                oResultML = m_CallMLService.Search(oQueryML);
            }

            //render the response data in to generic ecs Money Laundering details
            oResponseData = RenderResponseData(oResultML);
        }
        catch (Exception e) 
        {
            LogException(e);
            throw new ApplicationException("CallML Submission Failed");
        }

        return oResponseData;
    }

    private callmlsearch PrepareSubmission(XmlDocument Data)
    {
        ECSClientFacade oClient;
        callmlsearch oSearchReturn;
        callmlparameters oSearchParameters;

        //instantiate key elements
        oClient = new ECSClientFacade(Data);
        oSearchReturn = new callmlsearch();
        oSearchParameters = new callmlparameters();

        //Set header parameters
        oSearchParameters.searchpurpose = "ML";
        oSearchParameters.stringent = true;

        //for v1.0 a long address and name will provide a match, confirmed by Paul Davies @ CallML 
        oSearchParameters.name = ConvertEvolutionName(oClient);
        oSearchParameters.currentaddress = ConvertEvolutionAddress(oClient.MainAddress);
        
        //add parameters to search objects
        oSearchReturn.parameters = oSearchParameters;

        return oSearchReturn;
    }

    private address ConvertEvolutionAddress(ECSAddressFacade pEcsAddress)
    {
        address mlAddress = new address();
        if (pEcsAddress != null)
        {
            mlAddress.buildingname = pEcsAddress.BuildingName;
            mlAddress.buildingno = pEcsAddress.BuildingNumber;
            //mlAddress.abodeno = pEcsAddress.BuildingNumber;   // DMW - 22/2/2007 - commented this out, building number is not the same as abode number
            mlAddress.street1 = pEcsAddress.AddressLine1;
            mlAddress.street2 = pEcsAddress.AddressLine2;
            mlAddress.posttown = pEcsAddress.Town;
            mlAddress.postcode = pEcsAddress.Postcode;
        }
        return mlAddress;
    }

    private name ConvertEvolutionName(ECSClientFacade pEcsClient)
    {
        name mlName = new name();
        if(pEcsClient!=null)
        {
            mlName.title=pEcsClient.Salutation;
            mlName.forename=pEcsClient.FirstName;
            mlName.othernames =pEcsClient.MiddleNames;
            mlName.surname=pEcsClient.Surname;
        }
        return mlName;
    }

    private callcreditheaders GetHeader()
    {
        callcreditheaders mlHeader = new callcreditheaders();
        mlHeader.ojjobid = "M100";
        mlHeader.company = CallMLCompanyName;
        mlHeader.username = CallMLUserName;
        mlHeader.password = CallMLPassword;
        return mlHeader;
    }

    private XmlDocument RenderResponseData(callmlsearch SearchResponseData)
    {
        string sSearchResponseXml = string.Empty;
        XmlDocument oReturn = null;

        sSearchResponseXml = XmlUtilities.GetSerializedXmlFromObject(SearchResponseData);
        XmlUtilities.TransformXML(sSearchResponseXml, ref oReturn, Server.MapPath(@"App_LocalResources\CallMLtoGenericML.xsl"));

        return oReturn;
    }
    
    private void LogException(Exception ex)
    {
        string sSourceName = "CallML Integration";
        string sMessage, sMessageTemplate = "CallML Co-ordinator Error {0}: {1} occured in {2}";

        EvolutionEventLog.Source = sSourceName;
        sMessage = string.Format(sMessageTemplate,ex.GetType().ToString(),ex.Message,ex.Source);
        EvolutionEventLog.WriteEntry(sMessage, EventLogEntryType.Warning, 1);
        EvolutionEventLog.Close();
    }

    // NOTE: The Installer should create an "Evolution" Event log service, as the aspnet account
    // under most circumstances will not have the rights to do so
    private EventLog EvolutionEventLog
    {
        get
        {
            if (m_oEventLog == null)
            {
                try
                {
                    if (!EventLog.SourceExists("AIM"))
                    {
                        EventLog.CreateEventSource("AIM", "Evolution");
                    }
                    m_oEventLog = new EventLog("Evolution");
                }
                catch (Exception)
                {
                    throw new ApplicationException("Event log cannot be accessed, Error logging disabled");
                }
            }
            return m_oEventLog;
        }
    }

    private string CallMLUserName
    {
        get
        {
            EnsurePopulatedConnectionDetails();
            return m_sMLUserName.Trim();
        }
    }
    
    private string CallMLPassword
    {
        get
        {
            EnsurePopulatedConnectionDetails();
            return m_sMLPassword.Trim();
        }
    }
    
    private string CallMLURL
    {
        get
        {
            EnsurePopulatedConnectionDetails();
            return m_sCallMLURL.Trim();
        }
    }
    
    private string CallMLCompanyName
    {
        get
        {
            EnsurePopulatedConnectionDetails();
            return m_sMLCompanyName.Trim();
        }
    }

    private void EnsurePopulatedConnectionDetails()
    {
        if (m_sMLUserName == string.Empty || m_sMLPassword == string.Empty || m_sMLCompanyName == string.Empty || m_sCallMLURL == string.Empty)
        {
            PopulateConnectionDetails();
        }
    }

    private void PopulateConnectionDetails()
    {
        string sConnection = string.Empty;
        SqlParameter[] oSpParams;
        const string GETMLCONNECTIONDETAILS = "ML_GetMLConnectionDetails";

        //the connection string should be in the web.config
        sConnection = System.Configuration.ConfigurationManager.ConnectionStrings["Evolution"].ConnectionString;

        //Get the SQL Helper to 'Discover' the parameter names, types, etc..
        oSpParams = SqlHelperParameterCache.GetSpParameterSet(sConnection, GETMLCONNECTIONDETAILS, false);

        //Apply Values to stored Stored Procedure parameter cache
        foreach (SqlParameter oParam in oSpParams)
        {
            switch (oParam.ParameterName)
            {
                case "@MLType":
                    oParam.Value = "CallML";
                    break;
                //Note: The configuration does allow a per-user set of callml connection credentials
                //however this is not the prefered scenario for CallML so a single, default set of credentials is
                //used in V1.0
                case "@EcsUserName":
                    oParam.Value = "AIM";
                    break;
                default: break;
            }
        }

        SqlHelper.ExecuteNonQuery(sConnection, System.Data.CommandType.StoredProcedure, GETMLCONNECTIONDETAILS, oSpParams);

        //add returned parameters to a list structure
        List<SqlParameter> returnValues = new List<SqlParameter>();
        returnValues.AddRange(oSpParams);

        //use anonymous delegate methods to find and return the result values
        m_sMLUserName = (string)returnValues.Find(delegate(SqlParameter prm) { return prm.ParameterName == "@MLUserName"; }).Value;
        m_sMLPassword = (string)returnValues.Find(delegate(SqlParameter prm) { return prm.ParameterName == "@MLPassword"; }).Value;
        m_sMLCompanyName = (string)returnValues.Find(delegate(SqlParameter prm) { return prm.ParameterName == "@MLCompanyName"; }).Value;
        m_sCallMLURL = (string)returnValues.Find(delegate(SqlParameter prm) { return prm.ParameterName == "@MLHostURL"; }).Value;
    }
}